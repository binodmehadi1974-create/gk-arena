import 'package:flutter_test/flutter_test.dart';
import 'package:gk_arena/features/learning/database/in_memory_learning_data_source.dart';
import 'package:gk_arena/features/learning/models/learning_models.dart';
import 'package:gk_arena/features/learning/repositories/learning_repository.dart';
import 'package:gk_arena/features/question_bank/database/in_memory_question_data_source.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/features/quiz/services/quiz_scoring_service.dart';

Question _makeQuestion({
  required String id,
  required QuestionSubject subject,
  required String text,
  int correctIndex = 0,
}) {
  final DateTime now = DateTime.utc(2026, 1, 1);
  return Question(
    id: id,
    questionText: text,
    options: const <String>['Option A', 'Option B', 'Option C', 'Option D'],
    correctOptionIndex: correctIndex,
    explanation: 'Verified explanation for $id.',
    subject: subject,
    topic: '${subject.titleEn} Core',
    subtopic: 'Fundamentals',
    difficulty: QuestionDifficulty.medium,
    language: QuestionLanguage.english,
    examCategory: ExamCategory.general,
    questionType: QuestionType.singleChoice,
    sourceReference: 'Unit Test Fixture',
    verificationStatus: VerificationStatus.verified,
    createdAt: now,
    updatedAt: now,
  );
}

void main() {
  const QuizScoringService scoringService = QuizScoringService();

  late QuestionRepository questionRepository;
  late InMemoryLearningStore sharedStore;
  late LearningRepository learningRepository;
  late DateTime fakeNow;

  late Question qHist1;
  late Question qHist2;
  late Question qGeo1;
  late Question qMath1;

  setUp(() async {
    fakeNow = DateTime.utc(2026, 11, 22, 10, 0);
    questionRepository = QuestionRepository(
      dataSource: InMemoryQuestionDataSource(),
    );
    await questionRepository.initialize();

    qHist1 = _makeQuestion(
      id: 'q_hist_1',
      subject: QuestionSubject.history,
      text: 'Which dynasty built the Brihadeeswarar Temple?',
      correctIndex: 0,
    );
    qHist2 = _makeQuestion(
      id: 'q_hist_2',
      subject: QuestionSubject.history,
      text: 'In which year was the Battle of Plassey fought?',
      correctIndex: 1,
    );
    qGeo1 = _makeQuestion(
      id: 'q_geo_1',
      subject: QuestionSubject.geography,
      text: 'Which river is known as the Dakshin Ganga?',
      correctIndex: 2,
    );
    qMath1 = _makeQuestion(
      id: 'q_math_1',
      subject: QuestionSubject.mathematics,
      text: 'What is the value of 15 squared?',
      correctIndex: 3,
    );

    await questionRepository.saveBatch(<Question>[
      qHist1,
      qHist2,
      qGeo1,
      qMath1,
    ]);

    sharedStore = InMemoryLearningStore();
    learningRepository = LearningRepository(
      dataSource: InMemoryLearningDataSource(store: sharedStore),
      questionRepository: questionRepository,
      clock: () => fakeNow,
    );
    await learningRepository.initialize();
  });

  test('New user dashboard starts with clean empty state and zero fabricated stats', () async {
    final StudentDashboardSummary summary =
        await learningRepository.getDashboardSummary();

    expect(summary.hasActivity, isFalse);
    expect(summary.totalTestsAttempted, 0);
    expect(summary.totalQuestionsAttempted, 0);
    expect(summary.totalCorrect, 0);
    expect(summary.totalIncorrect, 0);
    expect(summary.overallAccuracyPercent, 0.0);
    expect(summary.bookmarksCount, 0);
    expect(summary.pendingWrongAnswersCount, 0);
    expect(summary.recentTests, isEmpty);
    expect(summary.subjectAnalytics.length, QuestionSubject.values.length);
    expect(
      summary.subjectAnalytics.every((SubjectAnalytics s) => !s.hasActivity),
      isTrue,
    );
  });

  test('Saving test history persists full score breakdown and supports reopening review', () async {
    final QuizConfig config = const QuizConfig(
      mode: TestMode.subjectWise,
      subjects: <QuestionSubject>[QuestionSubject.history],
      questionCount: 2,
    );
    final QuizResult result = scoringService.evaluate(
      config: config,
      states: <QuizQuestionState>[
        QuizQuestionState(question: qHist1, selectedOptionIndex: 0), // Correct
        QuizQuestionState(question: qHist2, selectedOptionIndex: 0), // Wrong
      ],
      timeTakenSeconds: 45,
      wasAutoSubmitted: false,
    );

    final TestHistoryRecord saved =
        await learningRepository.recordCompletedTest(result);

    final List<TestHistoryRecord> history =
        await learningRepository.getTestHistory();
    expect(history.length, 1);
    expect(history.first.testId, saved.testId);
    expect(history.first.correctCount, 1);
    expect(history.first.incorrectCount, 1);
    expect(history.first.accuracyPercent, 50.0);
    expect(history.first.timeTakenSeconds, 45);

    final TestHistoryRecord? reopened =
        await learningRepository.getTestHistoryById(saved.testId);
    expect(reopened, isNotNull);
    final QuizResult restored = reopened!.toQuizResult();
    expect(restored.reviewItems.length, 2);
    expect(restored.reviewItems[0].outcome, AnswerOutcome.correct);
    expect(restored.reviewItems[1].outcome, AnswerOutcome.incorrect);
    expect(restored.reviewItems[1].question.explanation, qHist2.explanation);
  });

  test('Bookmark add, remove, subject filter, and duplicate prevention work reliably', () async {
    final bool firstAdd = await learningRepository.addBookmark(qHist1);
    final bool duplicateAdd = await learningRepository.addBookmark(qHist1);
    await learningRepository.addBookmark(qGeo1);

    expect(firstAdd, isTrue);
    expect(duplicateAdd, isFalse);
    expect(await learningRepository.isBookmarked(qHist1.id), isTrue);

    final List<ResolvedBookmark> allBookmarks =
        await learningRepository.getResolvedBookmarks();
    expect(allBookmarks.length, 2);

    final List<ResolvedBookmark> geoBookmarks =
        await learningRepository.getResolvedBookmarks(
      subject: QuestionSubject.geography,
    );
    expect(geoBookmarks.length, 1);
    expect(geoBookmarks.first.question.id, qGeo1.id);

    await learningRepository.removeBookmark(qHist1.id);
    expect(await learningRepository.isBookmarked(qHist1.id), isFalse);
    expect((await learningRepository.getResolvedBookmarks()).length, 1);
  });

  test('Wrong answers are collected automatically and marked mastered after correct revision', () async {
    final QuizResult firstAttempt = scoringService.evaluate(
      config: const QuizConfig(
        mode: TestMode.mixedGk,
        subjects: <QuestionSubject>[
          QuestionSubject.history,
          QuestionSubject.geography,
        ],
        questionCount: 2,
      ),
      states: <QuizQuestionState>[
        QuizQuestionState(question: qHist2, selectedOptionIndex: 0), // Wrong (correct=1)
        QuizQuestionState(question: qGeo1, selectedOptionIndex: 2), // Correct
      ],
      timeTakenSeconds: 30,
      wasAutoSubmitted: false,
    );

    await learningRepository.recordCompletedTest(firstAttempt);

    final List<ResolvedWrongAnswer> pendingAfterFirst =
        await learningRepository.getResolvedWrongAnswers();
    expect(pendingAfterFirst.length, 1);
    expect(pendingAfterFirst.first.question.id, qHist2.id);
    expect(pendingAfterFirst.first.record.isMastered, isFalse);
    expect(pendingAfterFirst.first.record.wrongCount, 1);

    // Retry the missed question and answer correctly
    final QuizResult revisionAttempt = scoringService.evaluate(
      config: const QuizConfig(
        mode: TestMode.practice,
        subjects: <QuestionSubject>[QuestionSubject.history],
        questionCount: 1,
      ),
      states: <QuizQuestionState>[
        QuizQuestionState(question: qHist2, selectedOptionIndex: 1), // Correct!
      ],
      timeTakenSeconds: 12,
      wasAutoSubmitted: false,
    );

    await learningRepository.recordCompletedTest(revisionAttempt);

    final List<ResolvedWrongAnswer> pendingAfterRevision =
        await learningRepository.getResolvedWrongAnswers(includeMastered: false);
    expect(pendingAfterRevision, isEmpty);

    final List<ResolvedWrongAnswer> allWithMastered =
        await learningRepository.getResolvedWrongAnswers(includeMastered: true);
    expect(allWithMastered.length, 1);
    expect(allWithMastered.first.record.isMastered, isTrue);
    expect(allWithMastered.first.record.revisionAttempts, 1);
  });

  test('Subject-wise analytics and optional daily goal calculate accurately from real data', () async {
    await learningRepository.saveDailyGoal(
      isEnabled: true,
      dailyQuestionTarget: 5,
    );

    final QuizResult mixedResult = scoringService.evaluate(
      config: const QuizConfig(
        mode: TestMode.mixedGk,
        subjects: <QuestionSubject>[
          QuestionSubject.history,
          QuestionSubject.geography,
          QuestionSubject.mathematics,
        ],
        questionCount: 4,
      ),
      states: <QuizQuestionState>[
        QuizQuestionState(question: qHist1, selectedOptionIndex: 0), // Correct
        QuizQuestionState(question: qHist2, selectedOptionIndex: 0), // Wrong
        QuizQuestionState(question: qGeo1, selectedOptionIndex: 2), // Correct
        QuizQuestionState(question: qMath1, selectedOptionIndex: null), // Skipped
      ],
      timeTakenSeconds: 90,
      wasAutoSubmitted: false,
    );

    await learningRepository.recordCompletedTest(mixedResult);

    final StudentDashboardSummary summary =
        await learningRepository.getDashboardSummary();
    expect(summary.totalTestsAttempted, 1);
    expect(summary.totalQuestionsAttempted, 3);
    expect(summary.totalCorrect, 2);
    expect(summary.totalIncorrect, 1);
    expect(summary.totalUnattempted, 1);
    expect(summary.overallAccuracyPercent, 66.67);
    expect(summary.todayQuestionsAttempted, 3);
    expect(summary.dailyGoal.isEnabled, isTrue);
    expect(summary.dailyGoalProgress, closeTo(0.6, 0.001));
    expect(summary.isDailyGoalMet, isFalse);

    final SubjectAnalytics historyStats = summary.subjectAnalytics.firstWhere(
      (SubjectAnalytics s) => s.subject == QuestionSubject.history,
    );
    expect(historyStats.testsAttempted, 1);
    expect(historyStats.questionsPracticed, 2);
    expect(historyStats.accuracyPercent, 50.0);
    expect(historyStats.needsRevision, isTrue);

    final SubjectAnalytics physicsStats = summary.subjectAnalytics.firstWhere(
      (SubjectAnalytics s) => s.subject == QuestionSubject.physics,
    );
    expect(physicsStats.hasActivity, isFalse);
    expect(physicsStats.accuracyPercent, 0.0);
  });

  test('Persisted learning data survives repository re-initialization (simulated app restart)', () async {
    await learningRepository.addBookmark(qGeo1);
    await learningRepository.saveDailyGoal(
      isEnabled: true,
      dailyQuestionTarget: 20,
    );

    final QuizResult result = scoringService.evaluate(
      config: const QuizConfig(
        mode: TestMode.dailyChallenge,
        subjects: <QuestionSubject>[QuestionSubject.history],
        questionCount: 1,
      ),
      states: <QuizQuestionState>[
        QuizQuestionState(question: qHist1, selectedOptionIndex: 1), // Wrong
      ],
      timeTakenSeconds: 20,
      wasAutoSubmitted: false,
    );
    await learningRepository.recordCompletedTest(result);
    await learningRepository.close();

    // Simulate fresh app restart using the same backing persistence store
    final LearningRepository restartedRepo = LearningRepository(
      dataSource: InMemoryLearningDataSource(store: sharedStore),
      questionRepository: questionRepository,
      clock: () => fakeNow,
    );
    await restartedRepo.initialize();

    final StudentDashboardSummary restoredSummary =
        await restartedRepo.getDashboardSummary();
    expect(restoredSummary.totalTestsAttempted, 1);
    expect(restoredSummary.bookmarksCount, 1);
    expect(restoredSummary.pendingWrongAnswersCount, 1);
    expect(restoredSummary.dailyGoal.isEnabled, isTrue);
    expect(restoredSummary.dailyGoal.dailyQuestionTarget, 20);
  });
}
