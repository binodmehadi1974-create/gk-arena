import 'package:flutter_test/flutter_test.dart';
import 'package:gk_arena/features/account/controllers/account_controller.dart';
import 'package:gk_arena/features/account/models/account_models.dart';
import 'package:gk_arena/features/account/services/auth_service.dart';
import 'package:gk_arena/features/account/services/cloud_backup_service.dart';
import 'package:gk_arena/features/learning/database/in_memory_learning_data_source.dart';
import 'package:gk_arena/features/learning/repositories/learning_repository.dart';
import 'package:gk_arena/features/question_bank/database/in_memory_question_data_source.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/features/quiz/services/quiz_scoring_service.dart';
import 'package:gk_arena/features/settings/controllers/settings_controller.dart';
import 'package:gk_arena/features/settings/database/in_memory_settings_data_source.dart';

Question _makeQuestion(String id) {
  final DateTime now = DateTime.utc(2026, 1, 1);
  return Question(
    id: id,
    questionText: 'Account test question $id?',
    options: const <String>['A', 'B', 'C', 'D'],
    correctOptionIndex: 0,
    explanation: 'Verified explanation $id.',
    subject: QuestionSubject.history,
    topic: 'Modern India',
    subtopic: 'Core',
    difficulty: QuestionDifficulty.medium,
    language: QuestionLanguage.english,
    examCategory: ExamCategory.general,
    questionType: QuestionType.singleChoice,
    sourceReference: 'Unit Test',
    verificationStatus: VerificationStatus.verified,
    createdAt: now,
    updatedAt: now,
  );
}

void main() {
  late QuestionRepository questionRepository;
  late InMemoryLearningStore learningStore;
  late LearningRepository learningRepository;
  late SettingsController settingsController;
  late InMemoryTestAuthService authService;
  late InMemoryCloudBackupDataSource cloudRemote;
  late CloudSyncService syncService;
  late AccountController accountController;
  late Question q1;
  late Question q2;

  setUp(() async {
    questionRepository = QuestionRepository(
      dataSource: InMemoryQuestionDataSource(),
    );
    await questionRepository.initialize();
    q1 = _makeQuestion('q_acc_1');
    q2 = _makeQuestion('q_acc_2');
    await questionRepository.saveBatch(<Question>[q1, q2]);

    learningStore = InMemoryLearningStore();
    learningRepository = LearningRepository(
      dataSource: InMemoryLearningDataSource(store: learningStore),
      questionRepository: questionRepository,
    );
    await learningRepository.initialize();

    settingsController = SettingsController(
      dataSource: InMemorySettingsDataSource(),
      learningRepository: learningRepository,
    );
    await settingsController.initialize();

    authService = InMemoryTestAuthService();
    cloudRemote = InMemoryCloudBackupDataSource();
    syncService = CloudSyncService(
      remoteDataSource: cloudRemote,
      learningRepository: learningRepository,
      settingsController: settingsController,
    );
    accountController = AccountController(
      authService: authService,
      learningRepository: learningRepository,
      settingsController: settingsController,
      cloudSyncService: syncService,
    );
    await accountController.initialize();
  });

  test('UnconfiguredAuthService never fakes sign up or account deletion', () async {
    final UnconfiguredAuthService unconfigured = UnconfiguredAuthService();
    expect(unconfigured.isBackendConfigured, isFalse);

    final AuthActionResult del =
        await unconfigured.requestAccountDeletion(currentPassword: 'any');
    expect(del.success, isFalse);
    expect(del.requiresBackendConfig, isTrue);
  });

  test('Multi-user Sign Up, Login, Logout, and strict per-user data isolation', () async {
    // Guest adds a bookmark before registering
    await learningRepository.addBookmark(q1);
    expect((await learningRepository.getResolvedBookmarks()).length, 1);

    // User A registers and migrates guest data
    final AuthActionResult signUpA = await accountController.signUp(
      displayName: 'Student A',
      email: 'student.a@example.com',
      password: 'Password123!',
      migrateGuestData: true,
    );
    expect(signUpA.success, isTrue);
    expect(accountController.isGuest, isFalse);
    expect((await learningRepository.getResolvedBookmarks()).length, 1);

    // User A logs out -> back to empty Guest Mode
    await accountController.logout();
    expect(accountController.isGuest, isTrue);
    expect(await learningRepository.getResolvedBookmarks(), isEmpty);

    // User B registers separately -> MUST NOT see User A's bookmark
    final AuthActionResult signUpB = await accountController.signUp(
      displayName: 'Student B',
      email: 'student.b@example.com',
      password: 'Password456!',
      migrateGuestData: false,
    );
    expect(signUpB.success, isTrue);
    expect(await learningRepository.getResolvedBookmarks(), isEmpty);

    // User B adds q2 bookmark
    await learningRepository.addBookmark(q2);
    expect((await learningRepository.getResolvedBookmarks()).first.question.id, q2.id);

    // Switch back to User A -> sees only q1, never q2
    await accountController.logout();
    final AuthActionResult loginA = await accountController.login(
      email: 'student.a@example.com',
      password: 'Password123!',
    );
    expect(loginA.success, isTrue);
    final bookmarksA = await learningRepository.getResolvedBookmarks();
    expect(bookmarksA.length, 1);
    expect(bookmarksA.first.question.id, q1.id);
  });

  test('Cloud remote authorization rejects cross-user access attempts', () async {
    await accountController.signUp(
      displayName: 'Student A',
      email: 'auth.a@example.com',
      password: 'Password123!',
    );
    final String uidA = accountController.activeUser.uid;
    await accountController.syncNow();

    expect(
      () => cloudRemote.downloadBackup(
        requestingUid: 'uid_intruder',
        targetUid: uidA,
      ),
      throwsStateError,
    );
  });

  test('Offline queueing, cross-device restore, and deduplication work safely', () async {
    await accountController.signUp(
      displayName: 'Sync Student',
      email: 'sync@example.com',
      password: 'Password123!',
    );
    final String uid = accountController.activeUser.uid;

    await learningRepository.addBookmark(q1);
    const QuizScoringService scoringService = QuizScoringService();
    final QuizResult result = scoringService.evaluate(
      config: const QuizConfig(
        mode: TestMode.practice,
        subjects: <QuestionSubject>[QuestionSubject.history],
        questionCount: 1,
      ),
      states: <QuizQuestionState>[
        QuizQuestionState(question: q1, selectedOptionIndex: 0),
      ],
      timeTakenSeconds: 10,
      wasAutoSubmitted: false,
    );
    await learningRepository.recordCompletedTest(result, customTestId: 't_sync_1');

    // Simulate offline -> sync queues safely
    cloudRemote.isOnline = false;
    syncService.markLocalChangePending();
    final SyncMergeReport? offlineReport = await accountController.syncNow();
    expect(offlineReport, isNull);
    expect(syncService.status.state, SyncStatusState.offlineQueued);

    // Back online -> sync uploads
    cloudRemote.isOnline = true;
    final SyncMergeReport? onlineReport = await accountController.syncNow();
    expect(onlineReport, isNotNull);
    expect(syncService.status.state, SyncStatusState.synced);

    // Simulate second device with empty local store restoring user's backup
    final LearningRepository device2Learning = LearningRepository(
      dataSource: InMemoryLearningDataSource(initialUserId: uid),
      questionRepository: questionRepository,
    );
    await device2Learning.initialize();

    final CloudSyncService device2Sync = CloudSyncService(
      remoteDataSource: cloudRemote,
      learningRepository: device2Learning,
      settingsController: settingsController,
    );
    final SyncMergeReport? restored =
        await device2Sync.syncNow(accountController.activeUser);
    expect(restored, isNotNull);
    expect(restored!.restoredRecords, greaterThanOrEqualTo(2));
    expect((await device2Learning.getTestHistory()).length, 1);
    expect((await device2Learning.getResolvedBookmarks()).length, 1);

    // Syncing again skips duplicates without creating extra records
    final SyncMergeReport? secondSync =
        await device2Sync.syncNow(accountController.activeUser);
    expect(secondSync, isNotNull);
    expect((await device2Learning.getTestHistory()).length, 1);
    expect((await device2Learning.getResolvedBookmarks()).length, 1);
  });
}
