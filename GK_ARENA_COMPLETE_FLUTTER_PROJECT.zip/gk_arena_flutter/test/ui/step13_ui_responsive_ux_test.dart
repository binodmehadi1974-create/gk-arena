import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:gk_arena/features/quiz/services/quiz_environment.dart';
import 'package:gk_arena/features/settings/models/app_settings.dart';
import 'package:gk_arena/main.dart';
import 'package:gk_arena/ui/design_system/app_theme.dart';
import 'package:gk_arena/ui/widgets/state_views.dart';

void main() {
  testWidgets('GkArenaApp renders cleanly on compact 320x640 Android viewport with 1.3x text scale and Dark Theme',
      (WidgetTester tester) async {
    tester.view.physicalSize = const Size(320, 640);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    final QuizEnvironment env = QuizEnvironment();
    await env.ensureInitialized(loadDemoIfEmpty: false);
    await env.settingsController.setThemePreference(AppThemePreference.dark);

    await tester.pumpWidget(
      MediaQuery(
        data: const MediaQueryData(
          size: Size(320, 640),
          textScaler: TextScaler.linear(1.3),
        ),
        child: GkArenaApp(quizEnvironment: env),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('GK ARENA'), findsOneWidget);
    expect(tester.takeException(), isNull);

    // Switch tabs on compact viewport
    await tester.tap(find.text('प्रोफ़ाइल'));
    await tester.pumpAndSettle();
    expect(find.text('मेरी प्रोफ़ाइल'), findsOneWidget);
    expect(tester.takeException(), isNull);

    await env.dispose();
  });

  testWidgets('GkErrorRetryCard displays error message and triggers retry callback in Dark Theme',
      (WidgetTester tester) async {
    int retryCount = 0;

    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.darkTheme,
        home: Scaffold(
          body: GkErrorRetryCard(
            title: 'Connection Error',
            message: 'Unable to load records.',
            retryLabel: 'Retry Now',
            onRetry: () => retryCount++,
          ),
        ),
      ),
    );

    expect(find.text('Connection Error'), findsOneWidget);
    expect(find.text('Unable to load records.'), findsOneWidget);

    await tester.tap(find.text('Retry Now'));
    await tester.pump();
    expect(retryCount, 1);
  });
}
