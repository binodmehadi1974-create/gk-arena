import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:gk_arena/features/question_bank/database/in_memory_question_data_source.dart';
import 'package:gk_arena/features/question_bank/importers/question_batch_importer.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';
import 'package:gk_arena/features/quiz/controllers/quiz_session_controller.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/features/quiz/services/quiz_question_loader.dart';
import 'package:gk_arena/features/quiz/services/quiz_scoring_service.dart';
import 'package:gk_arena/features/quiz/services/recent_question_tracker.dart';

void main() {
  late QuestionRepository repository;
  late RecentQuestionTracker tracker;
  late QuizQuestionLoader loader;
  const QuizScoringService scoringService = QuizScoringService();

  setUp(() async {
    repository = QuestionRepository(dataSource: InMemoryQuestionDataSource());
    await repository.initialize();
    tracker = RecentQuestionTracker(maxHistorySize: 50);
    loader = QuizQuestionLoader(
      repository: repository,
      recentTracker: tracker,
    );
  });

  tearDown(() async {
    await repository.close();
  });

  Future<void> seedDemoQuestions() async {
    final String rawJson =
        await File('assets/sample_data/demo_sample_questions.json')
            .readAsString();
    final QuestionBatchImporter importer =
        QuestionBatchImporter(repository: repository);
    await importer.importFromJsonString(rawJson);
  }

  group('Question Loading — Empty Bank & Insufficient Count', () {
    test('returns emptyBank when question bank has zero questions', () async {
      final QuizLoadResult res = await loader.loadForConfig(
        const QuizConfig(mode: TestMode.mixedGk, questionCount: 5),
      );
      expect(res.status, QuizLoadStatus.emptyBank);
      expect(res.questions, isEmpty);
    });

    test('returns insufficientQuestions when fewer questions match than requested', () async {
      await seedDemoQuestions();
      final QuizLoadResult res = await loader.loadForConfig(
        const QuizConfig(
          mode: TestMode.subjectWise,
          subjects: <QuestionSubject>[QuestionSubject.chemistry],
          questionCount: 5,
        ),
      );
      expect(res.status, QuizLoadStatus.insufficientQuestions);
      expect(res.availableCount, 1);
      expect(res.canStartPartial, isTrue);
    });
  });

  group('QuizSessionController — Selection, Navigation, Timer, Auto-Submit & Scoring', () {
    test('supports selection, answer change, clear, mark for review, navigation, negative marking, and duplicate submit guard', () async {
      await seedDemoQuestions();
      final QuizLoadResult loaded = await loader.loadForConfig(
        const QuizConfig(
          mode: TestMode.timed,
          questionCount: 4,
          durationSeconds: 120,
          scoringRules: ScoringRules.negativeQuarter,
        ),
      );
      expect(loaded.status, QuizLoadStatus.ready);
      final List<Question> qs = loaded.questions;

      final QuizSessionController controller = QuizSessionController(
        config: const QuizConfig(
          mode: TestMode.timed,
          questionCount: 4,
          durationSeconds: 120,
          scoringRules: ScoringRules.negativeQuarter,
        ),
        questions: qs,
        scoringService: scoringService,
        recentTracker: tracker,
      );

      // Q1: select wrong then change to correct
      final int q0Correct = qs[0].correctOptionIndex;
      controller.selectOption((q0Correct + 1) % 4);
      controller.selectOption(q0Correct);
      controller.toggleMarkForReview();
      expect(controller.currentState.isMarkedForReview, isTrue);

      // Q2: select wrong
      controller.nextQuestion();
      expect(controller.currentIndex, 1);
      controller.selectOption((qs[1].correctOptionIndex + 1) % 4);

      // Q3: select then clear -> unattempted
      controller.nextQuestion();
      controller.selectOption(0);
      controller.clearAnswer();
      expect(controller.currentState.isAnswered, isFalse);

      // Q4: jump directly and answer correctly
      controller.jumpToQuestion(3);
      controller.selectOption(qs[3].correctOptionIndex);

      // Previous navigation check
      controller.previousQuestion();
      expect(controller.currentIndex, 2);

      // Tick 10 seconds
      for (int i = 0; i < 10; i++) {
        controller.tickOneSecond();
      }
      expect(controller.elapsedSeconds, 10);
      expect(controller.remainingSeconds, 110);

      // Manual submit + duplicate-submission protection
      final QuizResult firstSubmit = controller.submit(autoSubmitted: false);
      final QuizResult duplicateSubmit = controller.submit(autoSubmitted: true);
      expect(identical(firstSubmit, duplicateSubmit), isTrue);

      // Expected: 2 correct (+2.0), 1 incorrect (-0.25), 1 unattempted (0) -> 1.75 / 4.0
      expect(firstSubmit.correctCount, 2);
      expect(firstSubmit.incorrectCount, 1);
      expect(firstSubmit.unattemptedCount, 1);
      expect(firstSubmit.totalScore, 1.75);
      expect(firstSubmit.maxScore, 4.0);
      expect(firstSubmit.accuracyPercent, 66.7);
      expect(firstSubmit.wasAutoSubmitted, isFalse);
      expect(firstSubmit.reviewItems.length, 4);
      expect(firstSubmit.reviewItems[0].outcome, AnswerOutcome.correct);
      expect(firstSubmit.reviewItems[1].outcome, AnswerOutcome.incorrect);
      expect(firstSubmit.reviewItems[2].outcome, AnswerOutcome.unattempted);

      controller.dispose();
    });

    test('auto-submits automatically when timer reaches zero', () async {
      await seedDemoQuestions();
      final QuizLoadResult loaded = await loader.loadForConfig(
        const QuizConfig(
          mode: TestMode.timed,
          questionCount: 2,
          durationSeconds: 3,
        ),
      );
      QuizResult? callbackResult;
      final QuizSessionController controller = QuizSessionController(
        config: const QuizConfig(
          mode: TestMode.timed,
          questionCount: 2,
          durationSeconds: 3,
        ),
        questions: loaded.questions,
        scoringService: scoringService,
        recentTracker: tracker,
        onSubmitted: (QuizResult r) => callbackResult = r,
      );

      controller.tickOneSecond();
      controller.tickOneSecond();
      expect(controller.isSubmitted, isFalse);
      controller.tickOneSecond();

      expect(controller.isSubmitted, isTrue);
      expect(controller.remainingSeconds, 0);
      expect(callbackResult, isNotNull);
      expect(callbackResult!.wasAutoSubmitted, isTrue);

      controller.dispose();
    });

    test('pauses timer during interruption and restores state cleanly from snapshot', () async {
      await seedDemoQuestions();
      final QuizLoadResult loaded = await loader.loadForConfig(
        const QuizConfig(
          mode: TestMode.timed,
          questionCount: 3,
          durationSeconds: 60,
        ),
      );
      final QuizSessionController original = QuizSessionController(
        config: const QuizConfig(
          mode: TestMode.timed,
          questionCount: 3,
          durationSeconds: 60,
        ),
        questions: loaded.questions,
        scoringService: scoringService,
        recentTracker: tracker,
      );

      original.selectOption(2);
      original.nextQuestion();
      original.toggleMarkForReview();
      original.tickOneSecond();
      original.pauseTimer();
      original.tickOneSecond(); // Ignored while paused
      expect(original.elapsedSeconds, 1);

      final Map<String, Object?> serialized =
          original.exportSnapshot().toJson();
      original.dispose();

      final QuizSessionController restored = QuizSessionController(
        config: const QuizConfig(
          mode: TestMode.timed,
          questionCount: 3,
          durationSeconds: 60,
        ),
        questions: loaded.questions,
        scoringService: scoringService,
        recentTracker: tracker,
      );
      restored.restoreFromSnapshot(QuizSessionSnapshot.fromJson(serialized));

      expect(restored.currentIndex, 1);
      expect(restored.states[0].selectedOptionIndex, 2);
      expect(restored.states[1].isMarkedForReview, isTrue);
      expect(restored.remainingSeconds, 59);
      restored.dispose();
    });
  });

  group('No-Repeat & Revision Mode Logic', () {
    test('avoids recently answered questions when alternatives exist, but allows revision repeats', () async {
      await seedDemoQuestions();
      final QuizLoadResult first = await loader.loadForConfig(
        const QuizConfig(
          mode: TestMode.practice,
          questionCount: 5,
          allowRepeatRecent: false,
        ),
      );
      tracker.recordAnswered(first.questions.map((Question q) => q.id));

      final QuizLoadResult second = await loader.loadForConfig(
        const QuizConfig(
          mode: TestMode.practice,
          questionCount: 5,
          allowRepeatRecent: false,
        ),
      );
      final Set<String> firstIds = first.questions.map((Question q) => q.id).toSet();
      final Set<String> secondIds = second.questions.map((Question q) => q.id).toSet();
      expect(firstIds.intersection(secondIds), isEmpty);

      // Revision mode intentionally allows repeating previous questions
      final QuizLoadResult revision = await loader.loadForConfig(
        const QuizConfig(
          mode: TestMode.practice,
          questionCount: 5,
          allowRepeatRecent: true,
        ),
      );
      expect(revision.questions.map((Question q) => q.id).toSet(), firstIds);
    });
  });
}
