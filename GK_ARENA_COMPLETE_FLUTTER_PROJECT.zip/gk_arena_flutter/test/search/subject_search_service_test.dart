import 'package:flutter_test/flutter_test.dart';
import 'package:gk_arena/features/search/data/subject_search_catalog.dart';
import 'package:gk_arena/features/search/models/search_models.dart';
import 'package:gk_arena/features/search/services/subject_search_service.dart';

void main() {
  const SubjectSearchService service = SubjectSearchService();

  group('SubjectSearchService — Bilingual Hindi & English Search', () {
    test('empty input returns the 10 default Explore directory subjects', () {
      final SubjectSearchResult result = service.search(query: '');
      expect(result.hasActiveQuery, isFalse);
      expect(result.count, 10);
    });

    test('whitespace-only input behaves as empty input', () {
      final SubjectSearchResult result = service.search(query: '    ');
      expect(result.hasActiveQuery, isFalse);
      expect(result.count, 10);
    });

    test('matches Hindi subject names accurately', () {
      expect(service.search(query: 'इतिहास').entries.first.id, 'history');
      expect(service.search(query: 'भूगोल').entries.first.id, 'geography');
      expect(service.search(query: 'गणित').entries.first.id, 'mathematics');
      expect(service.search(query: 'विज्ञान').entries.first.id, 'general_science');
      expect(
        service.search(query: 'राजनीति विज्ञान').entries.first.id,
        'political_science',
      );
      expect(service.search(query: 'रसायन विज्ञान').entries.first.id, 'chemistry');
      expect(service.search(query: 'जीव विज्ञान').entries.first.id, 'biology');
    });

    test('matches English names case-insensitively including Chemistry & Biology', () {
      expect(service.search(query: 'HISTORY').entries.first.id, 'history');
      expect(service.search(query: 'chemistry').entries.first.id, 'chemistry');
      expect(service.search(query: 'BiOlOgY').entries.first.id, 'biology');
      expect(service.search(query: 'STATIC GK').entries.first.id, 'static_gk');
      expect(
        service.search(query: 'current affairs').entries.first.id,
        'current_affairs',
      );
    });

    test('handles extra leading, trailing, and internal spaces', () {
      final SubjectSearchResult hindiResult =
          service.search(query: '   राजनीति    विज्ञान   ');
      expect(hindiResult.entries.first.id, 'political_science');

      final SubjectSearchResult englishResult =
          service.search(query: '  general   science  ');
      expect(englishResult.entries.first.id, 'general_science');
    });

    test('supports partial matches in English and Hindi', () {
      expect(service.search(query: 'geo').entries.first.id, 'geography');
      expect(service.search(query: 'econ').entries.first.id, 'economics');
      expect(service.search(query: 'अर्थ').entries.first.id, 'economics');
      expect(service.search(query: 'तार्किक').entries.first.id, 'reasoning');
      expect(service.search(query: 'phys').entries.first.id, 'physics');
    });

    test('combines search query with category filter', () {
      final SubjectSearchResult result = service.search(
        query: 'विज्ञान',
        category: SubjectSearchCatalog.categoryScience,
      );
      expect(result.entries.every((SearchSubjectEntry e) => e.category == SubjectSearchCatalog.categoryScience), isTrue);
      expect(result.entries.first.id, 'general_science');
    });

    test('returns empty result for unmatched query', () {
      final SubjectSearchResult result = service.search(query: 'xyz_unknown_999');
      expect(result.hasActiveQuery, isTrue);
      expect(result.isEmpty, isTrue);
      expect(result.entries, isEmpty);
    });
  });
}
