import 'package:flutter_test/flutter_test.dart';
import 'package:gk_arena/features/account/services/cloud_backup_service.dart';
import 'package:gk_arena/features/learning/database/in_memory_learning_data_source.dart';
import 'package:gk_arena/features/learning/repositories/learning_repository.dart';
import 'package:gk_arena/features/offline/offline_support_service.dart';
import 'package:gk_arena/features/question_bank/database/in_memory_question_data_source.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/features/quiz/services/quiz_question_loader.dart';
import 'package:gk_arena/features/quiz/services/recent_question_tracker.dart';
import 'package:gk_arena/features/settings/controllers/settings_controller.dart';
import 'package:gk_arena/features/settings/database/in_memory_settings_data_source.dart';

Question _syntheticQuestion(
  int index, {
  PublicationStatus pubStatus = PublicationStatus.published,
}) {
  final QuestionSubject subject =
      QuestionSubject.values[index % QuestionSubject.values.length];
  final QuestionLanguage lang =
      index.isEven ? QuestionLanguage.hindi : QuestionLanguage.english;
  final QuestionDifficulty diff =
      QuestionDifficulty.values[index % QuestionDifficulty.values.length];
  final DateTime now = DateTime.utc(2026, 1, 1);

  return Question(
    id: 'syn_${index.toString().padLeft(6, '0')}',
    questionText: 'Synthetic performance test question #$index for ${subject.titleEn}?',
    options: const <String>['Opt A', 'Opt B', 'Opt C', 'Opt D'],
    correctOptionIndex: index % 4,
    explanation: 'Synthetic explanation #$index.',
    subject: subject,
    topic: '${subject.titleEn} Topic ${index % 10}',
    subtopic: 'Subtopic ${index % 5}',
    difficulty: diff,
    language: lang,
    examCategory: ExamCategory.general,
    questionType: QuestionType.singleChoice,
    sourceReference: 'Synthetic Test Fixture',
    verificationStatus: VerificationStatus.unverified,
    publicationStatus: pubStatus,
    createdAt: now,
    updatedAt: now,
  );
}

void main() {
  late QuestionRepository questionRepository;
  late LearningRepository learningRepository;
  late SettingsController settingsController;
  late CloudSyncService cloudSyncService;
  late OfflineSupportService offlineService;
  late QuizQuestionLoader loader;

  setUp(() async {
    questionRepository = QuestionRepository(
      dataSource: InMemoryQuestionDataSource(),
    );
    await questionRepository.initialize();

    learningRepository = LearningRepository(
      dataSource: InMemoryLearningDataSource(),
      questionRepository: questionRepository,
    );
    await learningRepository.initialize();

    settingsController = SettingsController(
      dataSource: InMemorySettingsDataSource(),
      learningRepository: learningRepository,
    );
    await settingsController.initialize();

    cloudSyncService = CloudSyncService(
      remoteDataSource: UnconfiguredCloudBackupDataSource(),
      learningRepository: learningRepository,
      settingsController: settingsController,
    );

    offlineService = OfflineSupportService(
      questionRepository: questionRepository,
      cloudSyncService: cloudSyncService,
    );

    loader = QuizQuestionLoader(
      repository: questionRepository,
      recentTracker: RecentQuestionTracker(),
    );
  });

  test('Bounded quiz loading, distinct topics, batched lookups, and pagination handle 5,000 synthetic MCQs cleanly', () async {
    final List<Question> syntheticBatch = List<Question>.generate(
      5000,
      (int i) => _syntheticQuestion(
        i,
        // Keep last 50 as Drafts to verify student quizzes exclude unpublished items
        pubStatus: i >= 4950
            ? PublicationStatus.draft
            : PublicationStatus.published,
      ),
    );

    final BatchImportReport report =
        await questionRepository.saveBatch(syntheticBatch);
    expect(report.insertedCount, 5000);

    // 1. Distinct topics query returns sorted unique topics without loading all MCQs
    final List<String> historyTopics = await loader.getAvailableTopics(
      subject: QuestionSubject.history,
    );
    expect(historyTopics, isNotEmpty);

    // 2. Bounded candidate pool returns exactly requested count and only published questions
    final QuizLoadResult quiz = await loader.loadForConfig(
      const QuizConfig(
        mode: TestMode.subjectWise,
        subjects: <QuestionSubject>[QuestionSubject.history],
        questionCount: 20,
      ),
    );
    expect(quiz.status, QuizLoadStatus.ready);
    expect(quiz.questions.length, 20);
    expect(
      quiz.questions.every(
        (Question q) => q.publicationStatus == PublicationStatus.published,
      ),
      isTrue,
    );

    // 3. Batched getByIds resolves multiple bookmarks in one call
    final Map<String, Question> batchLookup = await questionRepository.getByIds(
      <String>['syn_000001', 'syn_000100', 'syn_004000'],
    );
    expect(batchLookup.length, 3);

    // 4. Paginated query returns exact window
    final List<Question> page5 = await questionRepository.query(
      const QuestionFilter(
        subject: QuestionSubject.geography,
        limit: 25,
        offset: 100,
      ),
    );
    expect(page5.length, 25);
  });

  test('OfflineSupportService reports real local published questions and honest unconfigured sync state', () async {
    await questionRepository.saveBatch(<Question>[
      _syntheticQuestion(1, pubStatus: PublicationStatus.published),
      _syntheticQuestion(2, pubStatus: PublicationStatus.draft),
    ]);

    final OfflineAvailabilitySummary summary =
        await offlineService.getAvailabilitySummary();
    expect(summary.totalPublishedOfflineQuestions, 1);
    expect(summary.isOfflineReady, isTrue);
    expect(summary.cloudSyncConfigured, isFalse);
    expect(summary.connectivityStatus, ConnectivityStatus.offlineLocalOnly);
  });
}
