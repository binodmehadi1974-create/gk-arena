import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:gk_arena/features/admin/models/admin_models.dart';
import 'package:gk_arena/features/admin/repositories/admin_repository.dart';
import 'package:gk_arena/features/admin/services/admin_access_service.dart';
import 'package:gk_arena/features/question_bank/database/in_memory_question_data_source.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';
import 'package:gk_arena/features/question_bank/services/content_intelligence_service.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/features/quiz/services/quiz_question_loader.dart';
import 'package:gk_arena/features/quiz/services/recent_question_tracker.dart';

Question _bilingualQuestion({
  required String id,
  required QuestionSubject subject,
  required String chapter,
  required String topic,
  required String textHi,
  String? textEn,
  List<String>? optionsHi,
  List<String>? optionsEn,
  String? explanationHi,
  String? explanationEn,
  List<String> tags = const <String>[],
  VerificationStatus verification = VerificationStatus.pendingReview,
}) {
  final DateTime now = DateTime.utc(2026, 11, 23);
  final List<String> opts = optionsHi ??
      const <String>['विकल्प A', 'विकल्प B', 'विकल्प C', 'विकल्प D'];
  return Question(
    id: id,
    questionText: textHi,
    options: opts,
    correctOptionIndex: 0,
    explanation: explanationHi ?? 'व्याख्या $id',
    subject: subject,
    chapter: chapter,
    topic: topic,
    subtopic: 'Core',
    difficulty: QuestionDifficulty.easy,
    language: QuestionLanguage.hindi,
    examCategory: ExamCategory.general,
    questionType: QuestionType.singleChoice,
    sourceReference: 'NCERT Reference',
    verificationStatus: verification,
    publicationStatus: PublicationStatus.published,
    createdAt: now,
    updatedAt: now,
    questionTextHi: textHi,
    questionTextEn: textEn,
    optionsHi: opts,
    optionsEn: optionsEn,
    explanationHi: explanationHi ?? 'व्याख्या $id',
    explanationEn: explanationEn,
    tags: tags,
  );
}

void main() {
  late QuestionRepository questionRepository;
  late AdminRepository adminRepository;
  late QuizQuestionLoader quizLoader;

  const AdminSession adminSession = AdminSession(
    uid: 'admin_ci',
    displayName: 'Content Admin',
    role: UserRole.admin,
    isBackendAuthorized: true,
  );
  const AdminSession studentSession = AdminSession(
    uid: 'student_ci',
    displayName: 'Student',
    role: UserRole.student,
    isBackendAuthorized: true,
  );

  setUp(() async {
    questionRepository = QuestionRepository(
      dataSource: InMemoryQuestionDataSource(),
    );
    await questionRepository.initialize();

    adminRepository = AdminRepository(
      questionRepository: questionRepository,
      accessService: InMemoryTestAdminAccessService(),
    );

    quizLoader = QuizQuestionLoader(
      repository: questionRepository,
      recentTracker: RecentQuestionTracker(),
    );
  });

  test('Bilingual display returns requested language and falls back safely when translation is missing', () {
    final Question fullBilingual = _bilingualQuestion(
      id: 'ci_1',
      subject: QuestionSubject.history,
      chapter: 'Ancient India',
      topic: 'Maurya Empire',
      textHi: 'अर्थशास्त्र के लेखक कौन हैं?',
      textEn: 'Who authored Arthashastra?',
      optionsHi: const <String>['कौटिल्य', 'मेगस्थनीज', 'कालिदास', 'बाणभट्ट'],
      optionsEn: const <String>['Kautilya', 'Megasthenes', 'Kalidasa', 'Banabhatta'],
      explanationHi: 'कौटिल्य ने अर्थशास्त्र लिखा।',
      explanationEn: 'Kautilya authored Arthashastra.',
    );

    expect(fullBilingual.displayQuestionText(QuestionLanguage.hindi), 'अर्थशास्त्र के लेखक कौन हैं?');
    expect(fullBilingual.displayQuestionText(QuestionLanguage.english), 'Who authored Arthashastra?');
    expect(fullBilingual.displayOptions(QuestionLanguage.english).first, 'Kautilya');
    expect(fullBilingual.displayExplanation(QuestionLanguage.english), 'Kautilya authored Arthashastra.');

    // Missing English translation falls back cleanly to Hindi without empty/broken strings
    final Question hindiOnly = _bilingualQuestion(
      id: 'ci_2',
      subject: QuestionSubject.geography,
      chapter: 'Rivers',
      topic: 'Ganga',
      textHi: 'दक्षिण गंगा किस नदी को कहते हैं?',
      textEn: null,
      optionsEn: null,
      explanationEn: null,
    );
    expect(hindiOnly.displayQuestionText(QuestionLanguage.english), 'दक्षिण गंगा किस नदी को कहते हैं?');
    expect(hindiOnly.displayOptions(QuestionLanguage.english).length, 4);
    expect(hindiOnly.displayExplanation(QuestionLanguage.english), isNotEmpty);
  });

  test('Flexible subject taxonomy supports all 12 subjects plus dynamic future subjects', () {
    final SubjectTaxonomyRegistry registry = SubjectTaxonomyRegistry();
    expect(registry.allSubjects.length, 12);
    expect(registry.containsSubject('history'), isTrue);
    expect(registry.containsSubject('current_affairs'), isTrue);

    registry.registerSubject(
      const SubjectTaxonomyEntry(
        id: 'computer_awareness',
        titleEn: 'Computer Awareness',
        titleHi: 'कंप्यूटर ज्ञान',
        chapters: <String>['Hardware', 'Networking'],
      ),
    );
    expect(registry.allSubjects.length, 13);
    expect(registry.containsSubject('computer_awareness'), isTrue);
  });

  test('Quality controller detects duplicate options, missing source/chapter, and preserves verification status', () {
    const QuestionQualityController qc = QuestionQualityController();
    final Question badOpts = _bilingualQuestion(
      id: 'ci_bad',
      subject: QuestionSubject.physics,
      chapter: '',
      topic: 'Units',
      textHi: 'बल का SI मात्रक क्या है?',
      textEn: 'What is the SI unit of Force?',
      optionsEn: const <String>['Newton', 'Newton', 'Watt', 'Joule'],
    );
    final QuestionQualityReport report = qc.inspect(badOpts);
    expect(report.isTechnicallyValid, isFalse);
    expect(report.errors.any((String e) => e.contains('Duplicate English option')), isTrue);
    expect(report.warnings.any((String w) => w.contains('Chapter')), isTrue);
  });

  test('Search engine filters by chapter, keyword, tags, and verification status with pagination', () async {
    await questionRepository.saveBatch(<Question>[
      _bilingualQuestion(
        id: 'srch_1',
        subject: QuestionSubject.history,
        chapter: 'Ancient India',
        topic: 'Maurya Empire',
        textHi: 'अर्थशास्त्र के लेखक कौन हैं?',
        textEn: 'Who authored Arthashastra?',
        tags: const <String>['kautilya', 'maurya'],
        verification: VerificationStatus.verified,
      ),
      _bilingualQuestion(
        id: 'srch_2',
        subject: QuestionSubject.history,
        chapter: 'Modern India',
        topic: '1857 Revolt',
        textHi: '1857 की क्रांति कहाँ से शुरू हुई?',
        textEn: 'Where did the 1857 Revolt begin?',
        tags: const <String>['meerut', 'revolt'],
        verification: VerificationStatus.pendingReview,
      ),
    ]);

    final List<Question> byChapter = await questionRepository.query(
      const QuestionFilter(chapter: 'Ancient India'),
    );
    expect(byChapter.length, 1);
    expect(byChapter.first.id, 'srch_1');

    final List<Question> byTagKeyword = await questionRepository.query(
      const QuestionFilter(keyword: 'meerut', limit: 10, offset: 0),
    );
    expect(byTagKeyword.length, 1);
    expect(byTagKeyword.first.id, 'srch_2');

    final List<Question> byVerification = await questionRepository.query(
      const QuestionFilter(verificationStatus: VerificationStatus.verified),
    );
    expect(byVerification.length, 1);
    expect(byVerification.first.id, 'srch_1');
  });

  test('Admin JSON export/import round-trip works and students cannot export/modify official questions', () async {
    await questionRepository.saveQuestion(
      _bilingualQuestion(
        id: 'exp_1',
        subject: QuestionSubject.physics,
        chapter: 'Motion',
        topic: 'SI Units',
        textHi: 'बल का मात्रक क्या है?',
        textEn: 'What is the SI unit of Force?',
        tags: const <String>['newton'],
      ),
    );

    expect(
      () => adminRepository.exportQuestionsJson(session: studentSession),
      throwsA(isA<AdminAuthorizationException>()),
    );

    final String exported = await adminRepository.exportQuestionsJson(
      session: adminSession,
    );
    final Map<String, dynamic> decoded =
        jsonDecode(exported) as Map<String, dynamic>;
    expect(decoded['schema_version'], 3);
    expect(decoded['count'], 1);

    // Quiz Engine retrieves bilingual question seamlessly
    final QuizLoadResult loaded = await quizLoader.loadForConfig(
      const QuizConfig(
        mode: TestMode.subjectWise,
        subjects: <QuestionSubject>[QuestionSubject.physics],
        questionCount: 1,
      ),
    );
    expect(loaded.status, QuizLoadStatus.ready);
    expect(loaded.questions.first.id, 'exp_1');
  });
}
