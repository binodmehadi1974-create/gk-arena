import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:gk_arena/features/question_bank/database/in_memory_question_data_source.dart';
import 'package:gk_arena/features/question_bank/importers/question_batch_importer.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';
import 'package:gk_arena/features/question_bank/validation/question_validator.dart';

void main() {
  late QuestionRepository repository;

  setUp(() async {
    repository = QuestionRepository(
      dataSource: InMemoryQuestionDataSource(),
    );
    await repository.initialize();
  });

  tearDown(() async {
    await repository.close();
  });

  Question buildSample({
    String id = 'TEST_001',
    String text = 'What is the capital of India?',
    List<String> options = const <String>['Mumbai', 'New Delhi', 'Kolkata', 'Chennai'],
    int correctIndex = 1,
    QuestionSubject subject = QuestionSubject.geography,
    String topic = 'Indian Geography',
    String subtopic = 'Capitals',
    QuestionDifficulty difficulty = QuestionDifficulty.easy,
    QuestionLanguage language = QuestionLanguage.english,
  }) {
    final DateTime now = DateTime.utc(2026, 11, 23);
    return Question(
      id: id,
      questionText: text,
      options: options,
      correctOptionIndex: correctIndex,
      explanation: 'New Delhi is the capital of India.',
      subject: subject,
      topic: topic,
      subtopic: subtopic,
      difficulty: difficulty,
      language: language,
      examCategory: ExamCategory.general,
      questionType: QuestionType.singleChoice,
      sourceReference: 'Unit test sample — unverified',
      verificationStatus: VerificationStatus.demoUnverified,
      createdAt: now,
      updatedAt: now,
      isSample: true,
    );
  }

  group('QuestionValidator', () {
    test('accepts a valid Question record', () {
      final QuestionValidationResult result =
          repository.validateQuestion(buildSample());
      expect(result.isValid, isTrue);
      expect(result.errors, isEmpty);
    });

    test('rejects invalid option count, duplicate options, and out-of-range answer', () {
      final Question invalid = buildSample(
        id: '',
        text: 'Hi?',
        options: const <String>['A', 'a', 'B'],
        correctIndex: 5,
      );
      final QuestionValidationResult result =
          repository.validateQuestion(invalid);
      expect(result.isValid, isFalse);
      expect(result.errors.length, greaterThanOrEqualTo(4));
    });
  });

  group('Unique IDs & Duplicate Detection', () {
    test('prevents duplicate question IDs', () async {
      final QuestionSaveResult first = await repository.saveQuestion(buildSample(id: 'DUP_1'));
      final QuestionSaveResult second = await repository.saveQuestion(
        buildSample(id: 'DUP_1', text: 'A completely different question text?'),
      );
      expect(first.saved, isTrue);
      expect(second.saved, isFalse);
      expect(second.isDuplicate, isTrue);
    });

    test('detects duplicates using normalized text (case, extra spaces, trailing punctuation)', () async {
      await repository.saveQuestion(
        buildSample(id: 'NORM_1', text: 'What is the capital of India?'),
      );

      expect(
        await repository.isDuplicateQuestion(
          '  what   is the CAPITAL of india  ',
          language: QuestionLanguage.english,
        ),
        isTrue,
      );

      final QuestionSaveResult dup = await repository.saveQuestion(
        buildSample(id: 'NORM_2', text: '  WHAT   is the capital of India.'),
      );
      expect(dup.saved, isFalse);
      expect(dup.isDuplicate, isTrue);
    });
  });

  group('Demo Sample JSON Import & Query Filters', () {
    test('imports all 20 separated demo_unverified sample MCQs and supports all filters', () async {
      final String rawJson =
          await File('assets/sample_data/demo_sample_questions.json')
              .readAsString();
      final QuestionBatchImporter importer =
          QuestionBatchImporter(repository: repository);
      final BatchImportReport report =
          await importer.importFromJsonString(rawJson);

      expect(report.totalReceived, 20);
      expect(report.insertedCount, 20);
      expect(report.duplicateCount, 0);
      expect(report.invalidCount, 0);

      // Re-importing the exact same batch should skip all 20 as duplicates
      final BatchImportReport secondRun =
          await importer.importFromJsonString(rawJson);
      expect(secondRun.insertedCount, 0);
      expect(secondRun.duplicateCount, 20);

      // Subject-wise retrieval
      final List<Question> history =
          await repository.getBySubject(QuestionSubject.history);
      expect(history.length, 2);

      final List<Question> chemistry =
          await repository.getBySubject(QuestionSubject.chemistry);
      expect(chemistry.length, 1);

      // Language filtering
      final List<Question> hindi =
          await repository.getByLanguage(QuestionLanguage.hindi);
      final List<Question> english =
          await repository.getByLanguage(QuestionLanguage.english);
      expect(hindi.length + english.length, 20);
      expect(hindi.every((Question q) => q.language == QuestionLanguage.hindi), isTrue);
      expect(english.every((Question q) => q.language == QuestionLanguage.english), isTrue);

      // Difficulty filtering
      final List<Question> hard =
          await repository.getByDifficulty(QuestionDifficulty.hard);
      expect(hard.isNotEmpty, isTrue);
      expect(hard.every((Question q) => q.difficulty == QuestionDifficulty.hard), isTrue);

      // Topic, ID, and Mixed retrieval
      final Question? byId = await repository.getById('DEMO_POL_001');
      expect(byId, isNotNull);
      expect(byId!.verificationStatus, VerificationStatus.demoUnverified);
      expect(byId.isSample, isTrue);

      final List<Question> mixed = await repository.getMixed(limit: 10);
      expect(mixed.length, 10);
    });

    test('supports CSV batch import', () async {
      const String csv =
          'id,question_text,option_a,option_b,option_c,option_d,correct_option_index,explanation,subject,topic,subtopic,difficulty,language,exam_category,question_type,source_reference,verification_status\n'
          'CSV_001,"Which planet is known as the Red Planet?",Venus,Mars,Jupiter,Saturn,1,"Mars appears red due to iron oxide on its surface.",geography,World Geography,Solar System,easy,en,general,single_choice,"CSV demo sample — unverified",demo_unverified\n';
      final QuestionBatchImporter importer =
          QuestionBatchImporter(repository: repository);
      final BatchImportReport report = await importer.importFromCsvString(csv);
      expect(report.insertedCount, 1);
      expect((await repository.getById('CSV_001'))?.correctAnswer, 'Mars');
    });
  });
}
