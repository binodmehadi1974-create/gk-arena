import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:gk_arena/features/monetization/config/ad_config.dart';
import 'package:gk_arena/features/monetization/services/ad_consent_and_policy_service.dart';
import 'package:gk_arena/features/monetization/services/ad_manager.dart';
import 'package:gk_arena/features/monetization/ui/widgets/gk_banner_ad_slot.dart';

void main() {
  test('Development configuration strictly uses official Google test ad unit IDs', () {
    expect(AdConfig.useTestAds, isTrue);
    expect(AdConfig.isProductionConfigured, isFalse);
    expect(AdConfig.bannerAdUnitId, AdConfig.androidTestBannerId);
    expect(AdConfig.interstitialAdUnitId, AdConfig.androidTestInterstitialId);
    expect(AdConfig.rewardedAdUnitId, AdConfig.androidTestRewardedId);
  });

  test('InterstitialFrequencyGuard blocks startup ads, active quiz ads, and enforces cooldown & session cap', () {
    DateTime now = DateTime.utc(2026, 11, 23, 8, 0);
    final InterstitialFrequencyGuard guard = InterstitialFrequencyGuard(
      minCooldownSeconds: 180,
      maxPerSession: 2,
      minCompletedTestsBeforeFirst: 1,
      clock: () => now,
    );

    // 1. Startup (0 completed tests) -> blocked
    expect(guard.canShowNow(isNaturalBreak: true), isFalse);

    // 2. Active quiz -> strictly blocked even after test count met
    guard.recordTestCompleted();
    guard.setQuizActive(true);
    expect(guard.canShowNow(isNaturalBreak: true), isFalse);

    // 3. Quiz ends -> natural break allowed
    guard.setQuizActive(false);
    expect(guard.canShowNow(isNaturalBreak: true), isTrue);
    guard.markShown();

    // 4. Quick navigation within 60s -> blocked by 180s cooldown
    now = now.add(const Duration(seconds: 60));
    expect(guard.canShowNow(isNaturalBreak: true), isFalse);

    // 5. After 181s -> second ad allowed
    now = now.add(const Duration(seconds: 121));
    expect(guard.canShowNow(isNaturalBreak: true), isTrue);
    guard.markShown();

    // 6. Session cap (2) reached -> blocked even after 10 minutes
    now = now.add(const Duration(minutes: 10));
    expect(guard.canShowNow(isNaturalBreak: true), isFalse);
  });

  test('Rewarded ad does not grant reward when ad is unavailable and grants only on verified completion', () async {
    final AdManager manager = AdManager();
    expect(manager.earnedBonusRevisionCredits, 0);

    // Attempting to show on unsupported/unloaded environment must NOT grant reward
    final RewardedAdResult res = await manager.showVoluntaryRewardedAd();
    expect(res.earnedReward, isFalse);
    expect(manager.earnedBonusRevisionCredits, 0);

    // Verified SDK completion grants exactly 1 credit
    manager.grantVerifiedReward();
    expect(manager.earnedBonusRevisionCredits, 1);
    manager.dispose();
  });

  test('AdConsentAndPolicyService enforces non-personalized student-safe requests by default', () {
    final AdConsentAndPolicyService policy = AdConsentAndPolicyService();
    expect(policy.isStudentSafeAudience, isTrue);
    expect(policy.buildAdRequest().nonPersonalizedAds, isTrue);
  });

  testWidgets('GkBannerAdSlot collapses cleanly without overflow when ad is unavailable',
      (WidgetTester tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          bottomNavigationBar: GkBannerAdSlot(),
          body: Center(child: Text('Content')),
        ),
      ),
    );
    await tester.pump();
    expect(find.text('Content'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
