import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:gk_arena/features/quiz/services/quiz_environment.dart';
import 'package:gk_arena/features/settings/models/app_settings.dart';
import 'package:gk_arena/main.dart';

void main() {
  testWidgets('GK ARENA renders 4 localized tabs, bilingual Explore search, and theme/language switching',
      (WidgetTester tester) async {
    final QuizEnvironment env = QuizEnvironment();
    await env.ensureInitialized(loadDemoIfEmpty: false);

    await tester.pumpWidget(GkArenaApp(quizEnvironment: env));
    await tester.pumpAndSettle();

    // Home screen (Default Hindi interface)
    expect(find.text('GK ARENA'), findsOneWidget);
    expect(find.text('अपना अगला टेस्ट शुरू करें'), findsOneWidget);

    // Navigate to Explore (विषय)
    await tester.tap(find.text('विषय'));
    await tester.pumpAndSettle();
    expect(find.text('History'), findsWidgets);
    expect(find.text('Reasoning'), findsOneWidget);

    // Live Hindi search -> History
    final Finder searchField = find.byKey(const Key('explore_search_field'));
    await tester.enterText(searchField, 'इतिहास');
    await tester.pumpAndSettle();
    expect(find.text('History'), findsWidgets);

    // Live English search -> Chemistry
    await tester.enterText(searchField, 'chemistry');
    await tester.pumpAndSettle();
    expect(find.text('Chemistry'), findsOneWidget);

    // No-result empty state
    await tester.enterText(searchField, 'unknown_xyz_123');
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('explore_empty_state')), findsOneWidget);

    // Clear search restores directory
    await tester.tap(find.byKey(const Key('explore_clear_search_button')));
    await tester.pumpAndSettle();
    expect(find.text('Reasoning'), findsOneWidget);

    // Navigate to Tests (टेस्ट)
    await tester.tap(find.text('टेस्ट'));
    await tester.pumpAndSettle();
    expect(find.text('Test Centre'), findsOneWidget);

    // Navigate to Profile (प्रोफ़ाइल)
    await tester.tap(find.text('प्रोफ़ाइल'));
    await tester.pumpAndSettle();
    expect(find.text('मेरी प्रोफ़ाइल'), findsOneWidget);

    // Switch interface language to English + Dark theme -> verify instant UI update
    await env.settingsController.setAppLanguage(AppLanguage.english);
    await env.settingsController.setThemePreference(AppThemePreference.dark);
    await tester.pumpAndSettle();

    expect(find.text('My Profile'), findsOneWidget);
    expect(find.text('Home'), findsOneWidget);
    expect(find.text('Explore'), findsOneWidget);

    await env.dispose();
  });
}
