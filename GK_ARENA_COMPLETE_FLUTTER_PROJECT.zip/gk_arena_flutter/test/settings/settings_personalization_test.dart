import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:gk_arena/features/learning/database/in_memory_learning_data_source.dart';
import 'package:gk_arena/features/learning/repositories/learning_repository.dart';
import 'package:gk_arena/features/question_bank/database/in_memory_question_data_source.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/features/quiz/services/quiz_scoring_service.dart';
import 'package:gk_arena/features/settings/controllers/settings_controller.dart';
import 'package:gk_arena/features/settings/database/in_memory_settings_data_source.dart';
import 'package:gk_arena/features/settings/localization/app_strings.dart';
import 'package:gk_arena/features/settings/models/app_settings.dart';

Question _sampleQuestion(String id) {
  final DateTime now = DateTime.utc(2026, 1, 1);
  return Question(
    id: id,
    questionText: 'Sample question $id?',
    options: const <String>['A', 'B', 'C', 'D'],
    correctOptionIndex: 0,
    explanation: 'Explanation for $id.',
    subject: QuestionSubject.history,
    topic: 'Ancient India',
    subtopic: 'Overview',
    difficulty: QuestionDifficulty.medium,
    language: QuestionLanguage.english,
    examCategory: ExamCategory.general,
    questionType: QuestionType.singleChoice,
    sourceReference: 'Test Fixture',
    verificationStatus: VerificationStatus.verified,
    createdAt: now,
    updatedAt: now,
  );
}

void main() {
  late InMemorySettingsStore settingsStore;
  late InMemoryLearningStore learningStore;
  late QuestionRepository questionRepository;
  late LearningRepository learningRepository;
  late SettingsController settingsController;

  setUp(() async {
    settingsStore = InMemorySettingsStore();
    learningStore = InMemoryLearningStore();
    questionRepository = QuestionRepository(
      dataSource: InMemoryQuestionDataSource(),
    );
    await questionRepository.initialize();
    await questionRepository.saveQuestion(_sampleQuestion('q_set_1'));

    learningRepository = LearningRepository(
      dataSource: InMemoryLearningDataSource(store: learningStore),
      questionRepository: questionRepository,
    );
    await learningRepository.initialize();

    settingsController = SettingsController(
      dataSource: InMemorySettingsDataSource(store: settingsStore),
      learningRepository: learningRepository,
    );
    await settingsController.initialize();
  });

  test('Hindi and English app strings localize navigation and settings cleanly', () {
    const AppStrings hi = AppStrings(AppLanguage.hindi);
    const AppStrings en = AppStrings(AppLanguage.english);

    expect(hi.navHome, 'होम');
    expect(en.navHome, 'Home');
    expect(hi.settings, 'सेटिंग्स');
    expect(en.settings, 'Settings');
    expect(hi.clearLearningData, isNot(en.clearLearningData));
  });

  test('Language and theme changes persist across simulated app restarts', () async {
    await settingsController.setAppLanguage(AppLanguage.english);
    await settingsController.setThemePreference(AppThemePreference.dark);
    await settingsController.close();

    final SettingsController restarted = SettingsController(
      dataSource: InMemorySettingsDataSource(store: settingsStore),
      learningRepository: learningRepository,
    );
    await restarted.initialize();

    expect(restarted.appLanguage, AppLanguage.english);
    expect(restarted.themePreference, AppThemePreference.dark);
    expect(restarted.themePreference.themeMode, ThemeMode.dark);
  });

  test('Study preferences persist independently from app interface language and sync daily goal', () async {
    await settingsController.setAppLanguage(AppLanguage.hindi);
    await settingsController.updateStudyPreferences(
      defaultQuestionLanguage: QuestionLanguage.english,
      preferredDifficulty: QuestionDifficulty.hard,
      preferredTestDurationMinutes: 20,
      dailyGoalEnabled: true,
      dailyGoalTarget: 25,
    );

    // App UI remains Hindi while Question Language is English
    expect(settingsController.appLanguage, AppLanguage.hindi);
    expect(
      settingsController.studyPreferences.defaultQuestionLanguage,
      QuestionLanguage.english,
    );

    // Verify daily goal synced to LearningRepository
    final goal = await learningRepository.getDailyGoal();
    expect(goal.isEnabled, isTrue);
    expect(goal.dailyQuestionTarget, 25);

    // Verify persistence after restart
    final SettingsController restarted = SettingsController(
      dataSource: InMemorySettingsDataSource(store: settingsStore),
      learningRepository: learningRepository,
    );
    await restarted.initialize();
    expect(
      restarted.studyPreferences.defaultQuestionLanguage,
      QuestionLanguage.english,
    );
    expect(
      restarted.studyPreferences.preferredDifficulty,
      QuestionDifficulty.hard,
    );
    expect(restarted.studyPreferences.preferredTestDurationMinutes, 20);
    expect(restarted.studyPreferences.dailyGoalTarget, 25);
  });

  test('Clear learning data wipes personal progress without deleting Question Bank or App Settings', () async {
    final Question q = (await questionRepository.getById('q_set_1'))!;
    await learningRepository.addBookmark(q);
    await settingsController.setThemePreference(AppThemePreference.system);

    const QuizScoringService scoringService = QuizScoringService();
    final QuizResult result = scoringService.evaluate(
      config: const QuizConfig(
        mode: TestMode.practice,
        subjects: <QuestionSubject>[QuestionSubject.history],
        questionCount: 1,
      ),
      states: <QuizQuestionState>[
        QuizQuestionState(question: q, selectedOptionIndex: 1), // Wrong
      ],
      timeTakenSeconds: 15,
      wasAutoSubmitted: false,
    );
    await learningRepository.recordCompletedTest(result);

    expect((await learningRepository.getTestHistory()).length, 1);
    expect((await learningRepository.getResolvedBookmarks()).length, 1);
    expect((await learningRepository.getResolvedWrongAnswers()).length, 1);

    // Execute scoped clear
    await learningRepository.clearAllLearningData();

    // Personal learning records must be wiped
    expect(await learningRepository.getTestHistory(), isEmpty);
    expect(await learningRepository.getResolvedBookmarks(), isEmpty);
    expect(await learningRepository.getResolvedWrongAnswers(includeMastered: true), isEmpty);

    // Question Bank and App Settings must remain completely intact
    expect(await questionRepository.count(), 1);
    expect(await questionRepository.getById('q_set_1'), isNotNull);
    expect(settingsController.themePreference, AppThemePreference.system);
  });
}
