import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:gk_arena/features/admin/models/admin_models.dart';
import 'package:gk_arena/features/admin/repositories/admin_repository.dart';
import 'package:gk_arena/features/admin/services/admin_access_service.dart';
import 'package:gk_arena/features/question_bank/database/in_memory_question_data_source.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';

Map<String, Object?> _validJsonRow(String id, {String? text, String subject = 'history'}) {
  return <String, Object?>{
    'id': id,
    'question_text': text ?? 'Verified structure sample question $id?',
    'options': <String>['Option 1', 'Option 2', 'Option 3', 'Option 4'],
    'correct_option_index': 1,
    'explanation': 'Detailed explanation for $id.',
    'subject': subject,
    'topic': 'Ancient India',
    'subtopic': 'Maurya Empire',
    'difficulty': 'medium',
    'language': 'en',
    'exam_category': 'ssc',
    'question_type': 'single_choice',
    'source_reference': 'NCERT Class 6',
    'verification_status': 'verified',
  };
}

void main() {
  const AdminSession adminSession = AdminSession(
    uid: 'admin_1',
    displayName: 'Lead Admin',
    role: UserRole.admin,
    isBackendAuthorized: true,
  );
  const AdminSession reviewerSession = AdminSession(
    uid: 'rev_1',
    displayName: 'Content Reviewer',
    role: UserRole.reviewer,
    isBackendAuthorized: true,
  );
  const AdminSession studentSession = AdminSession(
    uid: 'stu_1',
    displayName: 'Normal Student',
    role: UserRole.student,
    isBackendAuthorized: true,
  );

  late QuestionRepository questionRepository;
  late AdminRepository adminRepository;

  setUp(() async {
    questionRepository = QuestionRepository(
      dataSource: InMemoryQuestionDataSource(),
    );
    await questionRepository.initialize();

    adminRepository = AdminRepository(
      questionRepository: questionRepository,
      accessService: InMemoryTestAdminAccessService(),
    );
  });

  test('BackendEnforcedAdminAccessService blocks admin mutations when backend is unconfigured', () async {
    final AdminRepository strictRepo = AdminRepository(
      questionRepository: questionRepository,
      accessService: BackendEnforcedAdminAccessService(),
    );

    expect(
      () => strictRepo.getDashboardMetrics(session: adminSession),
      throwsA(isA<AdminAuthorizationException>()),
    );
  });

  test('Normal students are strictly blocked from all admin and reviewer operations', () async {
    expect(
      () => adminRepository.getDashboardMetrics(session: studentSession),
      throwsA(isA<AdminAuthorizationException>()),
    );
    expect(
      () => adminRepository.previewBulkImport(
        session: studentSession,
        format: 'json',
        content: '[]',
      ),
      throwsA(isA<AdminAuthorizationException>()),
    );
    expect(
      () => adminRepository.deleteQuestion(
        session: studentSession,
        questionId: 'any',
      ),
      throwsA(isA<AdminAuthorizationException>()),
    );
  });

  test('JSON preview detects valid, duplicate, and invalid records without silent drops and separates factual verification', () async {
    final String payload = jsonEncode(<Object?>[
      _validJsonRow('adm_1', text: 'Who founded the Maurya Empire?'),
      _validJsonRow('adm_1', text: 'Duplicate ID question?'), // Duplicate ID
      _validJsonRow('adm_2', text: '  who founded the maurya empire? '), // Duplicate text
      <String, Object?>{
        ..._validJsonRow('adm_bad_1'),
        'explanation': '', // Missing explanation
      },
      <String, Object?>{
        ..._validJsonRow('adm_bad_2'),
        'options': <String>['Same', 'Same', 'C', 'D'], // Duplicate options
      },
      <String, Object?>{
        ..._validJsonRow('adm_bad_3'),
        'language': 'fr', // Unsupported language
      },
    ]);

    final ImportPreviewReport preview = await adminRepository.previewBulkImport(
      session: adminSession,
      format: 'json',
      content: payload,
    );

    expect(preview.totalRows, 6);
    expect(preview.validCount, 1);
    expect(preview.duplicateCount, 2);
    expect(preview.invalidCount, 3);
    expect(preview.errors.length, 3);

    // Even though input claimed 'verified', bulk import must NOT auto-mark factually verified
    expect(
      preview.validQuestions.first.verificationStatus,
      VerificationStatus.pendingReview,
    );
    expect(
      preview.validQuestions.first.publicationStatus,
      PublicationStatus.draft,
    );

    // Commit after preview
    final ImportHistoryEntry history = await adminRepository.commitBulkImport(
      session: adminSession,
      preview: preview,
    );
    expect(history.importedCount, 1);
    expect(history.skippedDuplicates, 2);
    expect(history.rejectedCount, 3);
    expect(adminRepository.importHistory.length, 1);
  });

  test('CSV bulk import validates 17-column rows and imports valid entries', () async {
    const String csv =
        'id,question_text,option_a,option_b,option_c,option_d,correct_option_index,explanation,subject,topic,subtopic,difficulty,language,exam_category,question_type,source_reference,verification_status\n'
        'csv_1,Which planet is closest to the Sun?,Mercury,Venus,Earth,Mars,0,Mercury is the innermost planet.,geography,Solar System,Planets,easy,en,general,single_choice,NCERT,unverified\n'
        'csv_bad,Too few columns,A,B\n';

    final ImportPreviewReport preview = await adminRepository.previewBulkImport(
      session: adminSession,
      format: 'csv',
      content: csv,
    );
    expect(preview.totalRows, 2);
    expect(preview.validCount, 1);
    expect(preview.invalidCount, 1);

    final ImportHistoryEntry entry = await adminRepository.commitBulkImport(
      session: adminSession,
      preview: preview,
    );
    expect(entry.importedCount, 1);
  });

  test('Draft -> Pending Review -> Approved -> Published workflow enforces reviewer vs admin permissions and audits actions', () async {
    final ImportPreviewReport preview = await adminRepository.previewBulkImport(
      session: adminSession,
      format: 'json',
      content: jsonEncode(<Object?>[_validJsonRow('wf_1')]),
    );
    await adminRepository.commitBulkImport(
      session: adminSession,
      preview: preview,
    );

    // Reviewer can move Draft -> Pending Review -> Approved
    final r1 = await adminRepository.transitionStatus(
      session: reviewerSession,
      questionId: 'wf_1',
      nextStatus: PublicationStatus.pendingReview,
    );
    expect(r1.saved, isTrue);

    final r2 = await adminRepository.transitionStatus(
      session: reviewerSession,
      questionId: 'wf_1',
      nextStatus: PublicationStatus.approved,
    );
    expect(r2.saved, isTrue);

    // Reviewer CANNOT publish directly (admin-only)
    expect(
      () => adminRepository.transitionStatus(
        session: reviewerSession,
        questionId: 'wf_1',
        nextStatus: PublicationStatus.published,
      ),
      throwsA(isA<AdminAuthorizationException>()),
    );

    // Admin publishes
    final r3 = await adminRepository.transitionStatus(
      session: adminSession,
      questionId: 'wf_1',
      nextStatus: PublicationStatus.published,
      factualVerification: VerificationStatus.verified,
    );
    expect(r3.saved, isTrue);

    final Question? published = await questionRepository.getById('wf_1');
    expect(published?.publicationStatus, PublicationStatus.published);
    expect(published?.verificationStatus, VerificationStatus.verified);
    expect(adminRepository.auditLog.isNotEmpty, isTrue);
  });

  test('Pagination and large batch handling (1,200 MCQs) work without loading full dataset', () async {
    final List<Map<String, Object?>> batch = List<Map<String, Object?>>.generate(
      1200,
      (int i) => _validJsonRow(
        'batch_${i.toString().padLeft(4, '0')}',
        text: 'Large batch scalability question number $i?',
        subject: i.isEven ? 'history' : 'geography',
      ),
    );

    final ImportPreviewReport preview = await adminRepository.previewBulkImport(
      session: adminSession,
      format: 'json',
      content: jsonEncode(batch),
    );
    expect(preview.validCount, 1200);

    final ImportHistoryEntry committed = await adminRepository.commitBulkImport(
      session: adminSession,
      preview: preview,
    );
    expect(committed.importedCount, 1200);

    final PaginatedQuestionsResult page0 = await adminRepository.getQuestionsPage(
      session: adminSession,
      page: 0,
      pageSize: 25,
      subject: QuestionSubject.history,
    );
    expect(page0.items.length, 25);
    expect(page0.totalItems, 600);
    expect(page0.totalPages, 24);
    expect(page0.hasNextPage, isTrue);
    expect(page0.hasPreviousPage, isFalse);

    final AdminDashboardMetrics metrics =
        await adminRepository.getDashboardMetrics(session: adminSession);
    expect(metrics.totalQuestions, 1200);
    expect(metrics.draftQuestions, 1200);
    expect(metrics.bySubject[QuestionSubject.history], 600);
    expect(metrics.bySubject[QuestionSubject.geography], 600);
  });
}
