import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:gk_arena/features/admin/models/admin_models.dart';
import 'package:gk_arena/features/admin/repositories/admin_repository.dart';
import 'package:gk_arena/features/admin/services/admin_access_service.dart';
import 'package:gk_arena/features/admin/services/bulk_import_service.dart';
import 'package:gk_arena/features/learning/database/in_memory_learning_data_source.dart';
import 'package:gk_arena/features/learning/repositories/learning_repository.dart';
import 'package:gk_arena/features/question_bank/database/in_memory_question_data_source.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';

Map<String, Object?> _row(
  String id, {
  String text = 'Sample question text?',
  String? textHi,
  String? textEn,
  String subject = 'history',
  String topic = 'Ancient India',
  String language = 'en',
  String verificationStatus = 'verified',
}) {
  return <String, Object?>{
    'id': id,
    'question_text': text,
    if (textHi != null) 'question_text_hi': textHi,
    if (textEn != null) 'question_text_en': textEn,
    'options': <String>['Opt A', 'Opt B', 'Opt C', 'Opt D'],
    'correct_option_index': 1,
    'explanation': 'Clear explanation for $id.',
    'subject': subject,
    'chapter': 'Chapter 1',
    'topic': topic,
    'subtopic': 'Core',
    'difficulty': 'medium',
    'language': language,
    'exam_category': 'general',
    'question_type': 'single_choice',
    'source_reference': 'NCERT',
    'verification_status': verificationStatus,
  };
}

void main() {
  const AdminSession admin = AdminSession(
    uid: 'admin_12',
    displayName: 'Admin',
    role: UserRole.admin,
    isBackendAuthorized: true,
  );
  const AdminSession reviewer = AdminSession(
    uid: 'rev_12',
    displayName: 'Reviewer',
    role: UserRole.reviewer,
    isBackendAuthorized: true,
  );
  const AdminSession student = AdminSession(
    uid: 'stu_12',
    displayName: 'Student',
    role: UserRole.student,
    isBackendAuthorized: true,
  );

  late QuestionRepository questionRepo;
  late LearningRepository learningRepo;
  late AdminRepository adminRepo;

  setUp(() async {
    questionRepo = QuestionRepository(dataSource: InMemoryQuestionDataSource());
    await questionRepo.initialize();

    learningRepo = LearningRepository(
      dataSource: InMemoryLearningDataSource(),
      questionRepository: questionRepo,
    );
    await learningRepo.initialize();

    adminRepo = AdminRepository(
      questionRepository: questionRepo,
      accessService: InMemoryTestAdminAccessService(),
    );
  });

  test('Malformed JSON and CSV files are safely reported without crashing', () async {
    final DetailedImportPreview badJson = await adminRepo.previewBulkImport(
      session: admin,
      format: 'json',
      content: '{not_valid_json',
    );
    expect(badJson.invalidCount, 1);
    expect(badJson.validationFailures.length, 1);

    final DetailedImportPreview emptyCsv = await adminRepo.previewBulkImport(
      session: admin,
      format: 'csv',
      content: 'id,question_text\n',
    );
    expect(emptyCsv.invalidCount, 1);
    expect(emptyCsv.validationFailures.length, 1);
  });

  test('Partially invalid batch imports valid rows, logs detailed failures & duplicates, detects translation mismatch, and never auto-verifies', () async {
    final String jsonPayload = jsonEncode(<Object?>[
      _row(
        's12_valid_1',
        text: 'भारत छोड़ो आंदोलन कब शुरू हुआ?',
        textHi: 'भारत छोड़ो आंदोलन कब शुरू हुआ?',
        textEn: 'When did the Quit India Movement begin?',
        language: 'hi',
        verificationStatus: 'verified', // Must be downgraded to pending_review!
      ),
      _row(
        's12_dup_text',
        text: '  भारत छोड़ो आंदोलन कब शुरू हुआ? ', // Duplicate normalized text
        language: 'hi',
      ),
      _row(
        's12_mismatch',
        text: 'Same English text in Hindi field?',
        textHi: 'Same English text in Hindi field?', // Detectable mismatch warning
        textEn: 'Same English text in Hindi field?',
        language: 'en',
      ),
      <String, Object?>{
        ..._row('s12_invalid'),
        'correct_option_index': 9, // Invalid answer index
        'explanation': '', // Missing explanation
      },
    ]);

    final DetailedImportPreview preview = await adminRepo.previewBulkImport(
      session: admin,
      format: 'json',
      content: jsonPayload,
    );

    expect(preview.totalRows, 4);
    expect(preview.validCount, 2);
    expect(preview.duplicateCount, 1);
    expect(preview.invalidCount, 1);
    expect(preview.duplicateMatches.length, 1);
    expect(preview.validationFailures.length, 1);
    expect(
      preview.warnings.any((String w) => w.contains('Translation mismatch')),
      isTrue,
    );

    // Commit valid subset
    final ImportHistoryEntry committed = await adminRepo.commitBulkImport(
      session: admin,
      preview: preview,
    );
    expect(committed.importedCount, 2);

    // Verify auto-verification was strictly prevented
    final Question? saved = await questionRepo.getById('s12_valid_1');
    expect(saved, isNotNull);
    expect(saved!.verificationStatus, VerificationStatus.pendingReview);

    // Student cannot verify; authorized reviewer CAN verify and history is recorded
    expect(
      () => adminRepo.reviewVerificationStatus(
        session: student,
        questionId: 's12_valid_1',
        newStatus: VerificationStatus.verified,
      ),
      throwsA(isA<AdminAuthorizationException>()),
    );

    final res = await adminRepo.reviewVerificationStatus(
      session: reviewer,
      questionId: 's12_valid_1',
      newStatus: VerificationStatus.verified,
      note: 'Checked against NCERT Class 8 History.',
    );
    expect(res.saved, isTrue);
    expect(
      (await questionRepo.getById('s12_valid_1'))!.verificationStatus,
      VerificationStatus.verified,
    );
    expect(adminRepo.verificationHistory.length, 1);
    expect(adminRepo.verificationHistory.first.reviewerUid, reviewer.uid);
  });

  test('Large synthetic batch (2,000 rows) commits in chunks with progress and preserves user bookmarks', () async {
    // Save a user bookmark BEFORE bulk import
    final Question existingQ = Question.fromJson(_row('existing_bm', text: 'Pre-existing question?'));
    await questionRepo.saveQuestion(existingQ);
    await learningRepo.addBookmark(existingQ);

    final List<Map<String, Object?>> batch2k = List<Map<String, Object?>>.generate(
      2000,
      (int i) => _row(
        's12_lg_${i.toString().padLeft(4, '0')}',
        text: 'Synthetic large batch question #$i?',
      ),
    );

    final DetailedImportPreview preview = await adminRepo.previewBulkImport(
      session: admin,
      format: 'json',
      content: jsonEncode(batch2k),
    );
    expect(preview.validCount, 2000);

    int progressCalls = 0;
    final ImportHistoryEntry committed = await adminRepo.commitBulkImport(
      session: admin,
      preview: preview,
      chunkSize: 250,
      onProgress: (int processed, int total) {
        progressCalls++;
      },
    );

    expect(committed.importedCount, 2000);
    expect(progressCalls, 8); // 2000 / 250 = 8 chunks

    // User bookmarks remain completely preserved
    final bookmarks = await learningRepo.getResolvedBookmarks();
    expect(bookmarks.length, 1);
    expect(bookmarks.first.question.id, 'existing_bm');
  });
}
