import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:gk_arena/features/account/controllers/account_controller.dart';
import 'package:gk_arena/features/account/services/auth_service.dart';
import 'package:gk_arena/features/account/services/cloud_backup_service.dart';
import 'package:gk_arena/features/admin/models/admin_models.dart';
import 'package:gk_arena/features/admin/repositories/admin_repository.dart';
import 'package:gk_arena/features/admin/services/admin_access_service.dart';
import 'package:gk_arena/features/learning/database/in_memory_learning_data_source.dart';
import 'package:gk_arena/features/learning/repositories/learning_repository.dart';
import 'package:gk_arena/features/question_bank/database/in_memory_question_data_source.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';
import 'package:gk_arena/features/question_bank/validation/question_validator.dart';
import 'package:gk_arena/features/quiz/controllers/quiz_session_controller.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/features/quiz/services/quiz_scoring_service.dart';
import 'package:gk_arena/features/quiz/services/recent_question_tracker.dart';
import 'package:gk_arena/features/settings/controllers/settings_controller.dart';
import 'package:gk_arena/features/settings/database/in_memory_settings_data_source.dart';

Question _q(String id, {String text = 'Valid security test question?'}) {
  final DateTime now = DateTime.utc(2026, 11, 23);
  return Question(
    id: id,
    questionText: text,
    options: const <String>['Opt 1', 'Opt 2', 'Opt 3', 'Opt 4'],
    correctOptionIndex: 0,
    explanation: 'Valid explanation.',
    subject: QuestionSubject.history,
    chapter: 'Ch 1',
    topic: 'Topic 1',
    subtopic: 'Sub 1',
    difficulty: QuestionDifficulty.easy,
    language: QuestionLanguage.english,
    examCategory: ExamCategory.general,
    questionType: QuestionType.singleChoice,
    sourceReference: 'NCERT',
    verificationStatus: VerificationStatus.pendingReview,
    createdAt: now,
    updatedAt: now,
  );
}

void main() {
  test('QuestionValidator blocks null-bytes and oversized payloads', () {
    const QuestionValidator validator = QuestionValidator();

    final Question nullByteQ = _q('sec_1', text: 'Malicious\u0000question?');
    expect(validator.validate(nullByteQ).isValid, isFalse);

    final Question hugeQ = _q('sec_2', text: 'A' * 2500);
    expect(validator.validate(hugeQ).isValid, isFalse);
  });

  test('Duplicate quiz submission is strictly prevented by QuizSessionController', () {
    int submitCalls = 0;
    final QuizSessionController controller = QuizSessionController(
      config: const QuizConfig(
        mode: TestMode.practice,
        questionCount: 1,
      ),
      questions: <Question>[_q('dup_sub_1')],
      scoringService: const QuizScoringService(),
      recentTracker: RecentQuestionTracker(),
      onSubmitted: (_) => submitCalls++,
    );

    controller.selectOption(0);
    final QuizResult? first = controller.submit(autoSubmitted: false);
    final QuizResult? second = controller.submit(autoSubmitted: true);

    expect(first, isNotNull);
    expect(second, isNull);
    expect(submitCalls, 1);
    controller.dispose();
  });

  test('Failed bulk import does not corrupt pre-existing Question Bank or user data', () async {
    final QuestionRepository qRepo =
        QuestionRepository(dataSource: InMemoryQuestionDataSource());
    await qRepo.initialize();
    await qRepo.saveQuestion(_q('keep_1', text: 'Pre-existing valid question?'));

    final AdminRepository adminRepo = AdminRepository(
      questionRepository: qRepo,
      accessService: InMemoryTestAdminAccessService(),
    );
    const AdminSession admin = AdminSession(
      uid: 'adm',
      displayName: 'Admin',
      role: UserRole.admin,
      isBackendAuthorized: true,
    );

    final preview = await adminRepo.previewBulkImport(
      session: admin,
      format: 'json',
      content: '{{{corrupted_json',
    );
    expect(preview.validCount, 0);
    expect(preview.invalidCount, 1);
    expect(await qRepo.count(), 1);
    expect(await qRepo.getById('keep_1'), isNotNull);
  });

  test('Default production security guards block unconfigured admin mutations and fake account deletions', () async {
    final QuestionRepository qRepo =
        QuestionRepository(dataSource: InMemoryQuestionDataSource());
    await qRepo.initialize();
    final LearningRepository lRepo = LearningRepository(
      dataSource: InMemoryLearningDataSource(),
      questionRepository: qRepo,
    );
    await lRepo.initialize();
    final SettingsController settings = SettingsController(
      dataSource: InMemorySettingsDataSource(),
      learningRepository: lRepo,
    );
    await settings.initialize();

    final AccountController account = AccountController(
      authService: UnconfiguredAuthService(),
      learningRepository: lRepo,
      settingsController: settings,
      cloudSyncService: CloudSyncService(
        remoteDataSource: UnconfiguredCloudBackupDataSource(),
        learningRepository: lRepo,
        settingsController: settings,
      ),
    );
    await account.initialize();

    final delResult =
        await account.requestAccountDeletion(currentPassword: 'Password123!');
    expect(delResult.success, isFalse);
    expect(delResult.requiresBackendConfig, isTrue);

    final AdminRepository prodAdminRepo = AdminRepository(
      questionRepository: qRepo,
      accessService: BackendEnforcedAdminAccessService(),
    );
    expect(
      () => prodAdminRepo.deleteQuestion(
        session: const AdminSession(
          uid: 'spoofed',
          displayName: 'Spoofed',
          role: UserRole.admin,
          isBackendAuthorized: true,
        ),
        questionId: 'any',
      ),
      throwsA(isA<AdminAuthorizationException>()),
    );
  });

  test('JSON payload serialization never exposes passwords or secrets', () {
    final Question sample = _q('safe_1');
    final String encoded = jsonEncode(sample.toJson());
    expect(encoded.contains('password'), isFalse);
    expect(encoded.contains('AIza'), isFalse);
  });
}
