/// Pure Dart data models for GK ARENA's reusable search architecture.
/// Kept independent of Flutter UI so larger question databases can plug in later.
class SearchSubjectEntry {
  const SearchSubjectEntry({
    required this.id,
    required this.titleEn,
    required this.titleHi,
    required this.shortDescription,
    required this.category,
    required this.aliases,
    this.primaryAliases = const <String>[],
    this.isDefaultDirectoryItem = true,
  });

  final String id;
  final String titleEn;
  final String titleHi;
  final String shortDescription;
  final String category;
  final List<String> aliases;

  /// High-priority exact synonyms (e.g. "विज्ञान" -> General Science).
  final List<String> primaryAliases;

  /// Controls whether the item appears in the default unfiltered Explore grid.
  final bool isDefaultDirectoryItem;
}

class SubjectSearchResult {
  const SubjectSearchResult({
    required this.rawQuery,
    required this.normalizedQuery,
    required this.category,
    required this.entries,
  });

  final String rawQuery;
  final String normalizedQuery;
  final String category;
  final List<SearchSubjectEntry> entries;

  bool get hasActiveQuery => normalizedQuery.isNotEmpty;
  bool get isEmpty => entries.isEmpty;
  int get count => entries.length;
}
