import 'package:gk_arena/features/search/data/subject_search_catalog.dart';
import 'package:gk_arena/features/search/models/search_models.dart';

/// Pure Dart bilingual search service for GK ARENA subjects.
/// Designed cleanly so larger question indices can extend or replace the backend later.
class SubjectSearchService {
  const SubjectSearchService({
    this.catalog = SubjectSearchCatalog.entries,
  });

  final List<SearchSubjectEntry> catalog;

  static final RegExp _multiWhitespace = RegExp(r'\s+');

  /// Normalizes input by trimming edges, collapsing internal spaces, and lowercasing.
  String normalizeQuery(String query) {
    return query.trim().replaceAll(_multiWhitespace, ' ').toLowerCase();
  }

  /// Searches subjects by bilingual Hindi/English query and optional category.
  SubjectSearchResult search({
    required String query,
    String category = SubjectSearchCatalog.categoryAll,
  }) {
    final String normalized = normalizeQuery(query);
    final bool filterByCategory =
        category.isNotEmpty && category != SubjectSearchCatalog.categoryAll;

    if (normalized.isEmpty) {
      final List<SearchSubjectEntry> defaults = catalog
          .where((SearchSubjectEntry entry) =>
              entry.isDefaultDirectoryItem &&
              (!filterByCategory || entry.category == category))
          .toList(growable: false);

      return SubjectSearchResult(
        rawQuery: query,
        normalizedQuery: normalized,
        category: category,
        entries: defaults,
      );
    }

    final List<String> tokens = normalized.split(' ');
    final List<_ScoredEntry> scored = <_ScoredEntry>[];

    for (int i = 0; i < catalog.length; i++) {
      final SearchSubjectEntry entry = catalog[i];
      if (filterByCategory && entry.category != category) {
        continue;
      }

      final int score = _scoreEntry(entry, normalized, tokens);
      if (score > 0) {
        scored.add(_ScoredEntry(entry: entry, score: score, order: i));
      }
    }

    scored.sort((_ScoredEntry a, _ScoredEntry b) {
      final int byScore = b.score.compareTo(a.score);
      if (byScore != 0) return byScore;
      return a.order.compareTo(b.order);
    });

    return SubjectSearchResult(
      rawQuery: query,
      normalizedQuery: normalized,
      category: category,
      entries: scored.map((_ScoredEntry e) => e.entry).toList(growable: false),
    );
  }

  int _scoreEntry(
    SearchSubjectEntry entry,
    String query,
    List<String> tokens,
  ) {
    final String titleEn = normalizeQuery(entry.titleEn);
    final String titleHi = normalizeQuery(entry.titleHi);
    final String category = normalizeQuery(entry.category);
    final String description = normalizeQuery(entry.shortDescription);

    final List<String> primaryAliases = entry.primaryAliases
        .map(normalizeQuery)
        .toList(growable: false);
    final List<String> aliases =
        entry.aliases.map(normalizeQuery).toList(growable: false);

    // 1. Exact title or exact primary synonym match
    if (titleEn == query || titleHi == query) {
      return 100;
    }
    if (primaryAliases.contains(query)) {
      return 96;
    }

    // 2. Exact match on any Hindi sub-part separated by "/"
    final List<String> hiParts = titleHi
        .split('/')
        .map((String part) => normalizeQuery(part))
        .toList(growable: false);
    if (hiParts.contains(query)) {
      return 95;
    }

    // 3. Exact secondary alias match
    if (aliases.contains(query)) {
      return 90;
    }

    // 4. Prefix match on English/Hindi title or primary aliases
    if (titleEn.startsWith(query) || titleHi.startsWith(query)) {
      return 85;
    }
    if (primaryAliases.any((String a) => a.startsWith(query))) {
      return 82;
    }

    // 5. Word-start match on title or aliases
    if (_hasWordStartingWith(titleEn, query) ||
        _hasWordStartingWith(titleHi, query) ||
        primaryAliases.any((String a) => _hasWordStartingWith(a, query))) {
      return 75;
    }

    // 6. Substring match on title or aliases
    if (titleEn.contains(query) ||
        titleHi.contains(query) ||
        primaryAliases.any((String a) => a.contains(query))) {
      return 65;
    }
    if (aliases.any((String a) => a.startsWith(query))) {
      return 62;
    }
    if (aliases.any((String a) => a.contains(query))) {
      return 58;
    }

    // 7. Category or description substring match
    if (category.contains(query)) {
      return 50;
    }
    if (description.contains(query)) {
      return 45;
    }

    // 8. Multi-token match (every space-separated token matches somewhere)
    if (tokens.length > 1) {
      final String combined = <String>[
        titleEn,
        titleHi,
        category,
        description,
        ...primaryAliases,
        ...aliases,
      ].join(' ');
      final bool allMatched =
          tokens.every((String token) => combined.contains(token));
      if (allMatched) {
        return 42;
      }
    }

    return 0;
  }

  bool _hasWordStartingWith(String text, String query) {
    final List<String> words = text.split(RegExp(r'[\s/&,.-]+'));
    return words.any((String w) => w.startsWith(query));
  }
}

class _ScoredEntry {
  const _ScoredEntry({
    required this.entry,
    required this.score,
    required this.order,
  });

  final SearchSubjectEntry entry;
  final int score;
  final int order;
}
