import 'package:flutter/material.dart';
import 'package:gk_arena/features/search/models/search_models.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/screens/explore/widgets/subject_catalog.dart';
import 'package:gk_arena/ui/widgets/subject_card.dart';

/// Maps a pure-Dart SearchSubjectEntry to its Stage-1 SubjectUiItem presentation.
abstract final class SubjectUiMapper {
  static final Map<String, SubjectUiItem> _uiById = <String, SubjectUiItem>{
    for (final SubjectUiItem item in SubjectCatalog.allSubjects) item.id: item,
    'chemistry': const SubjectUiItem(
      id: 'chemistry',
      titleEn: 'Chemistry',
      titleHi: 'रसायन विज्ञान',
      shortDescription: 'तत्व, यौगिक, रासायनिक अभिक्रियाएँ और आवर्त सारणी।',
      category: SubjectCatalog.categoryScience,
      icon: Icons.biotech_outlined,
      accentColor: AppColors.accentTeal,
      accentBackground: AppColors.softTealSurface,
    ),
    'biology': const SubjectUiItem(
      id: 'biology',
      titleEn: 'Biology',
      titleHi: 'जीव विज्ञान',
      shortDescription: 'मानव शरीर, कोशिका, वनस्पति एवं जंतु विज्ञान।',
      category: SubjectCatalog.categoryScience,
      icon: Icons.eco_outlined,
      accentColor: AppColors.success,
      accentBackground: AppColors.softGreenSurface,
    ),
  };

  static SubjectUiItem toUiItem(SearchSubjectEntry entry) {
    final SubjectUiItem? existing = _uiById[entry.id];
    if (existing != null) {
      return existing;
    }
    return SubjectUiItem(
      id: entry.id,
      titleEn: entry.titleEn,
      titleHi: entry.titleHi,
      shortDescription: entry.shortDescription,
      category: entry.category,
      icon: Icons.menu_book_outlined,
      accentColor: AppColors.primary,
      accentBackground: AppColors.softBlueSurface,
    );
  }
}
