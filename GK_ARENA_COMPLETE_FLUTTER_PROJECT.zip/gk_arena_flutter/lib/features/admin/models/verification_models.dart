import 'package:gk_arena/features/question_bank/models/question_enums.dart';

/// Audit record tracking every factual verification review decision on a question.
class VerificationHistoryEntry {
  const VerificationHistoryEntry({
    required this.id,
    required this.questionId,
    required this.reviewerUid,
    required this.previousStatus,
    required this.newStatus,
    required this.note,
    required this.timestamp,
  });

  final String id;
  final String questionId;
  final String reviewerUid;
  final VerificationStatus previousStatus;
  final VerificationStatus newStatus;
  final String note;
  final DateTime timestamp;
}

/// Detailed duplicate match entry surfaced in the Duplicate Review screen.
class DuplicateMatchDetail {
  const DuplicateMatchDetail({
    required this.rowNumber,
    required this.incomingId,
    required this.incomingText,
    required this.subjectId,
    required this.topic,
    required this.languageCode,
    required this.reason,
  });

  final int rowNumber;
  final String incomingId;
  final String incomingText;
  final String subjectId;
  final String topic;
  final String languageCode;
  final String reason;
}

/// Detailed validation failure entry surfaced in the Validation Report screen.
class ValidationFailureDetail {
  const ValidationFailureDetail({
    required this.rowNumber,
    required this.questionId,
    required this.errors,
    this.warnings = const <String>[],
  });

  final int rowNumber;
  final String questionId;
  final List<String> errors;
  final List<String> warnings;
}
