import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';

enum UserRole {
  student('student'),
  reviewer('reviewer'),
  admin('admin');

  const UserRole(this.code);
  final String code;
}

/// Authenticated admin/reviewer session context.
/// In production, [isBackendAuthorized] MUST be verified via backend custom claims.
class AdminSession {
  const AdminSession({
    required this.uid,
    required this.displayName,
    required this.role,
    required this.isBackendAuthorized,
  });

  final String uid;
  final String displayName;
  final UserRole role;
  final bool isBackendAuthorized;

  bool get canReview =>
      isBackendAuthorized &&
      (role == UserRole.admin || role == UserRole.reviewer);

  bool get canAdminister => isBackendAuthorized && role == UserRole.admin;
}

class AdminAuditEntry {
  const AdminAuditEntry({
    required this.id,
    required this.actorUid,
    required this.action,
    required this.targetId,
    required this.details,
    required this.timestamp,
  });

  final String id;
  final String actorUid;
  final String action;
  final String targetId;
  final String details;
  final DateTime timestamp;
}

enum ImportRowStatus { valid, duplicate, invalid }

class ImportPreviewRow {
  const ImportPreviewRow({
    required this.rowNumber,
    this.question,
    required this.status,
    this.errors = const <String>[],
  });

  final int rowNumber;
  final Question? question;
  final ImportRowStatus status;
  final List<String> errors;
}

class ImportPreviewReport {
  const ImportPreviewReport({
    required this.format,
    required this.totalRows,
    required this.validQuestions,
    required this.duplicateCount,
    required this.invalidCount,
    required this.rows,
    required this.errors,
  });

  final String format;
  final int totalRows;
  final List<Question> validQuestions;
  final int duplicateCount;
  final int invalidCount;
  final List<ImportPreviewRow> rows;
  final List<String> errors;

  int get validCount => validQuestions.length;
}

class ImportHistoryEntry {
  const ImportHistoryEntry({
    required this.importId,
    required this.actorUid,
    required this.format,
    required this.importedAt,
    required this.totalRows,
    required this.importedCount,
    required this.skippedDuplicates,
    required this.rejectedCount,
    required this.errors,
  });

  final String importId;
  final String actorUid;
  final String format;
  final DateTime importedAt;
  final int totalRows;
  final int importedCount;
  final int skippedDuplicates;
  final int rejectedCount;
  final List<String> errors;
}

class PaginatedQuestionsResult {
  const PaginatedQuestionsResult({
    required this.items,
    required this.page,
    required this.pageSize,
    required this.totalItems,
  });

  final List<Question> items;
  final int page;
  final int pageSize;
  final int totalItems;

  int get totalPages =>
      totalItems == 0 ? 1 : ((totalItems + pageSize - 1) ~/ pageSize);
  bool get hasNextPage => page + 1 < totalPages;
  bool get hasPreviousPage => page > 0;
}

class AdminDashboardMetrics {
  const AdminDashboardMetrics({
    required this.totalQuestions,
    required this.publishedQuestions,
    required this.draftQuestions,
    required this.pendingReviewQuestions,
    required this.approvedQuestions,
    required this.rejectedQuestions,
    required this.bySubject,
    required this.byLanguage,
    required this.importHistory,
    required this.totalValidationErrors,
    required this.recentAuditEntries,
  });

  final int totalQuestions;
  final int publishedQuestions;
  final int draftQuestions;
  final int pendingReviewQuestions;
  final int approvedQuestions;
  final int rejectedQuestions;
  final Map<QuestionSubject, int> bySubject;
  final Map<QuestionLanguage, int> byLanguage;
  final List<ImportHistoryEntry> importHistory;
  final int totalValidationErrors;
  final List<AdminAuditEntry> recentAuditEntries;
}
