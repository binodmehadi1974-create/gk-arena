import 'package:flutter/foundation.dart';
import 'package:gk_arena/features/admin/models/admin_models.dart';
import 'package:gk_arena/features/admin/models/verification_models.dart';
import 'package:gk_arena/features/admin/services/admin_access_service.dart';
import 'package:gk_arena/features/admin/services/bulk_import_service.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';
import 'package:gk_arena/features/question_bank/services/content_intelligence_service.dart';

/// Secure Admin & Review repository enforcing role authorization, audit
/// logging, paginated queries (100k+ safe), workflow transitions, and bulk import.
class AdminRepository extends ChangeNotifier {
  AdminRepository({
    required this.questionRepository,
    required this.accessService,
    BulkImportService? bulkImportService,
  }) : bulkImportService = bulkImportService ??
            BulkImportService(repository: questionRepository);

  final QuestionRepository questionRepository;
  final AdminAccessService accessService;
  final BulkImportService bulkImportService;

  final List<AdminAuditEntry> _auditLog = <AdminAuditEntry>[];
  final List<ImportHistoryEntry> _importHistory = <ImportHistoryEntry>[];
  final List<VerificationHistoryEntry> _verificationHistory = <VerificationHistoryEntry>[];
  int _seq = 0;

  List<AdminAuditEntry> get auditLog =>
      List<AdminAuditEntry>.unmodifiable(_auditLog);
  List<VerificationHistoryEntry> get verificationHistory =>
      List<VerificationHistoryEntry>.unmodifiable(_verificationHistory);
  List<ImportHistoryEntry> get importHistory =>
      List<ImportHistoryEntry>.unmodifiable(_importHistory);

  void _recordAudit({
    required String actorUid,
    required String action,
    required String targetId,
    required String details,
  }) {
    _seq++;
    _auditLog.insert(
      0,
      AdminAuditEntry(
        id: 'audit_${DateTime.now().toUtc().microsecondsSinceEpoch}_$_seq',
        actorUid: actorUid,
        action: action,
        targetId: targetId,
        details: details,
        timestamp: DateTime.now().toUtc(),
      ),
    );
  }

  /// Computes real dashboard metrics using SQL COUNT queries (never loads all
  /// questions into memory and never fabricates statistics).
  Future<AdminDashboardMetrics> getDashboardMetrics({
    required AdminSession? session,
  }) async {
    accessService.requireReviewer(session);

    final int total = await questionRepository.count();
    final int published = await questionRepository.count(
      filter: const QuestionFilter(publicationStatus: PublicationStatus.published),
    );
    final int draft = await questionRepository.count(
      filter: const QuestionFilter(publicationStatus: PublicationStatus.draft),
    );
    final int pending = await questionRepository.count(
      filter: const QuestionFilter(
        publicationStatus: PublicationStatus.pendingReview,
      ),
    );
    final int approved = await questionRepository.count(
      filter: const QuestionFilter(publicationStatus: PublicationStatus.approved),
    );
    final int rejected = await questionRepository.count(
      filter: const QuestionFilter(publicationStatus: PublicationStatus.rejected),
    );

    final Map<QuestionSubject, int> bySubject = <QuestionSubject, int>{};
    for (final QuestionSubject subject in QuestionSubject.values) {
      bySubject[subject] = await questionRepository.count(
        filter: QuestionFilter(subject: subject),
      );
    }

    final Map<QuestionLanguage, int> byLanguage = <QuestionLanguage, int>{};
    for (final QuestionLanguage lang in QuestionLanguage.values) {
      byLanguage[lang] = await questionRepository.count(
        filter: QuestionFilter(language: lang),
      );
    }

    final int totalValidationErrors = _importHistory.fold<int>(
      0,
      (int sum, ImportHistoryEntry e) => sum + e.rejectedCount,
    );

    return AdminDashboardMetrics(
      totalQuestions: total,
      publishedQuestions: published,
      draftQuestions: draft,
      pendingReviewQuestions: pending,
      approvedQuestions: approved,
      rejectedQuestions: rejected,
      bySubject: bySubject,
      byLanguage: byLanguage,
      importHistory: importHistory,
      totalValidationErrors: totalValidationErrors,
      recentAuditEntries: _auditLog.take(20).toList(growable: false),
    );
  }

  /// Paginated question browser designed for 100,000+ MCQs.
  Future<PaginatedQuestionsResult> getQuestionsPage({
    required AdminSession? session,
    int page = 0,
    int pageSize = 20,
    String? searchQuery,
    QuestionSubject? subject,
    String? topic,
    QuestionLanguage? language,
    QuestionDifficulty? difficulty,
    PublicationStatus? status,
  }) async {
    accessService.requireReviewer(session);
    final int safePage = page < 0 ? 0 : page;
    final int safePageSize = pageSize.clamp(5, 100);

    final QuestionFilter countFilter = QuestionFilter(
      searchQuery: searchQuery,
      subject: subject,
      topic: topic,
      language: language,
      difficulty: difficulty,
      publicationStatus: status,
    );
    final int total = await questionRepository.count(filter: countFilter);

    final List<Question> items = await questionRepository.query(
      QuestionFilter(
        searchQuery: searchQuery,
        subject: subject,
        topic: topic,
        language: language,
        difficulty: difficulty,
        publicationStatus: status,
        limit: safePageSize,
        offset: safePage * safePageSize,
      ),
    );

    return PaginatedQuestionsResult(
      items: items,
      page: safePage,
      pageSize: safePageSize,
      totalItems: total,
    );
  }

  Future<QuestionSaveResult> addQuestion({
    required AdminSession? session,
    required Question question,
  }) async {
    accessService.requireAdmin(session);
    final QuestionSaveResult result =
        await questionRepository.saveQuestion(question);
    if (result.saved) {
      _recordAudit(
        actorUid: session!.uid,
        action: 'ADD_QUESTION',
        targetId: question.id,
        details:
            'Added ${question.subject.id} question (${question.publicationStatus.code}).',
      );
      notifyListeners();
    }
    return result;
  }

  Future<QuestionSaveResult> updateQuestion({
    required AdminSession? session,
    required Question question,
  }) async {
    accessService.requireAdmin(session);
    final QuestionSaveResult result =
        await questionRepository.updateQuestion(question);
    if (result.saved) {
      _recordAudit(
        actorUid: session!.uid,
        action: 'UPDATE_QUESTION',
        targetId: question.id,
        details: 'Updated question (${question.publicationStatus.code}).',
      );
      notifyListeners();
    }
    return result;
  }

  Future<bool> deleteQuestion({
    required AdminSession? session,
    required String questionId,
  }) async {
    accessService.requireAdmin(session);
    final bool deleted = await questionRepository.deleteQuestion(questionId);
    if (deleted) {
      _recordAudit(
        actorUid: session!.uid,
        action: 'DELETE_QUESTION',
        targetId: questionId,
        details: 'Deleted question permanently.',
      );
      notifyListeners();
    }
    return deleted;
  }

  Future<int> bulkDeleteQuestions({
    required AdminSession? session,
    required List<String> questionIds,
  }) async {
    accessService.requireAdmin(session);
    final int deleted = await questionRepository.deleteBatch(questionIds);
    if (deleted > 0) {
      _recordAudit(
        actorUid: session!.uid,
        action: 'BULK_DELETE_QUESTIONS',
        targetId: '${questionIds.length}_items',
        details: 'Bulk deleted $deleted questions.',
      );
      notifyListeners();
    }
    return deleted;
  }

  /// Transitions workflow status: Draft -> Pending Review -> Approved -> Published / Rejected.
  /// Publishing requires full Admin role; reviewers can approve or reject.
  Future<QuestionSaveResult> transitionStatus({
    required AdminSession? session,
    required String questionId,
    required PublicationStatus nextStatus,
    VerificationStatus? factualVerification,
  }) async {
    if (nextStatus == PublicationStatus.published) {
      accessService.requireAdmin(session);
    } else {
      accessService.requireReviewer(session);
    }

    final Question? existing = await questionRepository.getById(questionId);
    if (existing == null) {
      return QuestionSaveResult(
        saved: false,
        errors: <String>['Question "$questionId" not found.'],
      );
    }

    final Question updated = existing.copyWith(
      publicationStatus: nextStatus,
      verificationStatus: factualVerification ?? existing.verificationStatus,
      updatedAt: DateTime.now().toUtc(),
    );
    final QuestionSaveResult res =
        await questionRepository.updateQuestion(updated);
    if (res.saved) {
      _recordAudit(
        actorUid: session!.uid,
        action: 'STATUS_${nextStatus.code.toUpperCase()}',
        targetId: questionId,
        details:
            'Transitioned ${existing.publicationStatus.code} -> ${nextStatus.code}.',
      );
      notifyListeners();
    }
    return res;
  }

  Future<DetailedImportPreview> previewBulkImport({
    required AdminSession? session,
    required String format,
    required String content,
    PublicationStatus defaultStatus = PublicationStatus.draft,
  }) async {
    accessService.requireAdmin(session);
    if (format.toLowerCase() == 'csv') {
      return bulkImportService.previewCsv(
        content,
        defaultStatus: defaultStatus,
      );
    }
    return bulkImportService.previewJson(
      content,
      defaultStatus: defaultStatus,
    );
  }

  /// Commits a previously previewed bulk import in safe chunked batches and
  /// records both ImportHistoryEntry and AdminAuditEntry.
  Future<ImportHistoryEntry> commitBulkImport({
    required AdminSession? session,
    required ImportPreviewReport preview,
    int chunkSize = 250,
    void Function(int processed, int total)? onProgress,
    bool Function()? isCancelled,
  }) async {
    accessService.requireAdmin(session);

    int totalInserted = 0;
    int totalDup = 0;
    int totalInvalid = 0;
    final List<String> batchErrors = <String>[];
    final List<Question> queue = preview.validQuestions;

    for (int start = 0; start < queue.length; start += chunkSize) {
      if (isCancelled != null && isCancelled()) break;
      final int end = (start + chunkSize < queue.length)
          ? start + chunkSize
          : queue.length;
      final BatchImportReport chunkReport =
          await questionRepository.saveBatch(queue.sublist(start, end));
      totalInserted += chunkReport.insertedCount;
      totalDup += chunkReport.duplicateCount;
      totalInvalid += chunkReport.invalidCount;
      batchErrors.addAll(chunkReport.errors);
      onProgress?.call(end, queue.length);
    }

    final BatchImportReport batchReport = BatchImportReport(
      totalReceived: queue.length,
      insertedCount: totalInserted,
      duplicateCount: totalDup,
      invalidCount: totalInvalid,
      errors: batchErrors,
    );

    _seq++;
    final ImportHistoryEntry entry = ImportHistoryEntry(
      importId: 'imp_${DateTime.now().toUtc().microsecondsSinceEpoch}_$_seq',
      actorUid: session!.uid,
      format: preview.format,
      importedAt: DateTime.now().toUtc(),
      totalRows: preview.totalRows,
      importedCount: batchReport.insertedCount,
      skippedDuplicates: preview.duplicateCount + batchReport.duplicateCount,
      rejectedCount: preview.invalidCount + batchReport.invalidCount,
      errors: List<String>.unmodifiable(<String>[
        ...preview.errors,
        ...batchReport.errors,
      ]),
    );

    _importHistory.insert(0, entry);
    _recordAudit(
      actorUid: session.uid,
      action: 'BULK_IMPORT_${preview.format.toUpperCase()}',
      targetId: entry.importId,
      details:
          'Imported ${entry.importedCount}, skipped ${entry.skippedDuplicates}, rejected ${entry.rejectedCount}.',
    );
    notifyListeners();
    return entry;
  }

  QuestionQualityReport inspectQuestionQuality(Question question) {
    return const QuestionQualityController().inspect(question);
  }

  /// Exports paginated/filtered questions to JSON for authorized administrators.
  Future<String> exportQuestionsJson({
    required AdminSession? session,
    QuestionFilter filter = const QuestionFilter(limit: 500),
  }) async {
    accessService.requireAdmin(session);
    final List<Question> items = await questionRepository.query(filter);
    _recordAudit(
      actorUid: session!.uid,
      action: 'EXPORT_QUESTIONS_JSON',
      targetId: '${items.length}_items',
      details: 'Exported ${items.length} questions to JSON.',
    );
    return const QuestionBankExportService().exportToJson(items);
  }

  /// Authorized reviewer factual verification action (Draft / Pending Review /
  /// Verified / Rejected) with immutable VerificationHistoryEntry logging.
  Future<QuestionSaveResult> reviewVerificationStatus({
    required AdminSession? session,
    required String questionId,
    required VerificationStatus newStatus,
    String note = '',
  }) async {
    accessService.requireReviewer(session);
    final Question? existing = await questionRepository.getById(questionId);
    if (existing == null) {
      return QuestionSaveResult(
        saved: false,
        errors: <String>['Question "$questionId" not found.'],
      );
    }

    final Question updated = existing.copyWith(
      verificationStatus: newStatus,
      updatedAt: DateTime.now().toUtc(),
    );
    final QuestionSaveResult result =
        await questionRepository.updateQuestion(updated);
    if (result.saved) {
      _seq++;
      _verificationHistory.insert(
        0,
        VerificationHistoryEntry(
          id: 'ver_${DateTime.now().toUtc().microsecondsSinceEpoch}_$_seq',
          questionId: questionId,
          reviewerUid: session!.uid,
          previousStatus: existing.verificationStatus,
          newStatus: newStatus,
          note: note.trim(),
          timestamp: DateTime.now().toUtc(),
        ),
      );
      _recordAudit(
        actorUid: session.uid,
        action: 'VERIFY_${newStatus.code.toUpperCase()}',
        targetId: questionId,
        details:
            'Verification ${existing.verificationStatus.code} -> ${newStatus.code}. ${note.trim()}',
      );
      notifyListeners();
    }
    return result;
  }
}
