import 'package:gk_arena/features/admin/models/admin_models.dart';

class AdminAuthorizationException implements Exception {
  const AdminAuthorizationException(this.message);
  final String message;

  @override
  String toString() => 'AdminAuthorizationException: $message';
}

/// Backend-enforced authorization contract for Admin & Reviewer operations.
/// Never relies on hidden UI buttons or hardcoded passwords.
abstract class AdminAccessService {
  bool get isBackendConfigured;

  void requireAdmin(AdminSession? session);
  void requireReviewer(AdminSession? session);
}

/// Default runtime guard when Firebase Custom Claims backend is not yet configured.
/// Strictly blocks all admin mutations instead of weakening security for a demo.
class BackendEnforcedAdminAccessService implements AdminAccessService {
  @override
  bool get isBackendConfigured => false;

  @override
  void requireAdmin(AdminSession? session) {
    if (!isBackendConfigured) {
      throw const AdminAuthorizationException(
        'Admin backend authorization (Firebase Auth Custom Claims + Firestore Rules) '
        'is not configured in this build. Admin mutations are blocked for security.',
      );
    }
    if (session == null || !session.canAdminister) {
      throw const AdminAuthorizationException(
        'Administrator privileges verified by the backend are required.',
      );
    }
  }

  @override
  void requireReviewer(AdminSession? session) {
    if (!isBackendConfigured) {
      throw const AdminAuthorizationException(
        'Reviewer backend authorization is not configured in this build.',
      );
    }
    if (session == null || !session.canReview) {
      throw const AdminAuthorizationException(
        'Reviewer or Administrator privileges are required.',
      );
    }
  }
}

/// Deterministic authorization guard strictly for unit testing role separation
/// (admin allowed, reviewer allowed for review only, student always denied).
class InMemoryTestAdminAccessService implements AdminAccessService {
  @override
  bool get isBackendConfigured => true;

  @override
  void requireAdmin(AdminSession? session) {
    if (session == null || !session.canAdminister) {
      throw const AdminAuthorizationException(
        'Access denied: Admin role with backend verification required.',
      );
    }
  }

  @override
  void requireReviewer(AdminSession? session) {
    if (session == null || !session.canReview) {
      throw const AdminAuthorizationException(
        'Access denied: Reviewer or Admin role required.',
      );
    }
  }
}
