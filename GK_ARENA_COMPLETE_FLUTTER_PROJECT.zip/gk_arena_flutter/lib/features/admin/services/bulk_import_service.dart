import 'dart:convert';
import 'package:gk_arena/features/admin/models/admin_models.dart';
import 'package:gk_arena/features/admin/models/verification_models.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';
import 'package:gk_arena/features/question_bank/services/content_intelligence_service.dart';
import 'package:gk_arena/features/question_bank/validation/question_validator.dart';

/// Extended preview report including structured validation failures,
/// duplicate review details, and warnings.
class DetailedImportPreview extends ImportPreviewReport {
  const DetailedImportPreview({
    required super.format,
    required super.totalRows,
    required super.validQuestions,
    required super.duplicateCount,
    required super.invalidCount,
    required super.rows,
    required super.errors,
    required this.validationFailures,
    required this.duplicateMatches,
    required this.warnings,
  });

  final List<ValidationFailureDetail> validationFailures;
  final List<DuplicateMatchDetail> duplicateMatches;
  final List<String> warnings;
}

/// Bulk JSON & CSV Import Preview + Advanced Quality Verification engine.
/// - Detects duplicates via unique ID AND normalized(text) + language + subject + topic.
/// - Detects malformed records, invalid options, missing explanations, and
///   translation mismatches where detectable.
/// - Never automatically marks imported questions as factually Verified.
class BulkImportService {
  const BulkImportService({
    required this.repository,
    this.validator = const QuestionValidator(),
    this.qualityController = const QuestionQualityController(),
  });

  final QuestionRepository repository;
  final QuestionValidator validator;
  final QuestionQualityController qualityController;

  static final RegExp _devanagariRegex = RegExp(r'[\u0900-\u097F]');
  static const int maxImportBytes = 10 * 1024 * 1024; // 10 MB safe cap
  static const int maxRowsPerImport = 25000;

  String _semanticDuplicateKey(Question q) {
    final String normText = QuestionTextNormalizer.normalize(q.questionText);
    final String normTopic = q.topic.trim().toLowerCase();
    return '${q.language.code}::${q.subject.id}::$normTopic::$normText';
  }

  List<String> _checkTranslationMismatch(Question q) {
    final List<String> warnings = <String>[];
    final String hi = (q.questionTextHi ?? '').trim();
    final String en = (q.questionTextEn ?? '').trim();

    if (hi.isNotEmpty && en.isNotEmpty) {
      if (QuestionTextNormalizer.normalize(hi) ==
          QuestionTextNormalizer.normalize(en)) {
        warnings.add(
          'Translation mismatch: Hindi and English question texts are identical.',
        );
      }
      if (!_devanagariRegex.hasMatch(hi)) {
        warnings.add(
          'Translation mismatch: Hindi field contains no Devanagari characters.',
        );
      }
    }
    return warnings;
  }

  Future<DetailedImportPreview> previewJson(
    String jsonContent, {
    PublicationStatus defaultStatus = PublicationStatus.draft,
  }) async {
    if (utf8.encode(jsonContent).length > maxImportBytes) {
      const String msg = 'Import file exceeds 10 MB safety limit. Split into smaller batches.';
      return const DetailedImportPreview(
        format: 'json',
        totalRows: 0,
        validQuestions: <Question>[],
        duplicateCount: 0,
        invalidCount: 1,
        rows: <ImportPreviewRow>[],
        errors: <String>[msg],
        validationFailures: <ValidationFailureDetail>[
          ValidationFailureDetail(rowNumber: 0, questionId: 'FILE', errors: <String>[msg]),
        ],
        duplicateMatches: <DuplicateMatchDetail>[],
        warnings: <String>[],
      );
    }
    final Object? decoded;
    try {
      decoded = jsonDecode(jsonContent);
    } catch (e) {
      final String msg = 'Malformed JSON file: $e';
      return DetailedImportPreview(
        format: 'json',
        totalRows: 0,
        validQuestions: const <Question>[],
        duplicateCount: 0,
        invalidCount: 1,
        rows: const <ImportPreviewRow>[],
        errors: <String>[msg],
        validationFailures: <ValidationFailureDetail>[
          ValidationFailureDetail(
            rowNumber: 0,
            questionId: 'FILE',
            errors: <String>[msg],
          ),
        ],
        duplicateMatches: const <DuplicateMatchDetail>[],
        warnings: const <String>[],
      );
    }

    final List<dynamic> rawList;
    if (decoded is List<dynamic>) {
      rawList = decoded;
    } else if (decoded is Map<String, dynamic> && decoded['questions'] is List) {
      rawList = decoded['questions'] as List<dynamic>;
    } else {
      const String msg =
          'Invalid JSON structure: expected a list of questions or {"questions": [...]}.';
      return const DetailedImportPreview(
        format: 'json',
        totalRows: 0,
        validQuestions: <Question>[],
        duplicateCount: 0,
        invalidCount: 1,
        rows: <ImportPreviewRow>[],
        errors: <String>[msg],
        validationFailures: <ValidationFailureDetail>[
          ValidationFailureDetail(
            rowNumber: 0,
            questionId: 'FILE',
            errors: <String>[msg],
          ),
        ],
        duplicateMatches: <DuplicateMatchDetail>[],
        warnings: <String>[],
      );
    }

    final List<Question> validQuestions = <Question>[];
    final List<ImportPreviewRow> previewRows = <ImportPreviewRow>[];
    final List<String> errors = <String>[];
    final List<String> warnings = <String>[];
    final List<ValidationFailureDetail> validationFailures =
        <ValidationFailureDetail>[];
    final List<DuplicateMatchDetail> duplicateMatches =
        <DuplicateMatchDetail>[];

    final Set<String> seenIds = <String>{};
    final Set<String> seenSemanticKeys = <String>{};
    final Set<String> seenTextKeys = <String>{};
    int duplicateCount = 0;
    int invalidCount = 0;

    for (int i = 0; i < rawList.length; i++) {
      final int rowNum = i + 1;
      final dynamic raw = rawList[i];
      if (raw is! Map<String, dynamic>) {
        invalidCount++;
        final String msg = 'Row $rowNum: Malformed record (expected JSON object).';
        errors.add(msg);
        validationFailures.add(
          ValidationFailureDetail(
            rowNumber: rowNum,
            questionId: 'row_$rowNum',
            errors: <String>[msg],
          ),
        );
        previewRows.add(
          ImportPreviewRow(
            rowNumber: rowNum,
            status: ImportRowStatus.invalid,
            errors: <String>[msg],
          ),
        );
        continue;
      }

      Question parsed;
      try {
        // Strictly prevent automatic factual verification on import.
        final String rawVer =
            (raw['verification_status'] ?? 'pending_review').toString().trim().toLowerCase();
        final String safeVer = rawVer == 'verified'
            ? VerificationStatus.pendingReview.code
            : (rawVer.isEmpty ? VerificationStatus.pendingReview.code : rawVer);

        final Map<String, Object?> normalizedMap = <String, Object?>{
          ...raw,
          'publication_status': raw['publication_status'] ?? defaultStatus.code,
          'verification_status': safeVer,
        };
        parsed = Question.fromJson(normalizedMap);
      } catch (e) {
        invalidCount++;
        final String msg = 'Row $rowNum: $e';
        errors.add(msg);
        validationFailures.add(
          ValidationFailureDetail(
            rowNumber: rowNum,
            questionId: (raw['id'] ?? 'row_$rowNum').toString(),
            errors: <String>[msg],
          ),
        );
        previewRows.add(
          ImportPreviewRow(
            rowNumber: rowNum,
            status: ImportRowStatus.invalid,
            errors: <String>[msg],
          ),
        );
        continue;
      }

      final QuestionQualityReport qc = qualityController.inspect(parsed);
      final List<String> rowWarnings = <String>[
        ...qc.warnings,
        ..._checkTranslationMismatch(parsed),
      ];
      if (rowWarnings.isNotEmpty) {
        warnings.add('Row $rowNum (${parsed.id}): ${rowWarnings.join(' ')}');
      }

      if (!qc.isTechnicallyValid) {
        invalidCount++;
        final String msg = 'Row $rowNum (${parsed.id}): ${qc.errors.join(' ')}';
        errors.add(msg);
        validationFailures.add(
          ValidationFailureDetail(
            rowNumber: rowNum,
            questionId: parsed.id.isEmpty ? 'row_$rowNum' : parsed.id,
            errors: qc.errors,
            warnings: rowWarnings,
          ),
        );
        previewRows.add(
          ImportPreviewRow(
            rowNumber: rowNum,
            question: parsed,
            status: ImportRowStatus.invalid,
            errors: qc.errors,
          ),
        );
        continue;
      }

      final String normalizedText =
          QuestionTextNormalizer.normalize(parsed.questionText);
      final String textKey = '${parsed.language.code}::$normalizedText';
      final String semanticKey = _semanticDuplicateKey(parsed);

      String? dupReason;
      if (!seenIds.add(parsed.id)) {
        dupReason = 'Duplicate question ID within import file.';
      } else if (!seenSemanticKeys.add(semanticKey) || !seenTextKeys.add(textKey)) {
        dupReason =
            'Duplicate normalized question text + language + subject/topic within import file.';
      } else if ((await repository.getById(parsed.id)) != null) {
        dupReason = 'Question ID already exists in Question Bank.';
      } else if (await repository.isDuplicateQuestion(
        parsed.questionText,
        language: parsed.language,
      )) {
        dupReason =
            'Normalized question text already exists in Question Bank for this language.';
      }

      if (dupReason != null) {
        duplicateCount++;
        duplicateMatches.add(
          DuplicateMatchDetail(
            rowNumber: rowNum,
            incomingId: parsed.id,
            incomingText: parsed.questionText,
            subjectId: parsed.subject.id,
            topic: parsed.topic,
            languageCode: parsed.language.code,
            reason: dupReason,
          ),
        );
        previewRows.add(
          ImportPreviewRow(
            rowNumber: rowNum,
            question: parsed,
            status: ImportRowStatus.duplicate,
            errors: <String>[dupReason],
          ),
        );
        continue;
      }

      validQuestions.add(parsed);
      previewRows.add(
        ImportPreviewRow(
          rowNumber: rowNum,
          question: parsed,
          status: ImportRowStatus.valid,
        ),
      );
    }

    return DetailedImportPreview(
      format: 'json',
      totalRows: rawList.length,
      validQuestions: List<Question>.unmodifiable(validQuestions),
      duplicateCount: duplicateCount,
      invalidCount: invalidCount,
      rows: List<ImportPreviewRow>.unmodifiable(previewRows),
      errors: List<String>.unmodifiable(errors),
      validationFailures:
          List<ValidationFailureDetail>.unmodifiable(validationFailures),
      duplicateMatches:
          List<DuplicateMatchDetail>.unmodifiable(duplicateMatches),
      warnings: List<String>.unmodifiable(warnings),
    );
  }

  Future<DetailedImportPreview> previewCsv(
    String csvContent, {
    PublicationStatus defaultStatus = PublicationStatus.draft,
  }) async {
    if (utf8.encode(csvContent).length > maxImportBytes) {
      const String msg = 'CSV file exceeds 10 MB safety limit. Split into smaller batches.';
      return const DetailedImportPreview(
        format: 'csv',
        totalRows: 0,
        validQuestions: <Question>[],
        duplicateCount: 0,
        invalidCount: 1,
        rows: <ImportPreviewRow>[],
        errors: <String>[msg],
        validationFailures: <ValidationFailureDetail>[
          ValidationFailureDetail(rowNumber: 0, questionId: 'FILE', errors: <String>[msg]),
        ],
        duplicateMatches: <DuplicateMatchDetail>[],
        warnings: <String>[],
      );
    }
    final List<String> lines = const LineSplitter()
        .convert(csvContent)
        .where((String line) => line.trim().isNotEmpty)
        .toList(growable: false);

    if (lines.length <= 1) {
      const String msg = 'CSV file has no data rows after header.';
      return const DetailedImportPreview(
        format: 'csv',
        totalRows: 0,
        validQuestions: <Question>[],
        duplicateCount: 0,
        invalidCount: 1,
        rows: <ImportPreviewRow>[],
        errors: <String>[msg],
        validationFailures: <ValidationFailureDetail>[
          ValidationFailureDetail(
            rowNumber: 0,
            questionId: 'FILE',
            errors: <String>[msg],
          ),
        ],
        duplicateMatches: <DuplicateMatchDetail>[],
        warnings: <String>[],
      );
    }

    final List<Question> validQuestions = <Question>[];
    final List<ImportPreviewRow> previewRows = <ImportPreviewRow>[];
    final List<String> errors = <String>[];
    final List<String> warnings = <String>[];
    final List<ValidationFailureDetail> validationFailures =
        <ValidationFailureDetail>[];
    final List<DuplicateMatchDetail> duplicateMatches =
        <DuplicateMatchDetail>[];

    final Set<String> seenIds = <String>{};
    final Set<String> seenSemanticKeys = <String>{};
    final Set<String> seenTextKeys = <String>{};
    int duplicateCount = 0;
    int invalidCount = 0;
    final DateTime now = DateTime.now().toUtc();

    for (int i = 1; i < lines.length; i++) {
      final int rowNum = i + 1;
      final List<String> cols = _parseCsvRow(lines[i]);
      if (cols.length < 17) {
        invalidCount++;
        final String msg =
            'CSV row $rowNum: Expected at least 17 columns, found ${cols.length}.';
        errors.add(msg);
        validationFailures.add(
          ValidationFailureDetail(
            rowNumber: rowNum,
            questionId: cols.isNotEmpty ? cols[0].trim() : 'row_$rowNum',
            errors: <String>[msg],
          ),
        );
        previewRows.add(
          ImportPreviewRow(
            rowNumber: rowNum,
            status: ImportRowStatus.invalid,
            errors: <String>[msg],
          ),
        );
        continue;
      }

      Question parsed;
      try {
        final VerificationStatus rawVer = VerificationStatus.fromCode(cols[16]);
        final VerificationStatus safeVer =
            rawVer == VerificationStatus.verified
                ? VerificationStatus.pendingReview
                : rawVer;
        final String chapter = cols.length >= 18 ? cols[17].trim() : '';

        parsed = Question(
          id: cols[0].trim(),
          questionText: cols[1].trim(),
          options: <String>[
            cols[2].trim(),
            cols[3].trim(),
            cols[4].trim(),
            cols[5].trim(),
          ],
          correctOptionIndex: int.parse(cols[6].trim()),
          explanation: cols[7].trim(),
          subject: QuestionSubject.fromId(cols[8]),
          chapter: chapter,
          topic: cols[9].trim(),
          subtopic: cols[10].trim(),
          difficulty: QuestionDifficulty.fromCode(cols[11]),
          language: QuestionLanguage.fromCode(cols[12]),
          examCategory: ExamCategory.fromCode(cols[13]),
          questionType: QuestionType.fromCode(cols[14]),
          sourceReference: cols[15].trim(),
          verificationStatus: safeVer,
          publicationStatus: defaultStatus,
          createdAt: now,
          updatedAt: now,
          isSample: false,
        );
      } catch (e) {
        invalidCount++;
        final String msg = 'CSV row $rowNum: $e';
        errors.add(msg);
        validationFailures.add(
          ValidationFailureDetail(
            rowNumber: rowNum,
            questionId: cols[0].trim().isEmpty ? 'row_$rowNum' : cols[0].trim(),
            errors: <String>[msg],
          ),
        );
        previewRows.add(
          ImportPreviewRow(
            rowNumber: rowNum,
            status: ImportRowStatus.invalid,
            errors: <String>[msg],
          ),
        );
        continue;
      }

      final QuestionQualityReport qc = qualityController.inspect(parsed);
      if (qc.warnings.isNotEmpty) {
        warnings.add('CSV row $rowNum (${parsed.id}): ${qc.warnings.join(' ')}');
      }
      if (!qc.isTechnicallyValid) {
        invalidCount++;
        final String msg =
            'CSV row $rowNum (${parsed.id}): ${qc.errors.join(' ')}';
        errors.add(msg);
        validationFailures.add(
          ValidationFailureDetail(
            rowNumber: rowNum,
            questionId: parsed.id.isEmpty ? 'row_$rowNum' : parsed.id,
            errors: qc.errors,
            warnings: qc.warnings,
          ),
        );
        previewRows.add(
          ImportPreviewRow(
            rowNumber: rowNum,
            question: parsed,
            status: ImportRowStatus.invalid,
            errors: qc.errors,
          ),
        );
        continue;
      }

      final String normalizedText =
          QuestionTextNormalizer.normalize(parsed.questionText);
      final String textKey = '${parsed.language.code}::$normalizedText';
      final String semanticKey = _semanticDuplicateKey(parsed);

      String? dupReason;
      if (!seenIds.add(parsed.id)) {
        dupReason = 'Duplicate question ID within CSV file.';
      } else if (!seenSemanticKeys.add(semanticKey) || !seenTextKeys.add(textKey)) {
        dupReason =
            'Duplicate normalized question text + language + subject/topic within CSV file.';
      } else if ((await repository.getById(parsed.id)) != null) {
        dupReason = 'Question ID already exists in Question Bank.';
      } else if (await repository.isDuplicateQuestion(
        parsed.questionText,
        language: parsed.language,
      )) {
        dupReason =
            'Normalized question text already exists in Question Bank for this language.';
      }

      if (dupReason != null) {
        duplicateCount++;
        duplicateMatches.add(
          DuplicateMatchDetail(
            rowNumber: rowNum,
            incomingId: parsed.id,
            incomingText: parsed.questionText,
            subjectId: parsed.subject.id,
            topic: parsed.topic,
            languageCode: parsed.language.code,
            reason: dupReason,
          ),
        );
        previewRows.add(
          ImportPreviewRow(
            rowNumber: rowNum,
            question: parsed,
            status: ImportRowStatus.duplicate,
            errors: <String>[dupReason],
          ),
        );
        continue;
      }

      validQuestions.add(parsed);
      previewRows.add(
        ImportPreviewRow(
          rowNumber: rowNum,
          question: parsed,
          status: ImportRowStatus.valid,
        ),
      );
    }

    return DetailedImportPreview(
      format: 'csv',
      totalRows: lines.length - 1,
      validQuestions: List<Question>.unmodifiable(validQuestions),
      duplicateCount: duplicateCount,
      invalidCount: invalidCount,
      rows: List<ImportPreviewRow>.unmodifiable(previewRows),
      errors: List<String>.unmodifiable(errors),
      validationFailures:
          List<ValidationFailureDetail>.unmodifiable(validationFailures),
      duplicateMatches:
          List<DuplicateMatchDetail>.unmodifiable(duplicateMatches),
      warnings: List<String>.unmodifiable(warnings),
    );
  }

  List<String> _parseCsvRow(String line) {
    final List<String> fields = <String>[];
    final StringBuffer current = StringBuffer();
    bool inQuotes = false;

    for (int i = 0; i < line.length; i++) {
      final String ch = line[i];
      if (ch == '"') {
        if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
          current.write('"');
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (ch == ',' && !inQuotes) {
        fields.add(current.toString());
        current.clear();
      } else {
        current.write(ch);
      }
    }
    fields.add(current.toString());
    return fields;
  }
}
