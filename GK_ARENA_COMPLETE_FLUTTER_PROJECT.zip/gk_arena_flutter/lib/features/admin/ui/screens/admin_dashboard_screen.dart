import 'package:flutter/material.dart';
import 'package:gk_arena/features/admin/models/admin_models.dart';
import 'package:gk_arena/features/admin/repositories/admin_repository.dart';
import 'package:gk_arena/features/admin/ui/screens/admin_bulk_import_screen.dart';
import 'package:gk_arena/features/admin/ui/screens/admin_question_manager_screen.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/navigation/smooth_page_route.dart';
import 'package:gk_arena/ui/widgets/premium_button.dart';
import 'package:gk_arena/ui/widgets/state_views.dart';

/// Separate, backend-authorized Admin Dashboard displaying real Question Bank
/// counts, import history, validation error totals, and recent audit logs.
class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({
    super.key,
    required this.adminRepository,
    required this.session,
  });

  final AdminRepository adminRepository;
  final AdminSession? session;

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  bool _loading = true;
  String? _authError;
  AdminDashboardMetrics? _metrics;

  @override
  void initState() {
    super.initState();
    widget.adminRepository.addListener(_loadMetrics);
    _loadMetrics();
  }

  @override
  void dispose() {
    widget.adminRepository.removeListener(_loadMetrics);
    super.dispose();
  }

  Future<void> _loadMetrics() async {
    try {
      final AdminDashboardMetrics data =
          await widget.adminRepository.getDashboardMetrics(
        session: widget.session,
      );
      if (!mounted) return;
      setState(() {
        _metrics = data;
        _authError = null;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _metrics = null;
        _authError = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final Color surface = AppColors.surfaceOf(context);
    final Color border = AppColors.borderOf(context);
    final Color textPrimary = AppColors.textPrimaryOf(context);
    final Color textSecondary = AppColors.textSecondaryOf(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('GK ARENA Admin Panel'),
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _authError != null
                ? Padding(
                    padding: const EdgeInsets.all(20),
                    child: GkEmptyStateCard(
                      icon: Icons.admin_panel_settings_outlined,
                      badgeText: 'Access Restricted',
                      title: 'Admin Authorization Required',
                      description: _authError!,
                      actionLabel: 'Back',
                      onActionTap: () => Navigator.of(context).pop(),
                    ),
                  )
                : RefreshIndicator(
                    onRefresh: _loadMetrics,
                    child: SingleChildScrollView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(
                        20,
                        AppSpacing.sm,
                        20,
                        AppSpacing.lg,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          // Metric Overview Grid (100% real counts)
                          Wrap(
                            spacing: AppSpacing.sm,
                            runSpacing: AppSpacing.sm,
                            children: <Widget>[
                              _AdminKpiCard(
                                label: 'Total Questions',
                                value: '${_metrics!.totalQuestions}',
                                color: AppColors.primary,
                                surface: surface,
                                border: border,
                              ),
                              _AdminKpiCard(
                                label: 'Published',
                                value: '${_metrics!.publishedQuestions}',
                                color: AppColors.success,
                                surface: surface,
                                border: border,
                              ),
                              _AdminKpiCard(
                                label: 'Drafts',
                                value: '${_metrics!.draftQuestions}',
                                color: AppColors.textSecondary,
                                surface: surface,
                                border: border,
                              ),
                              _AdminKpiCard(
                                label: 'Pending Review',
                                value: '${_metrics!.pendingReviewQuestions}',
                                color: AppColors.warning,
                                surface: surface,
                                border: border,
                              ),
                              _AdminKpiCard(
                                label: 'Validation Errors',
                                value: '${_metrics!.totalValidationErrors}',
                                color: AppColors.danger,
                                surface: surface,
                                border: border,
                              ),
                            ],
                          ),
                          const SizedBox(height: AppSpacing.lg),

                          Row(
                            children: <Widget>[
                              Expanded(
                                child: PremiumButton(
                                  label: 'Manage Questions',
                                  variant: PremiumButtonVariant.primary,
                                  onPressed: () {
                                    Navigator.of(context).push(
                                      SmoothPageRoute<void>(
                                        builder: (_) =>
                                            AdminQuestionManagerScreen(
                                          adminRepository:
                                              widget.adminRepository,
                                          session: widget.session,
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                              const SizedBox(width: AppSpacing.sm),
                              Expanded(
                                child: PremiumButton(
                                  label: 'Bulk Import',
                                  variant: PremiumButtonVariant.soft,
                                  onPressed: () {
                                    Navigator.of(context).push(
                                      SmoothPageRoute<void>(
                                        builder: (_) => AdminBulkImportScreen(
                                          adminRepository:
                                              widget.adminRepository,
                                          session: widget.session,
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: AppSpacing.lg),

                          Text(
                            'Questions by Language',
                            style: AppTextStyles.sectionTitle
                                .copyWith(color: textPrimary),
                          ),
                          const SizedBox(height: AppSpacing.xs),
                          Wrap(
                            spacing: AppSpacing.sm,
                            runSpacing: AppSpacing.xs,
                            children: QuestionLanguage.values.map((lang) {
                              final int cnt = _metrics!.byLanguage[lang] ?? 0;
                              return Chip(
                                label: Text('${lang.labelEn}: $cnt'),
                              );
                            }).toList(growable: false),
                          ),
                          const SizedBox(height: AppSpacing.lg),

                          Text(
                            'Questions by Subject',
                            style: AppTextStyles.sectionTitle
                                .copyWith(color: textPrimary),
                          ),
                          const SizedBox(height: AppSpacing.xs),
                          Container(
                            decoration: BoxDecoration(
                              color: surface,
                              borderRadius:
                                  BorderRadius.circular(AppSpacing.radiusLg),
                              border: Border.all(color: border),
                            ),
                            child: Column(
                              children: QuestionSubject.values.map((subject) {
                                final int cnt =
                                    _metrics!.bySubject[subject] ?? 0;
                                return ListTile(
                                  dense: true,
                                  title: Text(
                                    subject.titleEn,
                                    style: AppTextStyles.bodyPrimary
                                        .copyWith(color: textPrimary),
                                  ),
                                  trailing: Text(
                                    '$cnt',
                                    style: AppTextStyles.cardTitle.copyWith(
                                      color: AppColors.primary,
                                    ),
                                  ),
                                );
                              }).toList(growable: false),
                            ),
                          ),
                          const SizedBox(height: AppSpacing.lg),

                          Text(
                            'Import History (${_metrics!.importHistory.length})',
                            style: AppTextStyles.sectionTitle
                                .copyWith(color: textPrimary),
                          ),
                          const SizedBox(height: AppSpacing.xs),
                          if (_metrics!.importHistory.isEmpty)
                            Text(
                              'No bulk imports recorded yet.',
                              style: AppTextStyles.cardSubtitle
                                  .copyWith(color: textSecondary),
                            )
                          else
                            ..._metrics!.importHistory.take(5).map(
                              (ImportHistoryEntry item) => Container(
                                width: double.infinity,
                                margin: const EdgeInsets.only(
                                  bottom: AppSpacing.xs,
                                ),
                                padding: const EdgeInsets.all(AppSpacing.sm),
                                decoration: BoxDecoration(
                                  color: surface,
                                  borderRadius: BorderRadius.circular(
                                    AppSpacing.radiusMd,
                                  ),
                                  border: Border.all(color: border),
                                ),
                                child: Text(
                                  '${item.format.toUpperCase()} • Imported ${item.importedCount} • '
                                  'Skipped ${item.skippedDuplicates} • Rejected ${item.rejectedCount}',
                                  style: AppTextStyles.bodyPrimary
                                      .copyWith(color: textPrimary),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
      ),
    );
  }
}

class _AdminKpiCard extends StatelessWidget {
  const _AdminKpiCard({
    required this.label,
    required this.value,
    required this.color,
    required this.surface,
    required this.border,
  });

  final String label;
  final String value;
  final Color color;
  final Color surface;
  final Color border;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minWidth: 140, maxWidth: 185),
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        border: Border.all(color: border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            value,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: AppTextStyles.cardSubtitle.copyWith(
              color: AppColors.textSecondaryOf(context),
            ),
          ),
        ],
      ),
    );
  }
}
