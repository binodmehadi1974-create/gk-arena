import 'package:flutter/material.dart';
import 'package:gk_arena/features/admin/models/admin_models.dart';
import 'package:gk_arena/features/admin/repositories/admin_repository.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/widgets/state_views.dart';

/// Paginated Admin Question Management screen supporting ID/text search,
/// subject/language/difficulty/status filters, workflow transitions, and
/// confirmation-gated deletion (100k+ safe).
class AdminQuestionManagerScreen extends StatefulWidget {
  const AdminQuestionManagerScreen({
    super.key,
    required this.adminRepository,
    required this.session,
  });

  final AdminRepository adminRepository;
  final AdminSession? session;

  @override
  State<AdminQuestionManagerScreen> createState() =>
      _AdminQuestionManagerScreenState();
}

class _AdminQuestionManagerScreenState
    extends State<AdminQuestionManagerScreen> {
  final TextEditingController _searchController = TextEditingController();
  int _page = 0;
  static const int _pageSize = 20;

  QuestionSubject? _subjectFilter;
  QuestionLanguage? _languageFilter;
  PublicationStatus? _statusFilter;

  bool _loading = true;
  String? _error;
  PaginatedQuestionsResult? _result;

  @override
  void initState() {
    super.initState();
    _loadPage();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadPage() async {
    setState(() => _loading = true);
    try {
      final PaginatedQuestionsResult res =
          await widget.adminRepository.getQuestionsPage(
        session: widget.session,
        page: _page,
        pageSize: _pageSize,
        searchQuery: _searchController.text.trim(),
        subject: _subjectFilter,
        language: _languageFilter,
        status: _statusFilter,
      );
      if (!mounted) return;
      setState(() {
        _result = res;
        _error = null;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  Future<void> _confirmDelete(Question q) async {
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Delete Question?'),
          content: Text(
            'Permanently delete question "${q.id}"? This action is audited and cannot be undone.',
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );

    if (confirmed == true) {
      try {
        await widget.adminRepository.deleteQuestion(
          session: widget.session,
          questionId: q.id,
        );
        await _loadPage();
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(e.toString())),
          );
        }
      }
    }
  }

  Future<void> _transition(Question q, PublicationStatus next) async {
    try {
      final res = await widget.adminRepository.transitionStatus(
        session: widget.session,
        questionId: q.id,
        nextStatus: next,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            res.saved
                ? 'Question "${q.id}" moved to ${next.label}.'
                : res.errors.join(' '),
          ),
        ),
      );
      await _loadPage();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString())),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final Color surface = AppColors.surfaceOf(context);
    final Color border = AppColors.borderOf(context);
    final Color textPrimary = AppColors.textPrimaryOf(context);
    final Color textSecondary = AppColors.textSecondaryOf(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Question Manager')),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(20, AppSpacing.xs, 20, AppSpacing.xs),
              child: TextField(
                controller: _searchController,
                onSubmitted: (_) {
                  _page = 0;
                  _loadPage();
                },
                decoration: InputDecoration(
                  hintText: 'Search by Question ID or text...',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.arrow_forward_rounded),
                    onPressed: () {
                      _page = 0;
                      _loadPage();
                    },
                  ),
                ),
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
              child: Row(
                children: <Widget>[
                  FilterChip(
                    label: Text(_statusFilter?.label ?? 'All Statuses'),
                    selected: _statusFilter != null,
                    onSelected: (_) {
                      final int nextIdx = _statusFilter == null
                          ? 0
                          : (_statusFilter!.index + 1);
                      setState(() {
                        _statusFilter =
                            nextIdx >= PublicationStatus.values.length
                                ? null
                                : PublicationStatus.values[nextIdx];
                        _page = 0;
                      });
                      _loadPage();
                    },
                  ),
                  const SizedBox(width: AppSpacing.xs),
                  FilterChip(
                    label: Text(_languageFilter?.labelEn ?? 'All Languages'),
                    selected: _languageFilter != null,
                    onSelected: (_) {
                      setState(() {
                        if (_languageFilter == null) {
                          _languageFilter = QuestionLanguage.hindi;
                        } else if (_languageFilter == QuestionLanguage.hindi) {
                          _languageFilter = QuestionLanguage.english;
                        } else {
                          _languageFilter = null;
                        }
                        _page = 0;
                      });
                      _loadPage();
                    },
                  ),
                  const SizedBox(width: AppSpacing.xs),
                  FilterChip(
                    label: Text(_subjectFilter?.titleEn ?? 'All Subjects'),
                    selected: _subjectFilter != null,
                    onSelected: (_) {
                      final int nextIdx = _subjectFilter == null
                          ? 0
                          : (_subjectFilter!.index + 1);
                      setState(() {
                        _subjectFilter = nextIdx >= QuestionSubject.values.length
                            ? null
                            : QuestionSubject.values[nextIdx];
                        _page = 0;
                      });
                      _loadPage();
                    },
                  ),
                ],
              ),
            ),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _error != null
                      ? Padding(
                          padding: const EdgeInsets.all(20),
                          child: GkEmptyStateCard(
                            icon: Icons.error_outline_rounded,
                            title: 'Unable to Load Questions',
                            description: _error!,
                          ),
                        )
                      : (_result == null || _result!.items.isEmpty)
                          ? const Padding(
                              padding: EdgeInsets.all(20),
                              child: GkEmptyStateCard(
                                icon: Icons.quiz_outlined,
                                title: 'No Matching Questions',
                                description:
                                    'Adjust your search or filters to view questions.',
                              ),
                            )
                          : ListView.separated(
                              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                              padding: const EdgeInsets.fromLTRB(
                                20,
                                AppSpacing.xs,
                                20,
                                AppSpacing.md,
                              ),
                              itemCount: _result!.items.length,
                              separatorBuilder: (_, __) =>
                                  const SizedBox(height: AppSpacing.sm),
                              itemBuilder: (BuildContext context, int idx) {
                                final Question q = _result!.items[idx];
                                return Container(
                                  padding: const EdgeInsets.all(AppSpacing.md),
                                  decoration: BoxDecoration(
                                    color: surface,
                                    borderRadius: BorderRadius.circular(
                                      AppSpacing.radiusMd,
                                    ),
                                    border: Border.all(color: border),
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: Text(
                                              '${q.id} • ${q.subject.titleEn} • ${q.language.code.toUpperCase()}',
                                              style: AppTextStyles.badgeLabel
                                                  .copyWith(
                                                color: AppColors.primary,
                                              ),
                                            ),
                                          ),
                                          Chip(
                                            label: Text(
                                              q.publicationStatus.label,
                                              style: AppTextStyles.badgeLabel,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 6),
                                      Text(
                                        q.questionText,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: AppTextStyles.bodyPrimary
                                            .copyWith(color: textPrimary),
                                      ),
                                      const SizedBox(height: 6),
                                      Text(
                                        'Topic: ${q.topic} • Factual Status: ${q.verificationStatus.code}',
                                        style: AppTextStyles.cardSubtitle
                                            .copyWith(color: textSecondary),
                                      ),
                                      const SizedBox(height: AppSpacing.xs),
                                      Wrap(
                                        spacing: 6,
                                        children: <Widget>[
                                          TextButton(
                                            onPressed: () => _transition(
                                              q,
                                              PublicationStatus.pendingReview,
                                            ),
                                            child: const Text('Review'),
                                          ),
                                          TextButton(
                                            onPressed: () => _transition(
                                              q,
                                              PublicationStatus.approved,
                                            ),
                                            child: const Text('Approve'),
                                          ),
                                          TextButton(
                                            onPressed: () => _transition(
                                              q,
                                              PublicationStatus.published,
                                            ),
                                            child: const Text('Publish'),
                                          ),
                                          TextButton(
                                            onPressed: () => _confirmDelete(q),
                                            child: const Text(
                                              'Delete',
                                              style: TextStyle(
                                                color: AppColors.danger,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
            ),
            if (_result != null)
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: AppSpacing.sm,
                ),
                decoration: BoxDecoration(
                  color: surface,
                  border: Border(top: BorderSide(color: border)),
                ),
                child: Row(
                  children: <Widget>[
                    OutlinedButton(
                      onPressed: _result!.hasPreviousPage
                          ? () {
                              _page--;
                              _loadPage();
                            }
                          : null,
                      child: const Text('Previous'),
                    ),
                    Expanded(
                      child: Text(
                        'Page ${_result!.page + 1} / ${_result!.totalPages} (${_result!.totalItems} total)',
                        textAlign: TextAlign.center,
                        style: AppTextStyles.cardSubtitle
                            .copyWith(color: textSecondary),
                      ),
                    ),
                    OutlinedButton(
                      onPressed: _result!.hasNextPage
                          ? () {
                              _page++;
                              _loadPage();
                            }
                          : null,
                      child: const Text('Next'),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
