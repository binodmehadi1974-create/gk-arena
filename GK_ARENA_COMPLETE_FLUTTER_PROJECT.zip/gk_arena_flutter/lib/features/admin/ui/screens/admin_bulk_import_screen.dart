import 'package:flutter/material.dart';
import 'package:gk_arena/features/admin/models/admin_models.dart';
import 'package:gk_arena/features/admin/repositories/admin_repository.dart';
import 'package:gk_arena/features/admin/services/bulk_import_service.dart';
import 'package:gk_arena/features/admin/ui/screens/admin_duplicate_review_screen.dart';
import 'package:gk_arena/features/admin/ui/screens/admin_validation_report_screen.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/navigation/smooth_page_route.dart';
import 'package:gk_arena/ui/widgets/premium_button.dart';

/// Bulk Question Import screen supporting JSON & CSV preview, Validation Report,
/// Duplicate Review, cancellation, live chunked progress, and confirmed commit.
class AdminBulkImportScreen extends StatefulWidget {
  const AdminBulkImportScreen({
    super.key,
    required this.adminRepository,
    required this.session,
  });

  final AdminRepository adminRepository;
  final AdminSession? session;

  @override
  State<AdminBulkImportScreen> createState() => _AdminBulkImportScreenState();
}

class _AdminBulkImportScreenState extends State<AdminBulkImportScreen> {
  final TextEditingController _inputController = TextEditingController();
  String _format = 'json';
  bool _busy = false;
  bool _cancelled = false;
  double _progress = 0.0;
  DetailedImportPreview? _preview;
  ImportHistoryEntry? _committed;

  @override
  void dispose() {
    _inputController.dispose();
    super.dispose();
  }

  Future<void> _runPreview() async {
    setState(() {
      _busy = true;
      _committed = null;
      _progress = 0.0;
    });
    try {
      final DetailedImportPreview report =
          await widget.adminRepository.previewBulkImport(
        session: widget.session,
        format: _format,
        content: _inputController.text,
      );
      if (!mounted) return;
      setState(() {
        _preview = report;
        _busy = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    }
  }

  void _cancelPreview() {
    setState(() {
      _cancelled = true;
      _preview = null;
      _progress = 0.0;
    });
  }

  Future<void> _confirmAndCommit() async {
    final DetailedImportPreview? preview = _preview;
    if (preview == null || preview.validCount == 0) return;

    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Confirm Bulk Import?'),
          content: Text(
            'Valid to import: ${preview.validCount}\n'
            'Duplicates skipped: ${preview.duplicateCount}\n'
            'Invalid rejected: ${preview.invalidCount}\n\n'
            'Imported questions are saved as Draft / Pending Review (never auto-verified).',
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Commit Import'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) return;
    setState(() {
      _busy = true;
      _cancelled = false;
      _progress = 0.0;
    });
    try {
      final ImportHistoryEntry entry =
          await widget.adminRepository.commitBulkImport(
        session: widget.session,
        preview: preview,
        onProgress: (int processed, int total) {
          if (!mounted || total <= 0) return;
          setState(() => _progress = processed / total);
        },
        isCancelled: () => _cancelled,
      );
      if (!mounted) return;
      setState(() {
        _committed = entry;
        _busy = false;
        _progress = 1.0;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final Color surface = AppColors.surfaceOf(context);
    final Color border = AppColors.borderOf(context);
    final Color textPrimary = AppColors.textPrimaryOf(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Bulk Question Import')),
      body: SafeArea(
        child: SingleChildScrollView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          padding: const EdgeInsets.fromLTRB(
            20,
            AppSpacing.sm,
            20,
            AppSpacing.lg,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Wrap(
                spacing: AppSpacing.xs,
                children: <Widget>[
                  ChoiceChip(
                    label: const Text('JSON Format'),
                    selected: _format == 'json',
                    onSelected: (_) => setState(() {
                      _format = 'json';
                      _preview = null;
                    }),
                  ),
                  ChoiceChip(
                    label: const Text('CSV Format'),
                    selected: _format == 'csv',
                    onSelected: (_) => setState(() {
                      _format = 'csv';
                      _preview = null;
                    }),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.sm),
              TextField(
                controller: _inputController,
                maxLines: 8,
                decoration: InputDecoration(
                  hintText: _format == 'json'
                      ? 'Paste JSON array or {"questions": [...]} payload here...'
                      : 'Paste 17/18-column CSV with header row here...',
                ),
              ),
              const SizedBox(height: AppSpacing.md),
              PremiumButton(
                label: _busy ? 'Validating...' : 'Preview & Validate',
                variant: PremiumButtonVariant.primary,
                fullWidth: true,
                onPressed: _busy ? () {} : _runPreview,
              ),
              if (_busy && _progress > 0) ...<Widget>[
                const SizedBox(height: AppSpacing.sm),
                LinearProgressIndicator(value: _progress),
              ],
              if (_preview != null) ...<Widget>[
                const SizedBox(height: AppSpacing.lg),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(AppSpacing.md),
                  decoration: BoxDecoration(
                    color: surface,
                    borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
                    border: Border.all(color: border),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Import Preview Summary',
                        style: AppTextStyles.cardTitle
                            .copyWith(color: textPrimary),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Total Rows: ${_preview!.totalRows}\n'
                        'Valid (Ready to Import): ${_preview!.validCount}\n'
                        'Skipped Duplicates: ${_preview!.duplicateCount}\n'
                        'Rejected Invalid: ${_preview!.invalidCount}\n'
                        'Quality Warnings: ${_preview!.warnings.length}',
                        style: AppTextStyles.bodyPrimary
                            .copyWith(color: textPrimary),
                      ),
                      const SizedBox(height: AppSpacing.sm),
                      Wrap(
                        spacing: AppSpacing.xs,
                        runSpacing: AppSpacing.xs,
                        children: <Widget>[
                          OutlinedButton.icon(
                            onPressed: () {
                              Navigator.of(context).push(
                                SmoothPageRoute<void>(
                                  builder: (_) => AdminValidationReportScreen(
                                    failures: _preview!.validationFailures,
                                    warnings: _preview!.warnings,
                                  ),
                                ),
                              );
                            },
                            icon: const Icon(Icons.fact_check_outlined, size: 18),
                            label: Text(
                              'Validation Report (${_preview!.validationFailures.length})',
                            ),
                          ),
                          OutlinedButton.icon(
                            onPressed: () {
                              Navigator.of(context).push(
                                SmoothPageRoute<void>(
                                  builder: (_) => AdminDuplicateReviewScreen(
                                    duplicates: _preview!.duplicateMatches,
                                  ),
                                ),
                              );
                            },
                            icon: const Icon(Icons.copy_all_outlined, size: 18),
                            label: Text(
                              'Duplicate Review (${_preview!.duplicateMatches.length})',
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: AppSpacing.md),
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: OutlinedButton(
                              onPressed: _busy ? null : _cancelPreview,
                              child: const Text('Cancel'),
                            ),
                          ),
                          if (_preview!.validCount > 0) ...<Widget>[
                            const SizedBox(width: AppSpacing.sm),
                            Expanded(
                              flex: 2,
                              child: PremiumButton(
                                label:
                                    'Import ${_preview!.validCount} Valid',
                                variant: PremiumButtonVariant.primary,
                                onPressed: _busy ? () {} : _confirmAndCommit,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              ],
              if (_committed != null) ...<Widget>[
                const SizedBox(height: AppSpacing.md),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(AppSpacing.md),
                  decoration: BoxDecoration(
                    color: AppColors.softGreenOf(context),
                    borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
                    border: Border.all(color: AppColors.success),
                  ),
                  child: Text(
                    'Import Completed (${_committed!.importId}): '
                    'Imported ${_committed!.importedCount}, '
                    'Skipped ${_committed!.skippedDuplicates}, '
                    'Rejected ${_committed!.rejectedCount}.',
                    style: AppTextStyles.bodyPrimary
                        .copyWith(color: textPrimary),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
