import 'package:flutter/material.dart';
import 'package:gk_arena/features/admin/models/verification_models.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/widgets/state_views.dart';

/// Dedicated Admin Duplicate Review screen listing skipped duplicate questions
/// detected by unique ID or normalized(text) + language + subject/topic.
class AdminDuplicateReviewScreen extends StatelessWidget {
  const AdminDuplicateReviewScreen({
    super.key,
    required this.duplicates,
  });

  final List<DuplicateMatchDetail> duplicates;

  @override
  Widget build(BuildContext context) {
    final Color surface = AppColors.surfaceOf(context);
    final Color border = AppColors.borderOf(context);
    final Color textPrimary = AppColors.textPrimaryOf(context);
    final Color textSecondary = AppColors.textSecondaryOf(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Duplicate Review (${duplicates.length})'),
      ),
      body: SafeArea(
        child: duplicates.isEmpty
            ? const Padding(
                padding: EdgeInsets.all(20),
                child: GkEmptyStateCard(
                  icon: Icons.filter_none_rounded,
                  badgeText: 'No Duplicates',
                  title: 'No Duplicate Questions Detected',
                  description:
                      'All valid incoming records have unique IDs and normalized text.',
                ),
              )
            : ListView.separated(
                padding: const EdgeInsets.fromLTRB(
                  20,
                  AppSpacing.sm,
                  20,
                  AppSpacing.lg,
                ),
                itemCount: duplicates.length,
                separatorBuilder: (_, __) =>
                    const SizedBox(height: AppSpacing.sm),
                itemBuilder: (BuildContext context, int index) {
                  final DuplicateMatchDetail d = duplicates[index];
                  return Container(
                    padding: const EdgeInsets.all(AppSpacing.md),
                    decoration: BoxDecoration(
                      color: surface,
                      borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
                      border: Border.all(color: border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          'Row ${d.rowNumber} • ${d.incomingId} (${d.subjectId} / ${d.languageCode.toUpperCase()})',
                          style: AppTextStyles.badgeLabel
                              .copyWith(color: AppColors.warning),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          d.incomingText,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: AppTextStyles.bodyPrimary
                              .copyWith(color: textPrimary),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Topic: ${d.topic} • ${d.reason}',
                          style: AppTextStyles.cardSubtitle
                              .copyWith(color: textSecondary),
                        ),
                      ],
                    ),
                  );
                },
              ),
      ),
    );
  }
}
