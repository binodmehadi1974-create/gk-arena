import 'package:flutter/material.dart';
import 'package:gk_arena/features/admin/models/verification_models.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/widgets/state_views.dart';

/// Dedicated Admin Validation Report screen detailing row-by-row structural
/// failures and quality warnings from a Bulk Import preview.
class AdminValidationReportScreen extends StatelessWidget {
  const AdminValidationReportScreen({
    super.key,
    required this.failures,
    required this.warnings,
  });

  final List<ValidationFailureDetail> failures;
  final List<String> warnings;

  @override
  Widget build(BuildContext context) {
    final Color surface = AppColors.surfaceOf(context);
    final Color border = AppColors.borderOf(context);
    final Color textPrimary = AppColors.textPrimaryOf(context);
    final Color textSecondary = AppColors.textSecondaryOf(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Validation Report (${failures.length})'),
      ),
      body: SafeArea(
        child: (failures.isEmpty && warnings.isEmpty)
            ? const Padding(
                padding: EdgeInsets.all(20),
                child: GkEmptyStateCard(
                  icon: Icons.verified_outlined,
                  badgeText: 'All Clear',
                  title: 'No Validation Errors Found',
                  description:
                      'Every row in this import passed structural quality checks.',
                ),
              )
            : ListView(
                padding: const EdgeInsets.fromLTRB(
                  20,
                  AppSpacing.sm,
                  20,
                  AppSpacing.lg,
                ),
                children: <Widget>[
                  if (failures.isNotEmpty) ...<Widget>[
                    Text(
                      'Rejected Invalid Records (${failures.length})',
                      style: AppTextStyles.sectionTitle
                          .copyWith(color: AppColors.danger),
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    ...failures.map(
                      (ValidationFailureDetail f) => Container(
                        margin: const EdgeInsets.only(bottom: AppSpacing.sm),
                        padding: const EdgeInsets.all(AppSpacing.md),
                        decoration: BoxDecoration(
                          color: surface,
                          borderRadius:
                              BorderRadius.circular(AppSpacing.radiusMd),
                          border: Border.all(color: border),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              'Row ${f.rowNumber} • ID: ${f.questionId}',
                              style: AppTextStyles.cardTitle
                                  .copyWith(color: textPrimary),
                            ),
                            const SizedBox(height: 4),
                            ...f.errors.map(
                              (String e) => Text(
                                '• $e',
                                style: AppTextStyles.body
                                    .copyWith(color: AppColors.danger),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                  if (warnings.isNotEmpty) ...<Widget>[
                    const SizedBox(height: AppSpacing.md),
                    Text(
                      'Quality Warnings (${warnings.length})',
                      style: AppTextStyles.sectionTitle
                          .copyWith(color: AppColors.warning),
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    ...warnings.map(
                      (String w) => Container(
                        margin: const EdgeInsets.only(bottom: AppSpacing.xs),
                        padding: const EdgeInsets.all(AppSpacing.sm),
                        decoration: BoxDecoration(
                          color: AppColors.softAmberOf(context),
                          borderRadius:
                              BorderRadius.circular(AppSpacing.radiusSm),
                          border: Border.all(color: border),
                        ),
                        child: Text(
                          w,
                          style: AppTextStyles.body
                              .copyWith(color: textSecondary),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
      ),
    );
  }
}
