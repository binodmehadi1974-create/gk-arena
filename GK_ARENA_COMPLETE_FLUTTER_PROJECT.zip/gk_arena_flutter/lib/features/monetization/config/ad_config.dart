import 'package:flutter/foundation.dart';

/// Centralized AdMob configuration keeping official Google TEST ad unit IDs
/// strictly separated from future production placeholders.
///
/// NEVER hardcode real production AdMob IDs during development or generate
/// real ad traffic on test devices.
abstract final class AdConfig {
  /// Defaults to true so development builds ALWAYS use official Google test ads.
  static const bool useTestAds = true;

  // Official Google AdMob Android TEST Ad Unit IDs
  // Source: https://developers.google.com/admob/android/test-ads
  static const String androidTestAppId =
      'ca-app-pub-3940256099942544~3347511713';
  static const String androidTestBannerId =
      'ca-app-pub-3940256099942544/9214589741';
  static const String androidTestInterstitialId =
      'ca-app-pub-3940256099942544/1033173712';
  static const String androidTestRewardedId =
      'ca-app-pub-3940256099942544/5224354917';

  // Production Placeholders — replace ONLY before Play Store release using
  // IDs issued to an eligible AdMob account holder.
  static const String androidProdBannerId =
      'REPLACE_WITH_PRODUCTION_ANDROID_BANNER_ID';
  static const String androidProdInterstitialId =
      'REPLACE_WITH_PRODUCTION_ANDROID_INTERSTITIAL_ID';
  static const String androidProdRewardedId =
      'REPLACE_WITH_PRODUCTION_ANDROID_REWARDED_ID';

  static bool _isPlaceholder(String id) =>
      id.trim().isEmpty || id.contains('REPLACE_WITH_');

  static bool get isProductionConfigured =>
      !useTestAds &&
      !kDebugMode &&
      !_isPlaceholder(androidProdBannerId) &&
      !_isPlaceholder(androidProdInterstitialId) &&
      !_isPlaceholder(androidProdRewardedId);

  /// Always resolves to official Google TEST IDs in debug/development mode or
  /// whenever production IDs are still placeholders.
  static String get bannerAdUnitId {
    if (useTestAds || kDebugMode || _isPlaceholder(androidProdBannerId)) {
      return androidTestBannerId;
    }
    return androidProdBannerId;
  }

  static String get interstitialAdUnitId {
    if (useTestAds || kDebugMode || _isPlaceholder(androidProdInterstitialId)) {
      return androidTestInterstitialId;
    }
    return androidProdInterstitialId;
  }

  static String get rewardedAdUnitId {
    if (useTestAds || kDebugMode || _isPlaceholder(androidProdRewardedId)) {
      return androidTestRewardedId;
    }
    return androidProdRewardedId;
  }
}
