import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:gk_arena/features/monetization/config/ad_config.dart';
import 'package:gk_arena/features/monetization/services/ad_consent_and_policy_service.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

/// Responsive anchored adaptive bottom Banner Ad widget.
/// - Reserves space cleanly above system safe area without overlapping controls.
/// - Includes a subtle top separator + spacing to prevent accidental clicks.
/// - Collapses cleanly to SizedBox.shrink() on failure, offline, or non-mobile.
class GkBannerAdSlot extends StatefulWidget {
  const GkBannerAdSlot({
    super.key,
    this.policyService,
    this.enabled = true,
  });

  final AdConsentAndPolicyService? policyService;
  final bool enabled;

  @override
  State<GkBannerAdSlot> createState() => _GkBannerAdSlotState();
}

class _GkBannerAdSlotState extends State<GkBannerAdSlot> {
  BannerAd? _bannerAd;
  bool _isLoaded = false;
  bool _loadRequested = false;

  bool get _isSupportedMobile =>
      !kIsWeb &&
      (defaultTargetPlatform == TargetPlatform.android ||
          defaultTargetPlatform == TargetPlatform.iOS);

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_loadRequested && widget.enabled && _isSupportedMobile) {
      _loadRequested = true;
      _loadAdaptiveBanner();
    }
  }

  Future<void> _loadAdaptiveBanner() async {
    final int width = MediaQuery.sizeOf(context).width.truncate();
    if (width <= 0) return;

    try {
      final AnchoredAdaptiveBannerAdSize? size =
          await AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(width);
      if (!mounted || size == null) return;

      final AdConsentAndPolicyService policy =
          widget.policyService ?? AdConsentAndPolicyService();

      final BannerAd ad = BannerAd(
        adUnitId: AdConfig.bannerAdUnitId,
        size: size,
        request: policy.buildAdRequest(),
        listener: BannerAdListener(
          onAdLoaded: (Ad loadedAd) {
            if (!mounted) {
              loadedAd.dispose();
              return;
            }
            setState(() {
              _bannerAd = loadedAd as BannerAd;
              _isLoaded = true;
            });
          },
          onAdFailedToLoad: (Ad failedAd, LoadAdError _) {
            failedAd.dispose();
            if (!mounted) return;
            setState(() {
              _bannerAd = null;
              _isLoaded = false;
            });
          },
        ),
      );

      await ad.load();
    } catch (_) {
      // Gracefully collapse on platform channel failure or offline state.
    }
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final BannerAd? ad = _bannerAd;
    if (!widget.enabled || !_isLoaded || ad == null) {
      return const SizedBox.shrink();
    }

    return SafeArea(
      top: false,
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(top: 8),
        padding: const EdgeInsets.symmetric(vertical: 4),
        decoration: BoxDecoration(
          color: AppColors.surfaceOf(context),
          border: Border(
            top: BorderSide(color: AppColors.borderOf(context), width: 1),
          ),
        ),
        alignment: Alignment.center,
        child: SizedBox(
          width: ad.size.width.toDouble(),
          height: ad.size.height.toDouble(),
          child: AdWidget(ad: ad),
        ),
      ),
    );
  }
}
