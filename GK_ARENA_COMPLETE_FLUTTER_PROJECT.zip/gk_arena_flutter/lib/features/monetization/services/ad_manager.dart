import 'package:flutter/foundation.dart';
import 'package:gk_arena/features/monetization/config/ad_config.dart';
import 'package:gk_arena/features/monetization/services/ad_consent_and_policy_service.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

/// Pure-Dart frequency & safety guard for Interstitial ads.
/// Guarantees:
/// - NEVER shows an ad during an active quiz or timer.
/// - NEVER shows unexpected startup ads.
/// - Enforces cooldown (default 180s), minimum completed tests, and session cap.
class InterstitialFrequencyGuard {
  InterstitialFrequencyGuard({
    this.minCooldownSeconds = 180,
    this.maxPerSession = 4,
    this.minCompletedTestsBeforeFirst = 1,
    DateTime Function()? clock,
  }) : _clock = clock ?? DateTime.now;

  final int minCooldownSeconds;
  final int maxPerSession;
  final int minCompletedTestsBeforeFirst;
  final DateTime Function() _clock;

  bool _isQuizActive = false;
  int _completedTestsCount = 0;
  int _shownThisSession = 0;
  DateTime? _lastShownAt;

  bool get isQuizActive => _isQuizActive;
  int get shownThisSession => _shownThisSession;

  void setQuizActive(bool active) {
    _isQuizActive = active;
  }

  void recordTestCompleted() {
    _completedTestsCount++;
  }

  bool canShowNow({bool isNaturalBreak = true}) {
    if (!isNaturalBreak) return false;
    if (_isQuizActive) return false;
    if (_completedTestsCount < minCompletedTestsBeforeFirst) return false;
    if (_shownThisSession >= maxPerSession) return false;

    final DateTime? last = _lastShownAt;
    if (last != null) {
      final int elapsed = _clock().difference(last).inSeconds;
      if (elapsed < minCooldownSeconds) return false;
    }
    return true;
  }

  void markShown() {
    _shownThisSession++;
    _lastShownAt = _clock();
  }
}

/// Voluntary Rewarded Ad outcome — reward is granted ONLY when SDK confirms
/// full completion (`earnedReward == true`).
class RewardedAdResult {
  const RewardedAdResult({
    required this.earnedReward,
    required this.message,
  });

  final bool earnedReward;
  final String message;
}

/// Central AdMob lifecycle coordinator for Banner, Interstitial, and Rewarded ads.
class AdManager extends ChangeNotifier {
  AdManager({
    AdConsentAndPolicyService? policyService,
    InterstitialFrequencyGuard? interstitialGuard,
  })  : policyService = policyService ?? AdConsentAndPolicyService(),
        interstitialGuard = interstitialGuard ?? InterstitialFrequencyGuard();

  final AdConsentAndPolicyService policyService;
  final InterstitialFrequencyGuard interstitialGuard;

  bool _initialized = false;
  InterstitialAd? _interstitialAd;
  RewardedAd? _rewardedAd;
  int _earnedBonusRevisionCredits = 0;

  bool get isInitialized => _initialized;
  bool get isInterstitialReady => _interstitialAd != null;
  bool get isRewardedReady => _rewardedAd != null;
  int get earnedBonusRevisionCredits => _earnedBonusRevisionCredits;

  bool get _isSupportedMobile =>
      !kIsWeb &&
      (defaultTargetPlatform == TargetPlatform.android ||
          defaultTargetPlatform == TargetPlatform.iOS);

  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;
    if (!_isSupportedMobile) return;

    try {
      await policyService.applyRequestConfiguration();
      await MobileAds.instance.initialize();
      _preloadInterstitial();
      _preloadRewarded();
    } catch (_) {
      // Keep app fully operational offline or when native SDK is unavailable.
    }
  }

  void setQuizActive(bool active) {
    interstitialGuard.setQuizActive(active);
  }

  void _preloadInterstitial() {
    if (!_isSupportedMobile || _interstitialAd != null) return;
    InterstitialAd.load(
      adUnitId: AdConfig.interstitialAdUnitId,
      request: policyService.buildAdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (InterstitialAd ad) {
          _interstitialAd = ad;
          notifyListeners();
        },
        onAdFailedToLoad: (LoadAdError _) {
          _interstitialAd = null;
        },
      ),
    );
  }

  void _preloadRewarded() {
    if (!_isSupportedMobile || _rewardedAd != null) return;
    RewardedAd.load(
      adUnitId: AdConfig.rewardedAdUnitId,
      request: policyService.buildAdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (RewardedAd ad) {
          _rewardedAd = ad;
          notifyListeners();
        },
        onAdFailedToLoad: (LoadAdError _) {
          _rewardedAd = null;
        },
      ),
    );
  }

  /// Shows an interstitial ad ONLY at a natural post-test break if frequency
  /// caps, cooldown, and active-quiz guards all pass.
  Future<bool> maybeShowPostTestInterstitial() async {
    interstitialGuard.recordTestCompleted();
    if (!interstitialGuard.canShowNow(isNaturalBreak: true)) {
      return false;
    }

    final InterstitialAd? ad = _interstitialAd;
    if (ad == null) {
      _preloadInterstitial();
      return false;
    }

    _interstitialAd = null;
    interstitialGuard.markShown();
    ad.fullScreenContentCallback = FullScreenContentCallback<InterstitialAd>(
      onAdDismissedFullScreenContent: (InterstitialAd closed) {
        closed.dispose();
        _preloadInterstitial();
      },
      onAdFailedToShowFullScreenContent: (InterstitialAd failed, AdError _) {
        failed.dispose();
        _preloadInterstitial();
      },
    );
    await ad.show();
    return true;
  }

  /// Shows a strictly voluntary Rewarded Ad. Grants reward ONLY inside the SDK
  /// `onUserEarnedReward` callback (never on dismissal or load failure).
  Future<RewardedAdResult> showVoluntaryRewardedAd() async {
    if (!_isSupportedMobile) {
      return const RewardedAdResult(
        earnedReward: false,
        message: 'Test rewarded ads are available on Android/iOS devices.',
      );
    }

    final RewardedAd? ad = _rewardedAd;
    if (ad == null) {
      _preloadRewarded();
      return const RewardedAdResult(
        earnedReward: false,
        message: 'Optional ad is not ready right now. Please try again later.',
      );
    }

    _rewardedAd = null;
    bool rewarded = false;

    ad.fullScreenContentCallback = FullScreenContentCallback<RewardedAd>(
      onAdDismissedFullScreenContent: (RewardedAd closed) {
        closed.dispose();
        _preloadRewarded();
      },
      onAdFailedToShowFullScreenContent: (RewardedAd failed, AdError _) {
        failed.dispose();
        _preloadRewarded();
      },
    );

    await ad.show(
      onUserEarnedReward: (AdWithoutView _, RewardItem _) {
        rewarded = true;
        grantVerifiedReward();
      },
    );

    return RewardedAdResult(
      earnedReward: rewarded,
      message: rewarded
          ? 'Bonus revision tip credit unlocked!'
          : 'Ad closed before completion. No reward granted.',
    );
  }

  /// Grants reward strictly after verified SDK completion (exposed for unit tests).
  void grantVerifiedReward() {
    _earnedBonusRevisionCredits++;
    notifyListeners();
  }

  @override
  void dispose() {
    _interstitialAd?.dispose();
    _rewardedAd?.dispose();
    super.dispose();
  }
}
