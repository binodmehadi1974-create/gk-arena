import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

/// Privacy, UMP consent, and student/teen audience safety policy configuration
/// for Google Mobile Ads.
class AdConsentAndPolicyService {
  AdConsentAndPolicyService({
    this.isStudentSafeAudience = true,
  });

  /// Keeps ad content family/student-appropriate (G-rated) by default.
  final bool isStudentSafeAudience;

  bool _personalizedAdsAllowed = false;
  bool get personalizedAdsAllowed => _personalizedAdsAllowed;

  /// Builds policy-compliant [AdRequest] (non-personalized when consent is
  /// absent or under-age/student safety mode is active).
  AdRequest buildAdRequest() {
    return AdRequest(
      nonPersonalizedAds: isStudentSafeAudience || !_personalizedAdsAllowed,
    );
  }

  /// Applies Google Mobile Ads RequestConfiguration honoring student/teen
  /// content rating and under-age consent safeguards.
  Future<void> applyRequestConfiguration() async {
    final bool isMobile = !kIsWeb &&
        (defaultTargetPlatform == TargetPlatform.android ||
            defaultTargetPlatform == TargetPlatform.iOS);
    if (!isMobile) return;

    try {
      await MobileAds.instance.updateRequestConfiguration(
        RequestConfiguration(
          maxAdContentRating: isStudentSafeAudience
              ? MaxAdContentRating.g
              : MaxAdContentRating.pg,
          tagForUnderAgeOfConsent: isStudentSafeAudience
              ? TagForUnderAgeOfConsent.yes
              : TagForUnderAgeOfConsent.unspecified,
        ),
      );
    } catch (_) {
      // Never crash app startup if native ads plugin is unavailable in tests.
    }
  }

  void updateConsentChoice({required bool allowPersonalized}) {
    _personalizedAdsAllowed = !isStudentSafeAudience && allowPersonalized;
  }
}
