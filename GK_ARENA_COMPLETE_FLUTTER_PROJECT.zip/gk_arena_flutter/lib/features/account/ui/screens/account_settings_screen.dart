import 'package:flutter/material.dart';
import 'package:gk_arena/features/account/controllers/account_controller.dart';
import 'package:gk_arena/features/account/models/account_models.dart';
import 'package:gk_arena/features/account/ui/screens/auth_screen.dart';
import 'package:gk_arena/features/settings/localization/app_strings.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/navigation/smooth_page_route.dart';
import 'package:gk_arena/ui/screens/profile/widgets/profile_menu_tile.dart';
import 'package:gk_arena/ui/widgets/premium_button.dart';

/// Account & Cloud Backup settings screen displaying minimal profile details,
/// real sync status, password change, logout confirmation, and backend-verified
/// account deletion request flow.
class AccountSettingsScreen extends StatelessWidget {
  const AccountSettingsScreen({
    super.key,
    required this.accountController,
  });

  final AccountController accountController;

  Future<void> _confirmLogout(BuildContext context) async {
    final AppStrings s = AppLanguageScope.of(context);
    final bool? ok = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text(s.t(hi: 'लॉगआउट करें?', en: 'Log Out?')),
          content: Text(
            s.t(
              hi: 'लॉगआउट करने के बाद ऐप Guest Mode में स्विच हो जाएगा। इस खाते का निजी डेटा अलग सुरक्षित रहेगा।',
              en: 'Logging out switches the app back to Guest Mode. Your account data remains isolated.',
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: Text(s.cancel),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: Text(s.t(hi: 'लॉगआउट', en: 'Log Out')),
            ),
          ],
        );
      },
    );
    if (ok == true) {
      final AuthActionResult result = await accountController.logout();
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.message)),
      );
    }
  }

  Future<void> _showChangePasswordDialog(BuildContext context) async {
    final AppStrings s = AppLanguageScope.of(context);
    final TextEditingController currentCtrl = TextEditingController();
    final TextEditingController newCtrl = TextEditingController();

    final bool? submitted = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text(s.t(hi: 'पासवर्ड बदलें', en: 'Change Password')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                controller: currentCtrl,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: s.t(hi: 'वर्तमान पासवर्ड', en: 'Current Password'),
                ),
              ),
              const SizedBox(height: AppSpacing.sm),
              TextField(
                controller: newCtrl,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: s.t(hi: 'नया पासवर्ड', en: 'New Password'),
                ),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: Text(s.cancel),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: Text(s.save),
            ),
          ],
        );
      },
    );

    if (submitted == true) {
      final AuthActionResult result = await accountController.changePassword(
        currentPassword: currentCtrl.text,
        newPassword: newCtrl.text,
      );
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(result.message)),
        );
      }
    }
    currentCtrl.dispose();
    newCtrl.dispose();
  }

  Future<void> _showDeleteAccountDialog(BuildContext context) async {
    final AppStrings s = AppLanguageScope.of(context);
    final TextEditingController passwordCtrl = TextEditingController();

    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text(
            s.t(hi: 'खाता हटाने का अनुरोध', en: 'Request Account Deletion'),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                s.t(
                  hi: 'खाता केवल तभी हटाया जाएगा जब बैकएंड सर्वर स्थायी डिलीशन की पुष्टि करेगा। कृपया पासवर्ड दर्ज करें।',
                  en: 'An account is only marked deleted after the backend confirms permanent deletion. Enter your password to continue.',
                ),
              ),
              const SizedBox(height: AppSpacing.sm),
              TextField(
                controller: passwordCtrl,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: s.t(hi: 'पासवर्ड', en: 'Password'),
                ),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: Text(s.cancel),
            ),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: Text(s.t(hi: 'अनुरोध भेजें', en: 'Submit Request')),
            ),
          ],
        );
      },
    );

    if (confirmed == true) {
      final AuthActionResult result =
          await accountController.requestAccountDeletion(
        currentPassword: passwordCtrl.text,
      );
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(result.message)),
        );
      }
    }
    passwordCtrl.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final AppStrings s = AppLanguageScope.of(context);

    return AnimatedBuilder(
      animation: Listenable.merge(<Listenable>[
        accountController,
        accountController.cloudSyncService,
      ]),
      builder: (BuildContext context, _) {
        final UserProfile user = accountController.activeUser;
        final SyncStatusSnapshot sync =
            accountController.cloudSyncService.status;
        final Color surface = AppColors.surfaceOf(context);
        final Color border = AppColors.borderOf(context);
        final Color textPrimary = AppColors.textPrimaryOf(context);
        final Color textSecondary = AppColors.textSecondaryOf(context);

        return Scaffold(
          appBar: AppBar(
            title: Text(
              s.t(hi: 'खाता और क्लाउड बैकअप', en: 'Account & Cloud Backup'),
            ),
          ),
          body: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(
                20,
                AppSpacing.sm,
                20,
                AppSpacing.lg,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  // Account Info Card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(AppSpacing.md),
                    decoration: BoxDecoration(
                      color: surface,
                      borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
                      border: Border.all(color: border, width: 1),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          children: <Widget>[
                            Expanded(
                              child: Text(
                                user.displayName,
                                style: AppTextStyles.sectionTitle
                                    .copyWith(color: textPrimary),
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: user.isGuest
                                    ? AppColors.softAmberOf(context)
                                    : AppColors.softGreenOf(context),
                                borderRadius: BorderRadius.circular(
                                  AppSpacing.radiusPill,
                                ),
                              ),
                              child: Text(
                                user.isGuest
                                    ? 'Guest Mode'
                                    : (user.emailVerified
                                        ? 'Verified'
                                        : 'Unverified'),
                                style: AppTextStyles.badgeLabel.copyWith(
                                  color: user.isGuest
                                      ? AppColors.warning
                                      : AppColors.success,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          user.email ??
                              s.t(
                                hi: 'कोई ईमेल जुड़ा नहीं (स्थानीय Guest मोड)',
                                en: 'No email linked (Local Guest Mode)',
                              ),
                          style: AppTextStyles.cardSubtitle
                              .copyWith(color: textSecondary),
                        ),
                        const SizedBox(height: AppSpacing.md),
                        if (user.isGuest)
                          PremiumButton(
                            label: s.t(
                              hi: 'लॉगिन / साइन अप करें',
                              en: 'Login / Sign Up',
                            ),
                            variant: PremiumButtonVariant.primary,
                            fullWidth: true,
                            onPressed: () {
                              Navigator.of(context).push(
                                SmoothPageRoute<void>(
                                  builder: (_) => AuthScreen(
                                    accountController: accountController,
                                  ),
                                ),
                              );
                            },
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),

                  // Cloud Backup Status Card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(AppSpacing.md),
                    decoration: BoxDecoration(
                      color: surface,
                      borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
                      border: Border.all(color: border, width: 1),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          s.t(hi: 'क्लाउड बैकअप स्थिति', en: 'Cloud Backup Status'),
                          style: AppTextStyles.cardTitle
                              .copyWith(color: textPrimary),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          sync.message,
                          style: AppTextStyles.body
                              .copyWith(color: textSecondary),
                        ),
                        const SizedBox(height: AppSpacing.sm),
                        OutlinedButton.icon(
                          onPressed: () => accountController.syncNow(),
                          icon: const Icon(Icons.sync_rounded, size: 18),
                          label: Text(
                            s.t(hi: 'अभी सिंक जाँचें', en: 'Check Sync Now'),
                          ),
                        ),
                      ],
                    ),
                  ),

                  if (!user.isGuest) ...<Widget>[
                    const SizedBox(height: AppSpacing.lg),
                    Container(
                      decoration: BoxDecoration(
                        color: surface,
                        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
                        border: Border.all(color: border, width: 1),
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: Column(
                        children: <Widget>[
                          ProfileMenuTile(
                            icon: Icons.lock_reset_rounded,
                            title: s.t(hi: 'पासवर्ड बदलें', en: 'Change Password'),
                            subtitle: s.t(
                              hi: 'खाते का पासवर्ड अपडेट करें',
                              en: 'Update your account password',
                            ),
                            iconColor: AppColors.primary,
                            iconBackground: AppColors.softBlueOf(context),
                            onTap: () => _showChangePasswordDialog(context),
                          ),
                          const Divider(indent: 68),
                          ProfileMenuTile(
                            icon: Icons.logout_rounded,
                            title: s.t(hi: 'लॉगआउट', en: 'Log Out'),
                            subtitle: s.t(
                              hi: 'सुरक्षित रूप से लॉगआउट करें',
                              en: 'Sign out with confirmation',
                            ),
                            iconColor: AppColors.warning,
                            iconBackground: AppColors.softAmberOf(context),
                            onTap: () => _confirmLogout(context),
                          ),
                          const Divider(indent: 68),
                          ProfileMenuTile(
                            icon: Icons.person_remove_outlined,
                            title: s.t(
                              hi: 'खाता हटाने का अनुरोध',
                              en: 'Delete Account Request',
                            ),
                            subtitle: s.t(
                              hi: 'बैकएंड पुष्टि के साथ स्थायी खाता डिलीशन',
                              en: 'Permanent deletion verified by backend',
                            ),
                            iconColor: AppColors.danger,
                            iconBackground: const Color(0x26D64545),
                            onTap: () => _showDeleteAccountDialog(context),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
