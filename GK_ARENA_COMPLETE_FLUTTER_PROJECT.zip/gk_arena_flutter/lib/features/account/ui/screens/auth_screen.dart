import 'package:flutter/material.dart';
import 'package:gk_arena/features/account/controllers/account_controller.dart';
import 'package:gk_arena/features/account/models/account_models.dart';
import 'package:gk_arena/features/settings/localization/app_strings.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/widgets/premium_button.dart';

enum _AuthViewMode { login, signUp, forgotPassword }

/// Clean Account Authentication screen supporting Login, Sign Up, Forgot
/// Password, Guest Mode continuation, and transparent backend-config notice.
class AuthScreen extends StatefulWidget {
  const AuthScreen({
    super.key,
    required this.accountController,
  });

  final AccountController accountController;

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  _AuthViewMode _mode = _AuthViewMode.login;
  bool _migrateGuestData = true;
  bool _submitting = false;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() => _submitting = true);
    late final AuthActionResult result;

    switch (_mode) {
      case _AuthViewMode.login:
        result = await widget.accountController.login(
          email: _emailController.text,
          password: _passwordController.text,
        );
      case _AuthViewMode.signUp:
        result = await widget.accountController.signUp(
          displayName: _nameController.text,
          email: _emailController.text,
          password: _passwordController.text,
          migrateGuestData: _migrateGuestData,
        );
      case _AuthViewMode.forgotPassword:
        result = await widget.accountController.sendPasswordResetEmail(
          _emailController.text,
        );
    }

    if (!mounted) return;
    setState(() => _submitting = false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(result.message)),
    );

    if (result.success && _mode != _AuthViewMode.forgotPassword) {
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final AppStrings s = AppLanguageScope.of(context);
    final Color surface = AppColors.surfaceOf(context);
    final Color border = AppColors.borderOf(context);
    final Color textPrimary = AppColors.textPrimaryOf(context);
    final Color textSecondary = AppColors.textSecondaryOf(context);

    final String title;
    switch (_mode) {
      case _AuthViewMode.login:
        title = s.t(hi: 'लॉगिन करें', en: 'Login');
      case _AuthViewMode.signUp:
        title = s.t(hi: 'नया खाता बनाएँ', en: 'Sign Up');
      case _AuthViewMode.forgotPassword:
        title = s.t(hi: 'पासवर्ड रीसेट', en: 'Forgot Password');
    }

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: SafeArea(
        child: SingleChildScrollView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          padding: const EdgeInsets.fromLTRB(
            20,
            AppSpacing.sm,
            20,
            AppSpacing.lg,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              if (!widget.accountController.isBackendConfigured) ...<Widget>[
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(AppSpacing.md),
                  decoration: BoxDecoration(
                    color: AppColors.softAmberOf(context),
                    borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
                    border: Border.all(color: AppColors.warning, width: 1),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      const Icon(
                        Icons.cloud_off_rounded,
                        color: AppColors.warning,
                        size: 20,
                      ),
                      const SizedBox(width: AppSpacing.sm),
                      Expanded(
                        child: Text(
                          s.t(
                            hi: 'क्लाउड बैकएंड (Firebase Auth) अभी इस बिल्ड में कॉन्फ़िगर नहीं है। आप Guest Mode में ऐप का पूरा उपयोग कर सकते हैं।',
                            en: 'Cloud backend (Firebase Auth) is not configured in this build yet. You can continue using all offline features in Guest Mode.',
                          ),
                          style: AppTextStyles.body.copyWith(color: textPrimary),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: AppSpacing.md),
              ],

              // Mode Selector
              Wrap(
                spacing: AppSpacing.xs,
                runSpacing: AppSpacing.xs,
                children: <Widget>[
                  ChoiceChip(
                    label: Text(s.t(hi: 'लॉगिन', en: 'Login')),
                    selected: _mode == _AuthViewMode.login,
                    onSelected: (_) =>
                        setState(() => _mode = _AuthViewMode.login),
                  ),
                  ChoiceChip(
                    label: Text(s.t(hi: 'साइन अप', en: 'Sign Up')),
                    selected: _mode == _AuthViewMode.signUp,
                    onSelected: (_) =>
                        setState(() => _mode = _AuthViewMode.signUp),
                  ),
                  ChoiceChip(
                    label: Text(s.t(hi: 'पासवर्ड भूल गए', en: 'Reset Password')),
                    selected: _mode == _AuthViewMode.forgotPassword,
                    onSelected: (_) =>
                        setState(() => _mode = _AuthViewMode.forgotPassword),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.md),

              Container(
                padding: const EdgeInsets.all(AppSpacing.md),
                decoration: BoxDecoration(
                  color: surface,
                  borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
                  border: Border.all(color: border, width: 1),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    if (_mode == _AuthViewMode.signUp) ...<Widget>[
                      TextField(
                        controller: _nameController,
                        textInputAction: TextInputAction.next,
                        decoration: InputDecoration(
                          labelText: s.t(hi: 'नाम (Display Name)', en: 'Display Name'),
                          prefixIcon: const Icon(Icons.person_outline_rounded),
                        ),
                      ),
                      const SizedBox(height: AppSpacing.sm),
                    ],
                    TextField(
                      controller: _emailController,
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: _mode == _AuthViewMode.forgotPassword
                          ? TextInputAction.done
                          : TextInputAction.next,
                      decoration: InputDecoration(
                        labelText: s.t(hi: 'ईमेल पता', en: 'Email Address'),
                        prefixIcon: const Icon(Icons.email_outlined),
                      ),
                    ),
                    if (_mode != _AuthViewMode.forgotPassword) ...<Widget>[
                      const SizedBox(height: AppSpacing.sm),
                      TextField(
                        controller: _passwordController,
                        obscureText: true,
                        decoration: InputDecoration(
                          labelText: s.t(hi: 'पासवर्ड', en: 'Password'),
                          prefixIcon: const Icon(Icons.lock_outline_rounded),
                        ),
                      ),
                    ],
                    if (_mode == _AuthViewMode.signUp) ...<Widget>[
                      const SizedBox(height: AppSpacing.sm),
                      CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        value: _migrateGuestData,
                        onChanged: (bool? v) {
                          setState(() => _migrateGuestData = v ?? true);
                        },
                        title: Text(
                          s.t(
                            hi: 'Guest Mode का डेटा नए खाते में ले जाएँ',
                            en: 'Transfer Guest Mode data to my new account',
                          ),
                          style: AppTextStyles.bodyPrimary
                              .copyWith(color: textPrimary),
                        ),
                        subtitle: Text(
                          s.t(
                            hi: 'आपके स्थानीय टेस्ट इतिहास, बुकमार्क और रिवीजन रिकॉर्ड सुरक्षित रूप से इस खाते से जुड़ जाएंगे।',
                            en: 'Your local test history, bookmarks, and revision records will safely move into this account.',
                          ),
                          style: AppTextStyles.cardSubtitle
                              .copyWith(color: textSecondary),
                        ),
                      ),
                    ],
                    const SizedBox(height: AppSpacing.md),
                    PremiumButton(
                      label: _submitting ? '...' : title,
                      variant: PremiumButtonVariant.primary,
                      fullWidth: true,
                      onPressed: _submitting ? () {} : _submit,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.md),

              // Guest Mode Explanation Card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(AppSpacing.md),
                decoration: BoxDecoration(
                  color: surface,
                  borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
                  border: Border.all(color: border, width: 1),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      s.t(hi: 'Guest Mode के बारे में', en: 'About Guest Mode'),
                      style: AppTextStyles.cardTitle.copyWith(color: textPrimary),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      s.t(
                        hi: 'आप बिना खाता बनाए भी पूरा ऐप उपयोग कर सकते हैं। आपका अभ्यास डेटा इसी डिवाइस पर स्थानीय रूप से सुरक्षित रहता है। बाद में खाता बनाने पर आप अपना Guest डेटा नए खाते में स्थानांतरित कर सकते हैं।',
                        en: 'You can explore and practice without creating an account. Your progress stays stored locally on this device, and you can migrate it when you register later.',
                      ),
                      style: AppTextStyles.body.copyWith(color: textSecondary),
                    ),
                    const SizedBox(height: AppSpacing.sm),
                    OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: Text(
                        s.t(
                          hi: 'Guest Mode में जारी रखें',
                          en: 'Continue in Guest Mode',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
