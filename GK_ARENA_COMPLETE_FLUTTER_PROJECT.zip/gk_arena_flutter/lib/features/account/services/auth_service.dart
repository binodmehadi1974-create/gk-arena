import 'package:gk_arena/features/account/models/account_models.dart';
import 'package:gk_arena/features/settings/models/app_settings.dart';

/// Provider-agnostic authentication contract designed for Firebase Auth.
/// Never stores plaintext passwords or hardcodes API keys.
abstract class AuthService {
  bool get isBackendConfigured;
  UserProfile? get currentUser;

  Future<AuthActionResult> signUpWithEmail({
    required String displayName,
    required String email,
    required String password,
    required AppLanguage preferredLanguage,
  });

  Future<AuthActionResult> loginWithEmail({
    required String email,
    required String password,
  });

  Future<AuthActionResult> logout();

  Future<AuthActionResult> sendPasswordResetEmail({required String email});

  Future<AuthActionResult> sendEmailVerification();

  Future<AuthActionResult> changePassword({
    required String currentPassword,
    required String newPassword,
  });

  /// Must NEVER claim account deletion succeeded unless the backend confirms it.
  Future<AuthActionResult> requestAccountDeletion({
    required String currentPassword,
  });
}

/// Default runtime AuthService used until Firebase Auth is configured via
/// `flutterfire configure`. Explicitly reports unconfigured status instead of
/// fabricating cloud accounts or fake deletions.
class UnconfiguredAuthService implements AuthService {
  static const String _notConfiguredMessage =
      'Cloud authentication backend (Firebase Auth) is not configured in this build yet. '
      'You can continue using GK ARENA in Guest Mode.';

  @override
  bool get isBackendConfigured => false;

  @override
  UserProfile? get currentUser => null;

  @override
  Future<AuthActionResult> signUpWithEmail({
    required String displayName,
    required String email,
    required String password,
    required AppLanguage preferredLanguage,
  }) async {
    return const AuthActionResult(
      success: false,
      requiresBackendConfig: true,
      message: _notConfiguredMessage,
    );
  }

  @override
  Future<AuthActionResult> loginWithEmail({
    required String email,
    required String password,
  }) async {
    return const AuthActionResult(
      success: false,
      requiresBackendConfig: true,
      message: _notConfiguredMessage,
    );
  }

  @override
  Future<AuthActionResult> logout() async {
    return const AuthActionResult(
      success: true,
      message: 'Signed out to Guest Mode.',
    );
  }

  @override
  Future<AuthActionResult> sendPasswordResetEmail({
    required String email,
  }) async {
    return const AuthActionResult(
      success: false,
      requiresBackendConfig: true,
      message: _notConfiguredMessage,
    );
  }

  @override
  Future<AuthActionResult> sendEmailVerification() async {
    return const AuthActionResult(
      success: false,
      requiresBackendConfig: true,
      message: _notConfiguredMessage,
    );
  }

  @override
  Future<AuthActionResult> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    return const AuthActionResult(
      success: false,
      requiresBackendConfig: true,
      message: _notConfiguredMessage,
    );
  }

  @override
  Future<AuthActionResult> requestAccountDeletion({
    required String currentPassword,
  }) async {
    return const AuthActionResult(
      success: false,
      requiresBackendConfig: true,
      message:
          'Account deletion requires an active configured backend (Firebase Auth) '
          'to confirm permanent server-side deletion.',
    );
  }
}

/// Deterministic in-memory AuthService strictly for unit tests (never shipped as
/// a fake cloud backend). Stores only non-plaintext salted digest tokens.
class InMemoryTestAuthService implements AuthService {
  final Map<String, ({UserProfile profile, String credentialDigest})> _usersByEmail =
      <String, ({UserProfile profile, String credentialDigest})>{};
  final Set<String> passwordResetEmailsSent = <String>{};
  UserProfile? _currentUser;
  int _seq = 0;

  @override
  bool get isBackendConfigured => true;

  @override
  UserProfile? get currentUser => _currentUser;

  String _digest(String email, String secret) {
    // Simple deterministic non-plaintext test digest (production uses Firebase Auth).
    int hash = 17;
    final String combined = '${email.toLowerCase()}::$secret::gk_test_salt';
    for (final int unit in combined.codeUnits) {
      hash = 0x1fffffff & (hash * 31 + unit);
    }
    return 'test_digest_$hash';
  }

  @override
  Future<AuthActionResult> signUpWithEmail({
    required String displayName,
    required String email,
    required String password,
    required AppLanguage preferredLanguage,
  }) async {
    final String normalizedEmail = email.trim().toLowerCase();
    if (displayName.trim().isEmpty) {
      return const AuthActionResult(
        success: false,
        message: 'Display name is required.',
      );
    }
    if (!normalizedEmail.contains('@')) {
      return const AuthActionResult(
        success: false,
        message: 'Please enter a valid email address.',
      );
    }
    if (password.length < 8) {
      return const AuthActionResult(
        success: false,
        message: 'Password must be at least 8 characters.',
      );
    }
    if (_usersByEmail.containsKey(normalizedEmail)) {
      return const AuthActionResult(
        success: false,
        message: 'An account with this email already exists.',
      );
    }

    _seq++;
    final UserProfile profile = UserProfile(
      uid: 'uid_$_seq',
      displayName: displayName.trim(),
      email: normalizedEmail,
      preferredLanguage: preferredLanguage,
      createdAt: DateTime.now().toUtc(),
      isGuest: false,
      emailVerified: false,
    );
    _usersByEmail[normalizedEmail] = (
      profile: profile,
      credentialDigest: _digest(normalizedEmail, password),
    );
    _currentUser = profile;
    return AuthActionResult(
      success: true,
      message: 'Account created. Verification email queued.',
      user: profile,
    );
  }

  @override
  Future<AuthActionResult> loginWithEmail({
    required String email,
    required String password,
  }) async {
    final String normalizedEmail = email.trim().toLowerCase();
    final record = _usersByEmail[normalizedEmail];
    if (record == null ||
        record.credentialDigest != _digest(normalizedEmail, password)) {
      return const AuthActionResult(
        success: false,
        message: 'Invalid email or password.',
      );
    }
    _currentUser = record.profile;
    return AuthActionResult(
      success: true,
      message: 'Logged in successfully.',
      user: record.profile,
    );
  }

  @override
  Future<AuthActionResult> logout() async {
    _currentUser = null;
    return const AuthActionResult(
      success: true,
      message: 'Logged out successfully.',
    );
  }

  @override
  Future<AuthActionResult> sendPasswordResetEmail({
    required String email,
  }) async {
    final String normalizedEmail = email.trim().toLowerCase();
    if (!normalizedEmail.contains('@')) {
      return const AuthActionResult(
        success: false,
        message: 'Enter a valid email address.',
      );
    }
    passwordResetEmailsSent.add(normalizedEmail);
    return const AuthActionResult(
      success: true,
      message: 'If an account exists for this email, a reset link has been sent.',
    );
  }

  @override
  Future<AuthActionResult> sendEmailVerification() async {
    final UserProfile? user = _currentUser;
    if (user == null || user.email == null) {
      return const AuthActionResult(
        success: false,
        message: 'No signed-in account.',
      );
    }
    final UserProfile verified = user.copyWith(emailVerified: true);
    final record = _usersByEmail[user.email!]!;
    _usersByEmail[user.email!] = (
      profile: verified,
      credentialDigest: record.credentialDigest,
    );
    _currentUser = verified;
    return AuthActionResult(
      success: true,
      message: 'Email verification confirmed.',
      user: verified,
    );
  }

  @override
  Future<AuthActionResult> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    final UserProfile? user = _currentUser;
    if (user == null || user.email == null) {
      return const AuthActionResult(
        success: false,
        message: 'Not signed in.',
      );
    }
    if (newPassword.length < 8) {
      return const AuthActionResult(
        success: false,
        message: 'New password must be at least 8 characters.',
      );
    }
    final record = _usersByEmail[user.email!]!;
    if (record.credentialDigest != _digest(user.email!, currentPassword)) {
      return const AuthActionResult(
        success: false,
        message: 'Current password is incorrect.',
      );
    }
    _usersByEmail[user.email!] = (
      profile: record.profile,
      credentialDigest: _digest(user.email!, newPassword),
    );
    return const AuthActionResult(
      success: true,
      message: 'Password updated successfully.',
    );
  }

  @override
  Future<AuthActionResult> requestAccountDeletion({
    required String currentPassword,
  }) async {
    final UserProfile? user = _currentUser;
    if (user == null || user.email == null) {
      return const AuthActionResult(
        success: false,
        message: 'Not signed in.',
      );
    }
    final record = _usersByEmail[user.email!]!;
    if (record.credentialDigest != _digest(user.email!, currentPassword)) {
      return const AuthActionResult(
        success: false,
        message: 'Password verification failed.',
      );
    }
    _usersByEmail.remove(user.email!);
    _currentUser = null;
    return const AuthActionResult(
      success: true,
      message: 'Account deleted.',
    );
  }
}
