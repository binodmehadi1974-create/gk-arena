import 'package:flutter/foundation.dart';
import 'package:gk_arena/features/account/models/account_models.dart';
import 'package:gk_arena/features/learning/models/learning_models.dart';
import 'package:gk_arena/features/learning/repositories/learning_repository.dart';
import 'package:gk_arena/features/settings/controllers/settings_controller.dart';

/// Remote backup data-source contract designed for Cloud Firestore.
/// Enforces caller authorization: requestingUid MUST match targetUid.
abstract class CloudBackupRemoteDataSource {
  bool get isConfigured;

  Future<void> uploadBackup({
    required String requestingUid,
    required CloudBackupPayload payload,
  });

  Future<CloudBackupPayload?> downloadBackup({
    required String requestingUid,
    required String targetUid,
  });
}

/// Default runtime data source when Cloud Firestore is not yet configured.
class UnconfiguredCloudBackupDataSource implements CloudBackupRemoteDataSource {
  @override
  bool get isConfigured => false;

  @override
  Future<void> uploadBackup({
    required String requestingUid,
    required CloudBackupPayload payload,
  }) async {
    throw StateError('Cloud backup backend is not configured yet.');
  }

  @override
  Future<CloudBackupPayload?> downloadBackup({
    required String requestingUid,
    required String targetUid,
  }) async {
    throw StateError('Cloud backup backend is not configured yet.');
  }
}

/// Deterministic in-memory cloud store strictly for testing authorization,
/// offline queueing, cross-device restore, deduplication, and conflict resolution.
class InMemoryCloudBackupDataSource implements CloudBackupRemoteDataSource {
  final Map<String, CloudBackupPayload> _remoteByUser =
      <String, CloudBackupPayload>{};
  bool isOnline = true;

  @override
  bool get isConfigured => true;

  void _enforceAuthorization(String requestingUid, String targetUid) {
    if (requestingUid.isEmpty ||
        requestingUid == UserProfile.guestUid ||
        requestingUid != targetUid) {
      throw StateError(
        'Unauthorized access: user "$requestingUid" cannot access data for "$targetUid".',
      );
    }
  }

  @override
  Future<void> uploadBackup({
    required String requestingUid,
    required CloudBackupPayload payload,
  }) async {
    _enforceAuthorization(requestingUid, payload.userId);
    if (!isOnline) {
      throw StateError('Device is offline.');
    }
    _remoteByUser[payload.userId] = payload;
  }

  @override
  Future<CloudBackupPayload?> downloadBackup({
    required String requestingUid,
    required String targetUid,
  }) async {
    _enforceAuthorization(requestingUid, targetUid);
    if (!isOnline) {
      throw StateError('Device is offline.');
    }
    return _remoteByUser[targetUid];
  }
}

/// Coordinates safe upload, restore, deduplication, conflict resolution,
/// and offline queueing for private per-user learning data.
class CloudSyncService extends ChangeNotifier {
  CloudSyncService({
    required this.remoteDataSource,
    required this.learningRepository,
    required this.settingsController,
  }) {
    _status = remoteDataSource.isConfigured
        ? const SyncStatusSnapshot(
            state: SyncStatusState.idle,
            message: 'Ready to sync.',
          )
        : const SyncStatusSnapshot(
            state: SyncStatusState.backendNotConfigured,
            message:
                'Cloud backup is not configured yet. Your data is safely stored locally on this device.',
          );
  }

  final CloudBackupRemoteDataSource remoteDataSource;
  final LearningRepository learningRepository;
  final SettingsController settingsController;

  late SyncStatusSnapshot _status;
  int _queuedLocalChanges = 0;

  SyncStatusSnapshot get status => _status;

  void markLocalChangePending() {
    _queuedLocalChanges++;
    if (!remoteDataSource.isConfigured) {
      _status = SyncStatusSnapshot(
        state: SyncStatusState.backendNotConfigured,
        pendingChangesCount: _queuedLocalChanges,
        message:
            'Stored locally. Connect Firebase to enable cloud backup.',
      );
    } else {
      _status = SyncStatusSnapshot(
        state: SyncStatusState.offlineQueued,
        lastSyncedAt: _status.lastSyncedAt,
        pendingChangesCount: _queuedLocalChanges,
        message: 'Local changes pending sync.',
      );
    }
    notifyListeners();
  }

  /// Performs a two-way merge sync (download remote -> conflict-safe merge ->
  /// save merged local -> upload merged backup) strictly for [user].
  Future<SyncMergeReport?> syncNow(UserProfile user) async {
    if (user.isGuest) {
      _status = const SyncStatusSnapshot(
        state: SyncStatusState.idle,
        message: 'Guest Mode uses local storage only. Sign in to sync.',
      );
      notifyListeners();
      return null;
    }

    if (!remoteDataSource.isConfigured) {
      _status = SyncStatusSnapshot(
        state: SyncStatusState.backendNotConfigured,
        pendingChangesCount: _queuedLocalChanges,
        message:
            'Cloud backup backend is not configured yet. Local data remains safe.',
      );
      notifyListeners();
      return null;
    }

    _status = SyncStatusSnapshot(
      state: SyncStatusState.syncing,
      lastSyncedAt: _status.lastSyncedAt,
      pendingChangesCount: _queuedLocalChanges,
      message: 'Syncing learning data...',
    );
    notifyListeners();

    try {
      final CloudBackupPayload? remote = await remoteDataSource.downloadBackup(
        requestingUid: user.uid,
        targetUid: user.uid,
      );

      final List<TestHistoryRecord> localHistory =
          await learningRepository.getTestHistory();
      final List<BookmarkedQuestionRecord> localBookmarks =
          await learningRepository.getBookmarkRecords();
      final List<WrongAnswerRecord> localWrong =
          await learningRepository.getWrongAnswerRecords(includeMastered: true);
      final DailyLearningGoal localGoal =
          await learningRepository.getDailyGoal();

      int restoredRecords = 0;
      int duplicatesSkipped = 0;
      int conflictsResolved = 0;

      // 1. Merge Test History (deduplicated by testId)
      final Map<String, TestHistoryRecord> mergedHistory =
          <String, TestHistoryRecord>{
        for (final TestHistoryRecord h in localHistory) h.testId: h,
      };
      if (remote != null) {
        for (final TestHistoryRecord r in remote.testHistory) {
          if (mergedHistory.containsKey(r.testId)) {
            duplicatesSkipped++;
          } else {
            mergedHistory[r.testId] = r;
            restoredRecords++;
          }
        }
      }

      // 2. Merge Bookmarks (deduplicated by questionId, newest savedAt wins)
      final Map<String, BookmarkedQuestionRecord> mergedBookmarks =
          <String, BookmarkedQuestionRecord>{
        for (final BookmarkedQuestionRecord b in localBookmarks)
          b.questionId: b,
      };
      if (remote != null) {
        for (final BookmarkedQuestionRecord r in remote.bookmarks) {
          final BookmarkedQuestionRecord? existing =
              mergedBookmarks[r.questionId];
          if (existing == null) {
            mergedBookmarks[r.questionId] = r;
            restoredRecords++;
          } else if (r.savedAt.isAfter(existing.savedAt)) {
            mergedBookmarks[r.questionId] = r;
            conflictsResolved++;
          } else {
            duplicatesSkipped++;
          }
        }
      }

      // 3. Merge Wrong Answers (max counts, latest revision/mastery wins)
      final Map<String, WrongAnswerRecord> mergedWrong =
          <String, WrongAnswerRecord>{
        for (final WrongAnswerRecord w in localWrong) w.questionId: w,
      };
      if (remote != null) {
        for (final WrongAnswerRecord r in remote.wrongAnswers) {
          final WrongAnswerRecord? existing = mergedWrong[r.questionId];
          if (existing == null) {
            mergedWrong[r.questionId] = r;
            restoredRecords++;
          } else {
            final DateTime existingLatest =
                existing.lastRevisedAt ?? existing.lastWrongAt;
            final DateTime remoteLatest = r.lastRevisedAt ?? r.lastWrongAt;
            final bool remoteNewer = remoteLatest.isAfter(existingLatest);

            mergedWrong[r.questionId] = WrongAnswerRecord(
              questionId: r.questionId,
              subject: r.subject,
              wrongCount: existing.wrongCount >= r.wrongCount
                  ? existing.wrongCount
                  : r.wrongCount,
              revisionAttempts:
                  existing.revisionAttempts >= r.revisionAttempts
                      ? existing.revisionAttempts
                      : r.revisionAttempts,
              isMastered: remoteNewer ? r.isMastered : existing.isMastered,
              lastWrongAt: existing.lastWrongAt.isAfter(r.lastWrongAt)
                  ? existing.lastWrongAt
                  : r.lastWrongAt,
              lastRevisedAt: remoteNewer
                  ? r.lastRevisedAt
                  : existing.lastRevisedAt,
              masteredAt: remoteNewer ? r.masteredAt : existing.masteredAt,
            );
            conflictsResolved++;
          }
        }
      }

      // 4. Merge Daily Goal (latest updatedAt wins)
      DailyLearningGoal mergedGoal = localGoal;
      if (remote != null &&
          remote.dailyGoal.updatedAt.isAfter(localGoal.updatedAt)) {
        mergedGoal = remote.dailyGoal;
        conflictsResolved++;
      }

      // Apply merged data back to local storage
      await learningRepository.applyMergedBackup(
        history: mergedHistory.values.toList(growable: false),
        bookmarks: mergedBookmarks.values.toList(growable: false),
        wrongAnswers: mergedWrong.values.toList(growable: false),
        dailyGoal: mergedGoal,
      );

      final DateTime now = DateTime.now().toUtc();
      final CloudBackupPayload uploadPayload = CloudBackupPayload(
        userId: user.uid,
        exportedAt: now,
        testHistory: mergedHistory.values.toList(growable: false),
        bookmarks: mergedBookmarks.values.toList(growable: false),
        wrongAnswers: mergedWrong.values.toList(growable: false),
        dailyGoal: mergedGoal,
        settings: settingsController.settings,
      );

      await remoteDataSource.uploadBackup(
        requestingUid: user.uid,
        payload: uploadPayload,
      );

      _queuedLocalChanges = 0;
      _status = SyncStatusSnapshot(
        state: SyncStatusState.synced,
        lastSyncedAt: now,
        pendingChangesCount: 0,
        message: 'Cloud backup up to date.',
      );
      notifyListeners();

      return SyncMergeReport(
        uploadedRecords: uploadPayload.testHistory.length +
            uploadPayload.bookmarks.length +
            uploadPayload.wrongAnswers.length,
        restoredRecords: restoredRecords,
        duplicatesSkipped: duplicatesSkipped,
        conflictsResolved: conflictsResolved,
        syncedAt: now,
      );
    } catch (e) {
      final bool looksOffline = e.toString().toLowerCase().contains('offline');
      _status = SyncStatusSnapshot(
        state: looksOffline
            ? SyncStatusState.offlineQueued
            : SyncStatusState.error,
        lastSyncedAt: _status.lastSyncedAt,
        pendingChangesCount: _queuedLocalChanges,
        message: looksOffline
            ? 'Offline — changes queued and will sync when back online.'
            : 'Sync paused. Local data remains safe.',
      );
      notifyListeners();
      return null;
    }
  }
}
