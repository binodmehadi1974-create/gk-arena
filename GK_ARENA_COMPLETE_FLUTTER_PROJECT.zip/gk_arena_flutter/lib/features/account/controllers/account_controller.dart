import 'package:flutter/foundation.dart';
import 'package:gk_arena/features/account/models/account_models.dart';
import 'package:gk_arena/features/account/services/auth_service.dart';
import 'package:gk_arena/features/account/services/cloud_backup_service.dart';
import 'package:gk_arena/features/learning/repositories/learning_repository.dart';
import 'package:gk_arena/features/settings/controllers/settings_controller.dart';

/// Coordinates active UserProfile (Guest Mode or authenticated user),
/// per-user data isolation switching, guest-to-account migration, and sync.
class AccountController extends ChangeNotifier {
  AccountController({
    required this.authService,
    required this.learningRepository,
    required this.settingsController,
    required this.cloudSyncService,
  }) : _activeUser = UserProfile.guest(
          preferredLanguage: settingsController.appLanguage,
        );

  final AuthService authService;
  final LearningRepository learningRepository;
  final SettingsController settingsController;
  final CloudSyncService cloudSyncService;

  UserProfile _activeUser;

  UserProfile get activeUser => _activeUser;
  bool get isGuest => _activeUser.isGuest;
  bool get isBackendConfigured => authService.isBackendConfigured;

  Future<void> initialize() async {
    final UserProfile? existing = authService.currentUser;
    if (existing != null) {
      _activeUser = existing;
    } else {
      _activeUser = UserProfile.guest(
        preferredLanguage: settingsController.appLanguage,
      );
    }
    learningRepository.setActiveUserId(_activeUser.uid);
    notifyListeners();
  }

  /// Registers a new account and optionally migrates local Guest Mode data
  /// into the newly created user's isolated namespace.
  Future<AuthActionResult> signUp({
    required String displayName,
    required String email,
    required String password,
    bool migrateGuestData = true,
  }) async {
    final AuthActionResult result = await authService.signUpWithEmail(
      displayName: displayName,
      email: email,
      password: password,
      preferredLanguage: settingsController.appLanguage,
    );

    if (result.success && result.user != null) {
      if (migrateGuestData) {
        await learningRepository.migrateUserData(
          fromUserId: UserProfile.guestUid,
          toUserId: result.user!.uid,
        );
      }
      _activeUser = result.user!;
      learningRepository.setActiveUserId(_activeUser.uid);
      notifyListeners();
    }
    return result;
  }

  /// Signs into an existing account and isolates local data to that user's UID.
  Future<AuthActionResult> login({
    required String email,
    required String password,
    bool migrateGuestData = false,
  }) async {
    final AuthActionResult result = await authService.loginWithEmail(
      email: email,
      password: password,
    );

    if (result.success && result.user != null) {
      if (migrateGuestData) {
        await learningRepository.migrateUserData(
          fromUserId: UserProfile.guestUid,
          toUserId: result.user!.uid,
        );
      }
      _activeUser = result.user!;
      learningRepository.setActiveUserId(_activeUser.uid);
      notifyListeners();
    }
    return result;
  }

  /// Signs out cleanly and switches back to isolated Guest Mode.
  Future<AuthActionResult> logout() async {
    final AuthActionResult result = await authService.logout();
    if (result.success) {
      _activeUser = UserProfile.guest(
        preferredLanguage: settingsController.appLanguage,
      );
      learningRepository.setActiveUserId(_activeUser.uid);
      notifyListeners();
    }
    return result;
  }

  Future<AuthActionResult> sendPasswordResetEmail(String email) {
    return authService.sendPasswordResetEmail(email: email);
  }

  Future<AuthActionResult> sendEmailVerification() async {
    final AuthActionResult result = await authService.sendEmailVerification();
    if (result.success && result.user != null) {
      _activeUser = result.user!;
      notifyListeners();
    }
    return result;
  }

  Future<AuthActionResult> changePassword({
    required String currentPassword,
    required String newPassword,
  }) {
    return authService.changePassword(
      currentPassword: currentPassword,
      newPassword: newPassword,
    );
  }

  /// Never claims deletion succeeded unless [authService] confirms backend deletion.
  Future<AuthActionResult> requestAccountDeletion({
    required String currentPassword,
  }) async {
    final String deletingUid = _activeUser.uid;
    final AuthActionResult result = await authService.requestAccountDeletion(
      currentPassword: currentPassword,
    );
    if (result.success) {
      learningRepository.setActiveUserId(deletingUid);
      await learningRepository.clearAllLearningData();
      _activeUser = UserProfile.guest(
        preferredLanguage: settingsController.appLanguage,
      );
      learningRepository.setActiveUserId(_activeUser.uid);
      notifyListeners();
    }
    return result;
  }

  Future<SyncMergeReport?> syncNow() => cloudSyncService.syncNow(_activeUser);
}
