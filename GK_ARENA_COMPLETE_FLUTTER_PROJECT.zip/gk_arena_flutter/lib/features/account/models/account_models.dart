import 'package:gk_arena/features/learning/models/learning_models.dart';
import 'package:gk_arena/features/settings/models/app_settings.dart';

/// Minimal, privacy-first user profile model (no unnecessary personal fields).
class UserProfile {
  const UserProfile({
    required this.uid,
    required this.displayName,
    this.email,
    required this.preferredLanguage,
    required this.createdAt,
    this.isGuest = false,
    this.emailVerified = false,
  });

  static const String guestUid = 'guest_local';

  final String uid;
  final String displayName;
  final String? email;
  final AppLanguage preferredLanguage;
  final DateTime createdAt;
  final bool isGuest;
  final bool emailVerified;

  factory UserProfile.guest({
    AppLanguage preferredLanguage = AppLanguage.hindi,
  }) {
    return UserProfile(
      uid: guestUid,
      displayName: 'Guest Learner',
      email: null,
      preferredLanguage: preferredLanguage,
      createdAt: DateTime.now().toUtc(),
      isGuest: true,
      emailVerified: false,
    );
  }

  UserProfile copyWith({
    String? displayName,
    String? email,
    AppLanguage? preferredLanguage,
    bool? emailVerified,
  }) {
    return UserProfile(
      uid: uid,
      displayName: displayName ?? this.displayName,
      email: email ?? this.email,
      preferredLanguage: preferredLanguage ?? this.preferredLanguage,
      createdAt: createdAt,
      isGuest: isGuest,
      emailVerified: emailVerified ?? this.emailVerified,
    );
  }

  Map<String, Object?> toJson() {
    return <String, Object?>{
      'uid': uid,
      'display_name': displayName,
      'email': email,
      'preferred_language': preferredLanguage.code,
      'created_at': createdAt.toUtc().toIso8601String(),
      'is_guest': isGuest,
      'email_verified': emailVerified,
    };
  }

  factory UserProfile.fromJson(Map<String, Object?> json) {
    return UserProfile(
      uid: (json['uid'] ?? guestUid).toString(),
      displayName: (json['display_name'] ?? 'Learner').toString(),
      email: json['email']?.toString(),
      preferredLanguage:
          AppLanguage.fromCode(json['preferred_language']?.toString()),
      createdAt: DateTime.parse(
        (json['created_at'] ?? DateTime.now().toUtc().toIso8601String())
            .toString(),
      ),
      isGuest: json['is_guest'] == true,
      emailVerified: json['email_verified'] == true,
    );
  }
}

/// Result returned by authentication actions. Never claims success unless
/// actually confirmed by an active configured provider.
class AuthActionResult {
  const AuthActionResult({
    required this.success,
    required this.message,
    this.requiresBackendConfig = false,
    this.user,
  });

  final bool success;
  final String message;
  final bool requiresBackendConfig;
  final UserProfile? user;
}

enum SyncStatusState {
  idle,
  syncing,
  synced,
  offlineQueued,
  backendNotConfigured,
  error,
}

class SyncStatusSnapshot {
  const SyncStatusSnapshot({
    required this.state,
    this.lastSyncedAt,
    this.pendingChangesCount = 0,
    this.message = '',
  });

  final SyncStatusState state;
  final DateTime? lastSyncedAt;
  final int pendingChangesCount;
  final String message;
}

/// Private per-user learning backup payload.
/// Public Question Bank data is strictly excluded from user cloud backups.
class CloudBackupPayload {
  const CloudBackupPayload({
    required this.userId,
    required this.exportedAt,
    required this.testHistory,
    required this.bookmarks,
    required this.wrongAnswers,
    required this.dailyGoal,
    required this.settings,
  });

  final String userId;
  final DateTime exportedAt;
  final List<TestHistoryRecord> testHistory;
  final List<BookmarkedQuestionRecord> bookmarks;
  final List<WrongAnswerRecord> wrongAnswers;
  final DailyLearningGoal dailyGoal;
  final AppSettings settings;
}

class SyncMergeReport {
  const SyncMergeReport({
    required this.uploadedRecords,
    required this.restoredRecords,
    required this.duplicatesSkipped,
    required this.conflictsResolved,
    required this.syncedAt,
  });

  final int uploadedRecords;
  final int restoredRecords;
  final int duplicatesSkipped;
  final int conflictsResolved;
  final DateTime syncedAt;
}
