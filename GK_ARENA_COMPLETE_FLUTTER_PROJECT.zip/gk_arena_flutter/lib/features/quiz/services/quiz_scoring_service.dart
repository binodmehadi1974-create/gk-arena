import 'package:gk_arena/features/quiz/models/quiz_models.dart';

/// Pure Dart configurable scoring engine computing real results without hardcoded exam rules.
class QuizScoringService {
  const QuizScoringService();

  QuizResult evaluate({
    required QuizConfig config,
    required List<QuizQuestionState> states,
    required int timeTakenSeconds,
    required bool wasAutoSubmitted,
  }) {
    final ScoringRules rules = config.scoringRules;
    int correct = 0;
    int incorrect = 0;
    int unattempted = 0;
    double score = 0.0;
    final List<QuestionReviewItem> reviewItems = <QuestionReviewItem>[];

    for (int i = 0; i < states.length; i++) {
      final QuizQuestionState state = states[i];
      final int? selected = state.selectedOptionIndex;
      final AnswerOutcome outcome;
      final double marks;

      if (selected == null) {
        unattempted++;
        outcome = AnswerOutcome.unattempted;
        marks = rules.marksPerUnattempted;
      } else if (selected == state.question.correctOptionIndex) {
        correct++;
        outcome = AnswerOutcome.correct;
        marks = rules.marksPerCorrect;
      } else {
        incorrect++;
        outcome = AnswerOutcome.incorrect;
        marks = -rules.negativeMarkingPerWrong;
      }

      score += marks;
      reviewItems.add(
        QuestionReviewItem(
          index: i,
          question: state.question,
          selectedOptionIndex: selected,
          isMarkedForReview: state.isMarkedForReview,
          outcome: outcome,
          marksAwarded: marks,
        ),
      );
    }

    final int attempted = correct + incorrect;
    final double accuracy =
        attempted == 0 ? 0.0 : (correct / attempted) * 100.0;
    final double maxScore = states.length * rules.marksPerCorrect;
    final double roundedScore = double.parse(score.toStringAsFixed(2));
    final double roundedAccuracy = double.parse(accuracy.toStringAsFixed(1));

    return QuizResult(
      config: config,
      totalQuestions: states.length,
      correctCount: correct,
      incorrectCount: incorrect,
      unattemptedCount: unattempted,
      totalScore: roundedScore,
      maxScore: maxScore,
      accuracyPercent: roundedAccuracy,
      timeTakenSeconds: timeTakenSeconds,
      wasAutoSubmitted: wasAutoSubmitted,
      performanceSummary: _buildSummary(
        attempted: attempted,
        total: states.length,
        accuracy: roundedAccuracy,
      ),
      reviewItems: List<QuestionReviewItem>.unmodifiable(reviewItems),
    );
  }

  String _buildSummary({
    required int attempted,
    required int total,
    required double accuracy,
  }) {
    if (total == 0 || attempted == 0) {
      return 'कोई प्रश्न हल नहीं किया गया। उत्तर समीक्षा देखें और दोबारा प्रयास करें।';
    }
    if (accuracy >= 85.0) {
      return 'उत्कृष्ट प्रदर्शन! आपकी सटीकता बहुत मजबूत है।';
    }
    if (accuracy >= 65.0) {
      return 'अच्छा प्रयास! गलत प्रश्नों की व्याख्या देखकर इसे और बेहतर बनाएँ।';
    }
    if (accuracy >= 40.0) {
      return 'संतोषजनक शुरुआत। नियमित अभ्यास से सटीकता तेजी से सुधरेगी।';
    }
    return 'और अभ्यास की आवश्यकता है। प्रत्येक प्रश्न की व्याख्या ध्यान से पढ़ें।';
  }
}
