import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/features/quiz/services/recent_question_tracker.dart';

enum QuizLoadStatus {
  ready,
  emptyBank,
  insufficientQuestions,
  invalidConfig,
}

class QuizLoadResult {
  const QuizLoadResult({
    required this.status,
    required this.questions,
    required this.availableCount,
    required this.requestedCount,
    this.message,
  });

  final QuizLoadStatus status;
  final List<Question> questions;
  final int availableCount;
  final int requestedCount;
  final String? message;

  bool get canStartFull => status == QuizLoadStatus.ready;
  bool get canStartPartial =>
      status == QuizLoadStatus.insufficientQuestions && questions.isNotEmpty;
}

/// Loads and validates test question sets from QuestionRepository using bounded
/// candidate pools so 100,000+ MCQ banks are never loaded into RAM at once.
class QuizQuestionLoader {
  const QuizQuestionLoader({
    required this.repository,
    required this.recentTracker,
  });

  final QuestionRepository repository;
  final RecentQuestionTracker recentTracker;

  List<String> validateConfig(QuizConfig config) {
    final List<String> errors = <String>[];
    if (config.questionCount <= 0) {
      errors.add('प्रश्नों की संख्या कम से कम 1 होनी चाहिए।');
    }
    if ((config.mode == TestMode.subjectWise ||
            config.mode == TestMode.topicWise) &&
        config.subjects.isEmpty) {
      errors.add('कृपया कम से कम एक विषय चुनें।');
    }
    if (config.mode == TestMode.timed || config.mode == TestMode.fullMock) {
      if (config.durationSeconds == null || config.durationSeconds! <= 0) {
        errors.add('समय सीमा वाले टेस्ट के लिए वैध अवधि चुनें।');
      }
    }
    return errors;
  }

  /// Queries distinct topic names directly from the database (never loads full MCQs).
  Future<List<String>> getAvailableTopics({
    QuestionSubject? subject,
    QuestionLanguage? language,
  }) {
    return repository.getDistinctTopics(
      subject: subject,
      language: language,
      publicationStatus: PublicationStatus.published,
    );
  }

  Future<QuizLoadResult> loadForConfig(QuizConfig config) async {
    final List<String> configErrors = validateConfig(config);
    if (configErrors.isNotEmpty) {
      return QuizLoadResult(
        status: QuizLoadStatus.invalidConfig,
        questions: const <Question>[],
        availableCount: 0,
        requestedCount: config.questionCount,
        message: configErrors.join(' '),
      );
    }

    final int totalBankCount = await repository.count(
      filter: const QuestionFilter(
        publicationStatus: PublicationStatus.published,
      ),
    );
    if (totalBankCount == 0) {
      return QuizLoadResult(
        status: QuizLoadStatus.emptyBank,
        questions: const <Question>[],
        availableCount: 0,
        requestedCount: config.questionCount,
        message: 'प्रश्न बैंक अभी खाली है। कृपया पहले प्रश्न जोड़ें या लोड करें।',
      );
    }

    final List<Question> pool = await _fetchBoundedCandidatePool(config);
    if (pool.isEmpty) {
      return QuizLoadResult(
        status: QuizLoadStatus.insufficientQuestions,
        questions: const <Question>[],
        availableCount: 0,
        requestedCount: config.questionCount,
        message: 'चयनित फ़िल्टर के अनुसार कोई प्रश्न उपलब्ध नहीं है।',
      );
    }

    final List<Question> selected = recentTracker.selectQuestions(
      pool: pool,
      count: config.questionCount,
      allowRepeatRecent: config.allowRepeatRecent,
    );

    if (selected.length < config.questionCount) {
      return QuizLoadResult(
        status: QuizLoadStatus.insufficientQuestions,
        questions: selected,
        availableCount: selected.length,
        requestedCount: config.questionCount,
        message:
            'चयनित मानदंड के लिए केवल ${selected.length} प्रश्न उपलब्ध हैं (माँगे गए: ${config.questionCount})।',
      );
    }

    return QuizLoadResult(
      status: QuizLoadStatus.ready,
      questions: selected,
      availableCount: pool.length,
      requestedCount: config.questionCount,
    );
  }

  /// Fetches only a bounded candidate window (e.g., 5x requested count, capped
  /// at 250) and strictly filters published questions for student quizzes.
  Future<List<Question>> _fetchBoundedCandidatePool(QuizConfig config) async {
    final int candidateCap = (config.questionCount * 5).clamp(40, 250);

    if (config.mode == TestMode.topicWise &&
        config.topic != null &&
        config.topic!.trim().isNotEmpty) {
      return repository.query(
        QuestionFilter(
          subject: config.subjects.isNotEmpty ? config.subjects.first : null,
          topic: config.topic!,
          language: config.language,
          difficulty: config.difficulty,
          publicationStatus: PublicationStatus.published,
          limit: candidateCap,
        ),
      );
    }

    if (config.subjects.isNotEmpty) {
      final int perSubjectLimit =
          (candidateCap / config.subjects.length).ceil().clamp(20, 250);
      final List<Question> combined = <Question>[];
      final Set<String> seenIds = <String>{};
      for (final QuestionSubject subject in config.subjects) {
        final List<Question> subjectRows = await repository.query(
          QuestionFilter(
            subject: subject,
            language: config.language,
            difficulty: config.difficulty,
            publicationStatus: PublicationStatus.published,
            limit: perSubjectLimit,
          ),
        );
        for (final Question q in subjectRows) {
          if (seenIds.add(q.id)) {
            combined.add(q);
          }
        }
      }
      return combined;
    }

    return repository.getMixed(
      language: config.language,
      difficulty: config.difficulty,
      publicationStatus: PublicationStatus.published,
      limit: candidateCap,
    );
  }
}
