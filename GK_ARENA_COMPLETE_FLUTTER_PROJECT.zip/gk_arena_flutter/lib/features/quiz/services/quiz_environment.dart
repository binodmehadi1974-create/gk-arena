import 'package:flutter/foundation.dart';
import 'package:gk_arena/features/account/controllers/account_controller.dart';
import 'package:gk_arena/features/account/services/auth_service.dart';
import 'package:gk_arena/features/account/services/cloud_backup_service.dart';
import 'package:gk_arena/features/monetization/services/ad_manager.dart';
import 'package:gk_arena/features/learning/database/in_memory_learning_data_source.dart';
import 'package:gk_arena/features/learning/database/learning_data_source.dart';
import 'package:gk_arena/features/learning/database/sqlite_learning_data_source.dart';
import 'package:gk_arena/features/learning/repositories/learning_repository.dart';
import 'package:gk_arena/features/question_bank/database/in_memory_question_data_source.dart';
import 'package:gk_arena/features/question_bank/database/question_data_source.dart';
import 'package:gk_arena/features/question_bank/database/sample_data_loader.dart';
import 'package:gk_arena/features/question_bank/database/sqlite_question_data_source.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';
import 'package:gk_arena/features/quiz/services/quiz_question_loader.dart';
import 'package:gk_arena/features/quiz/services/quiz_scoring_service.dart';
import 'package:gk_arena/features/quiz/services/recent_question_tracker.dart';
import 'package:gk_arena/features/settings/controllers/settings_controller.dart';
import 'package:gk_arena/features/settings/database/in_memory_settings_data_source.dart';
import 'package:gk_arena/features/settings/database/settings_data_source.dart';
import 'package:gk_arena/features/settings/database/sqlite_settings_data_source.dart';

/// Shared runtime dependency container wiring Question Bank, Quiz Engine,
/// Student Learning Tracking, Settings, and User Account / Cloud Sync cleanly.
class QuizEnvironment {
  QuizEnvironment({
    QuestionRepository? repository,
    RecentQuestionTracker? recentTracker,
    QuizScoringService? scoringService,
    LearningRepository? learningRepository,
    SettingsController? settingsController,
    AuthService? authService,
    CloudBackupRemoteDataSource? cloudBackupDataSource,
    AdManager? adManager,
  })  : repository = repository ??
            QuestionRepository(dataSource: _defaultDataSource()),
        recentTracker = recentTracker ?? RecentQuestionTracker(),
        scoringService = scoringService ?? const QuizScoringService() {
    questionLoader = QuizQuestionLoader(
      repository: this.repository,
      recentTracker: this.recentTracker,
    );
    this.learningRepository = learningRepository ??
        LearningRepository(
          dataSource: _defaultLearningDataSource(),
          questionRepository: this.repository,
        );
    this.settingsController = settingsController ??
        SettingsController(
          dataSource: _defaultSettingsDataSource(),
          learningRepository: this.learningRepository,
        );
    cloudSyncService = CloudSyncService(
      remoteDataSource:
          cloudBackupDataSource ?? UnconfiguredCloudBackupDataSource(),
      learningRepository: this.learningRepository,
      settingsController: this.settingsController,
    );
    this.adManager = adManager ?? AdManager();
    accountController = AccountController(
      authService: authService ?? UnconfiguredAuthService(),
      learningRepository: this.learningRepository,
      settingsController: this.settingsController,
      cloudSyncService: cloudSyncService,
    );
  }

  final QuestionRepository repository;
  final RecentQuestionTracker recentTracker;
  final QuizScoringService scoringService;
  late final QuizQuestionLoader questionLoader;
  late final LearningRepository learningRepository;
  late final SettingsController settingsController;
  late final CloudSyncService cloudSyncService;
  late final AccountController accountController;
  late final AdManager adManager;

  bool _initialized = false;
  Future<void>? _initInFlight;

  static bool get _isMobilePlatform =>
      !kIsWeb &&
      (defaultTargetPlatform == TargetPlatform.android ||
          defaultTargetPlatform == TargetPlatform.iOS);

  static QuestionDataSource _defaultDataSource() {
    if (_isMobilePlatform) {
      return SqliteQuestionDataSource();
    }
    return InMemoryQuestionDataSource();
  }

  static LearningDataSource _defaultLearningDataSource() {
    if (_isMobilePlatform) {
      return SqliteLearningDataSource();
    }
    return InMemoryLearningDataSource();
  }

  static SettingsDataSource _defaultSettingsDataSource() {
    if (_isMobilePlatform) {
      return SqliteSettingsDataSource();
    }
    return InMemorySettingsDataSource();
  }

  /// Initializes question bank, learning tracking, settings, and account state.
  Future<void> ensureInitialized({bool loadDemoIfEmpty = true}) {
    if (_initialized) return Future<void>.value();
    return _initInFlight ??= _runInitialization(loadDemoIfEmpty: loadDemoIfEmpty);
  }

  Future<void> _runInitialization({required bool loadDemoIfEmpty}) async {
    try {
      // Initialize local SQLite stores concurrently for faster app startup.
      await Future.wait<void>(<Future<void>>[
        repository.initialize(),
        learningRepository.initialize(),
        settingsController.initialize(),
      ]);
      await accountController.initialize();
      await adManager.initialize();
      if (loadDemoIfEmpty && await repository.count() == 0) {
        final SampleDataLoader loader = SampleDataLoader(repository: repository);
        try {
          await loader.loadDemoSamples();
        } catch (_) {
          // Keep repository operational even if asset bundle is unavailable in unit tests.
        }
      }
      _initialized = true;
    } finally {
      _initInFlight = null;
    }
  }

  Future<void> dispose() async {
    adManager.dispose();
    await settingsController.close();
    await learningRepository.close();
    await repository.close();
  }
}
