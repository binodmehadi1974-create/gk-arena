import 'dart:collection';
import 'package:gk_arena/features/question_bank/models/question_model.dart';

/// Bounded recency tracker implementing no-repeat logic for normal practice
/// while allowing revision modes to repeat and never permanently excluding questions.
class RecentQuestionTracker {
  RecentQuestionTracker({this.maxHistorySize = 200});

  final int maxHistorySize;
  final ListQueue<String> _recentOrder = ListQueue<String>();
  final Set<String> _recentSet = <String>{};

  int get trackedCount => _recentSet.length;

  bool wasRecentlyAnswered(String questionId) => _recentSet.contains(questionId);

  void recordAnswered(Iterable<String> questionIds) {
    for (final String id in questionIds) {
      if (_recentSet.contains(id)) {
        _recentOrder.remove(id);
      } else {
        _recentSet.add(id);
      }
      _recentOrder.addLast(id);

      while (_recentOrder.length > maxHistorySize) {
        final String evicted = _recentOrder.removeFirst();
        _recentSet.remove(evicted);
      }
    }
  }

  void clear() {
    _recentOrder.clear();
    _recentSet.clear();
  }

  /// Selects up to [count] questions from [pool]:
  /// - When [allowRepeatRecent] is true (revision mode), preserves pool order directly.
  /// - Otherwise prioritizes unseen questions first, then gracefully tops up from
  ///   least-recently-seen questions if the unseen pool is smaller than [count].
  List<Question> selectQuestions({
    required List<Question> pool,
    required int count,
    required bool allowRepeatRecent,
  }) {
    if (pool.isEmpty || count <= 0) return const <Question>[];
    if (allowRepeatRecent) {
      return pool.take(count).toList(growable: false);
    }

    final List<Question> unseen = <Question>[];
    final List<Question> seen = <Question>[];

    for (final Question q in pool) {
      if (_recentSet.contains(q.id)) {
        seen.add(q);
      } else {
        unseen.add(q);
      }
    }

    if (unseen.length >= count) {
      return unseen.take(count).toList(growable: false);
    }

    // Order seen questions from oldest-seen to newest-seen so we never permanently exclude.
    final Map<String, int> recencyRank = <String, int>{};
    int rank = 0;
    for (final String id in _recentOrder) {
      recencyRank[id] = rank++;
    }
    seen.sort(
      (Question a, Question b) =>
          (recencyRank[a.id] ?? 0).compareTo(recencyRank[b.id] ?? 0),
    );

    final List<Question> combined = <Question>[...unseen, ...seen];
    return combined.take(count).toList(growable: false);
  }
}
