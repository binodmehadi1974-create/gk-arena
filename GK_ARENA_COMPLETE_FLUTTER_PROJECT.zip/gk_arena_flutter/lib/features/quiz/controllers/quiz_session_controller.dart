import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/features/quiz/services/quiz_scoring_service.dart';
import 'package:gk_arena/features/quiz/services/recent_question_tracker.dart';

/// Stateful Quiz Session Controller separate from UI widgets.
/// Manages navigation, answer selection, mark-for-review, countdown/elapsed timer,
/// auto-submit, duplicate-submission prevention, pause/resume, and snapshot restore.
class QuizSessionController extends ChangeNotifier {
  QuizSessionController({
    required this.config,
    required List<Question> questions,
    required this.scoringService,
    required this.recentTracker,
    this.onSubmitted,
  })  : assert(questions.isNotEmpty, 'Quiz session requires at least 1 question.'),
        _states = questions
            .map((Question q) => QuizQuestionState(question: q))
            .toList(growable: false),
        _remainingSeconds = config.isTimed ? config.durationSeconds! : 0;

  final QuizConfig config;
  final QuizScoringService scoringService;
  final RecentQuestionTracker recentTracker;
  final ValueChanged<QuizResult>? onSubmitted;

  final List<QuizQuestionState> _states;
  int _currentIndex = 0;
  int _remainingSeconds;
  int _elapsedSeconds = 0;
  bool _isSubmitted = false;
  bool _isTimerPaused = false;
  QuizResult? _result;
  Timer? _timer;

  List<QuizQuestionState> get states => List<QuizQuestionState>.unmodifiable(_states);
  int get totalQuestions => _states.length;
  int get currentIndex => _currentIndex;
  QuizQuestionState get currentState => _states[_currentIndex];
  Question get currentQuestion => _states[_currentIndex].question;
  bool get isFirstQuestion => _currentIndex == 0;
  bool get isLastQuestion => _currentIndex == _states.length - 1;
  bool get isTimed => config.isTimed;
  int get remainingSeconds => _remainingSeconds;
  int get elapsedSeconds => _elapsedSeconds;
  bool get isSubmitted => _isSubmitted;
  bool get isTimerPaused => _isTimerPaused;
  QuizResult? get result => _result;

  int get answeredCount =>
      _states.where((QuizQuestionState s) => s.isAnswered).length;
  int get unansweredCount => _states.length - answeredCount;
  int get markedCount =>
      _states.where((QuizQuestionState s) => s.isMarkedForReview).length;

  void startTimer() {
    if (_isSubmitted || _timer != null) return;
    _isTimerPaused = false;
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => tickOneSecond());
  }

  /// Exposed cleanly for deterministic unit testing and internal 1-second ticks.
  void tickOneSecond() {
    if (_isSubmitted || _isTimerPaused) return;
    _elapsedSeconds++;

    if (config.isTimed) {
      if (_remainingSeconds > 0) {
        _remainingSeconds--;
      }
      if (_remainingSeconds <= 0) {
        submit(autoSubmitted: true);
        return;
      }
    }
    notifyListeners();
  }

  void pauseTimer() {
    if (_isSubmitted) return;
    _isTimerPaused = true;
    notifyListeners();
  }

  void resumeTimer() {
    if (_isSubmitted) return;
    _isTimerPaused = false;
    notifyListeners();
  }

  void selectOption(int optionIndex) {
    if (_isSubmitted || optionIndex < 0 || optionIndex > 3) return;
    _states[_currentIndex] = _states[_currentIndex].copyWith(
      selectedOptionIndex: optionIndex,
    );
    notifyListeners();
  }

  void clearAnswer() {
    if (_isSubmitted) return;
    _states[_currentIndex] = _states[_currentIndex].copyWith(
      clearSelection: true,
    );
    notifyListeners();
  }

  void toggleMarkForReview() {
    if (_isSubmitted) return;
    final bool current = _states[_currentIndex].isMarkedForReview;
    _states[_currentIndex] = _states[_currentIndex].copyWith(
      isMarkedForReview: !current,
    );
    notifyListeners();
  }

  void nextQuestion() {
    if (_isSubmitted || isLastQuestion) return;
    _currentIndex++;
    notifyListeners();
  }

  void previousQuestion() {
    if (_isSubmitted || isFirstQuestion) return;
    _currentIndex--;
    notifyListeners();
  }

  void jumpToQuestion(int index) {
    if (_isSubmitted || index < 0 || index >= _states.length) return;
    _currentIndex = index;
    notifyListeners();
  }

  /// Submits the quiz safely with strict duplicate-submission prevention.
  QuizResult submit({bool autoSubmitted = false}) {
    if (_isSubmitted && _result != null) {
      return _result!;
    }

    _isSubmitted = true;
    _timer?.cancel();
    _timer = null;

    final QuizResult computed = scoringService.evaluate(
      config: config,
      states: _states,
      timeTakenSeconds: _elapsedSeconds,
      wasAutoSubmitted: autoSubmitted,
    );
    _result = computed;

    // Record answered questions for non-permanent no-repeat logic.
    final Iterable<String> answeredIds = _states
        .where((QuizQuestionState s) => s.isAnswered)
        .map((QuizQuestionState s) => s.question.id);
    recentTracker.recordAnswered(answeredIds);

    notifyListeners();
    onSubmitted?.call(computed);
    return computed;
  }

  QuizSessionSnapshot exportSnapshot() {
    final Map<int, int> selected = <int, int>{};
    final List<int> marked = <int>[];
    for (int i = 0; i < _states.length; i++) {
      if (_states[i].selectedOptionIndex != null) {
        selected[i] = _states[i].selectedOptionIndex!;
      }
      if (_states[i].isMarkedForReview) {
        marked.add(i);
      }
    }
    return QuizSessionSnapshot(
      currentIndex: _currentIndex,
      selectedOptionsByIndex: selected,
      markedIndices: marked,
      remainingSeconds: _remainingSeconds,
      elapsedSeconds: _elapsedSeconds,
      isSubmitted: _isSubmitted,
    );
  }

  void restoreFromSnapshot(QuizSessionSnapshot snapshot) {
    if (snapshot.currentIndex >= 0 && snapshot.currentIndex < _states.length) {
      _currentIndex = snapshot.currentIndex;
    }
    for (int i = 0; i < _states.length; i++) {
      _states[i] = _states[i].copyWith(
        selectedOptionIndex: snapshot.selectedOptionsByIndex[i],
        clearSelection: !snapshot.selectedOptionsByIndex.containsKey(i),
        isMarkedForReview: snapshot.markedIndices.contains(i),
      );
    }
    _remainingSeconds = snapshot.remainingSeconds;
    _elapsedSeconds = snapshot.elapsedSeconds;
    _isSubmitted = snapshot.isSubmitted;
    notifyListeners();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _timer = null;
    super.dispose();
  }
}
