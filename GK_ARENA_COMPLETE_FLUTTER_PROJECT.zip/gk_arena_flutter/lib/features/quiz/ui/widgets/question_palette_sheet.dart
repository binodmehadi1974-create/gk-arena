import 'package:flutter/material.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';

/// Bottom sheet displaying all question statuses (answered, unanswered, marked).
class QuestionPaletteSheet extends StatelessWidget {
  const QuestionPaletteSheet({
    super.key,
    required this.states,
    required this.currentIndex,
    required this.onSelectIndex,
  });

  final List<QuizQuestionState> states;
  final int currentIndex;
  final ValueChanged<int> onSelectIndex;

  @override
  Widget build(BuildContext context) {
    final int answered =
        states.where((QuizQuestionState s) => s.isAnswered).length;
    final int marked =
        states.where((QuizQuestionState s) => s.isMarkedForReview).length;
    final int unanswered = states.length - answered;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, AppSpacing.md, 20, AppSpacing.lg),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                const Expanded(
                  child: Text(
                    'Question Palette',
                    style: AppTextStyles.sectionTitle,
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: const Icon(Icons.close_rounded),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.xs),
            Wrap(
              spacing: AppSpacing.md,
              runSpacing: AppSpacing.xs,
              children: <Widget>[
                _LegendDot(
                  color: AppColors.success,
                  label: 'Answered ($answered)',
                ),
                _LegendDot(
                  color: AppColors.warning,
                  label: 'Marked ($marked)',
                ),
                _LegendDot(
                  color: AppColors.border,
                  label: 'Unanswered ($unanswered)',
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.md),
            ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 320),
              child: GridView.builder(
                shrinkWrap: true,
                itemCount: states.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 5,
                  crossAxisSpacing: AppSpacing.xs,
                  mainAxisSpacing: AppSpacing.xs,
                  childAspectRatio: 1.15,
                ),
                itemBuilder: (BuildContext context, int index) {
                  final QuizQuestionState state = states[index];
                  final bool isCurrent = index == currentIndex;
                  final Color fillColor;
                  final Color textColor;

                  switch (state.paletteStatus) {
                    case QuestionPaletteStatus.answered:
                      fillColor = AppColors.success;
                      textColor = AppColors.textOnDark;
                    case QuestionPaletteStatus.markedForReview:
                      fillColor = AppColors.warning;
                      textColor = AppColors.textOnDark;
                    case QuestionPaletteStatus.answeredAndMarked:
                      fillColor = AppColors.primary;
                      textColor = AppColors.textOnDark;
                    case QuestionPaletteStatus.unanswered:
                      fillColor = AppColors.background;
                      textColor = AppColors.textPrimary;
                  }

                  return Material(
                    color: fillColor,
                    borderRadius: BorderRadius.circular(AppSpacing.radiusSm),
                    child: InkWell(
                      onTap: () {
                        Navigator.of(context).pop();
                        onSelectIndex(index);
                      },
                      borderRadius: BorderRadius.circular(AppSpacing.radiusSm),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius:
                              BorderRadius.circular(AppSpacing.radiusSm),
                          border: Border.all(
                            color: isCurrent
                                ? AppColors.deepNavy
                                : AppColors.border,
                            width: isCurrent ? 2 : 1,
                          ),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          '${index + 1}',
                          style: AppTextStyles.buttonLabel.copyWith(
                            color: textColor,
                            fontSize: 13.5,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LegendDot extends StatelessWidget {
  const _LegendDot({
    required this.color,
    required this.label,
  });

  final Color color;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 6),
        Text(label, style: AppTextStyles.cardSubtitle),
      ],
    );
  }
}
