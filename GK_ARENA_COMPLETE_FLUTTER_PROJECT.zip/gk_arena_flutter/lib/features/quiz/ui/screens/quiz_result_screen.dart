import 'package:flutter/material.dart';
import 'package:gk_arena/features/monetization/services/ad_manager.dart';
import 'package:gk_arena/features/monetization/ui/widgets/gk_banner_ad_slot.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/features/quiz/services/quiz_environment.dart';
import 'package:gk_arena/features/quiz/services/quiz_question_loader.dart';
import 'package:gk_arena/features/quiz/ui/screens/answer_review_screen.dart';
import 'package:gk_arena/features/quiz/ui/screens/quiz_screen.dart';
import 'package:gk_arena/features/settings/localization/app_strings.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/navigation/smooth_page_route.dart';
import 'package:gk_arena/ui/widgets/premium_button.dart';

/// Premium Result Screen displaying real calculated quiz scores and actions.
/// Supports both fresh submissions and reopening saved tests from Test History.
class QuizResultScreen extends StatelessWidget {
  const QuizResultScreen({
    super.key,
    required this.result,
    required this.environment,
    this.isHistoricalView = false,
  });

  final QuizResult result;
  final QuizEnvironment environment;
  final bool isHistoricalView;

  String _formatDuration(int seconds) {
    final int mins = seconds ~/ 60;
    final int secs = seconds % 60;
    if (mins == 0) return '${secs}s';
    return '${mins}m ${secs}s';
  }

  Future<void> _retryTest(BuildContext context) async {
    final QuizLoadResult loaded =
        await environment.questionLoader.loadForConfig(result.config);
    if (!context.mounted) return;
    if (loaded.questions.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            loaded.message ?? 'पुनः प्रयास के लिए प्रश्न उपलब्ध नहीं हैं।',
          ),
        ),
      );
      return;
    }
    Navigator.of(context).pushReplacement(
      SmoothPageRoute<void>(
        builder: (_) => QuizScreen(
          config: result.config.copyWith(
            questionCount: loaded.questions.length,
          ),
          questions: loaded.questions,
          environment: environment,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final AppStrings s = AppLanguageScope.of(context);
    final Color surface = AppColors.surfaceOf(context);
    final Color border = AppColors.borderOf(context);
    final Color textPrimary = AppColors.textPrimaryOf(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(isHistoricalView ? s.savedTestResult : s.testResult),
        automaticallyImplyLeading: isHistoricalView,
      ),
      bottomNavigationBar: GkBannerAdSlot(
        policyService: environment.adManager.policyService,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(
            20,
            AppSpacing.sm,
            20,
            AppSpacing.lg,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // Hero Score Summary Card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(AppSpacing.lg),
                decoration: BoxDecoration(
                  gradient: AppColors.heroGradient,
                  borderRadius: BorderRadius.circular(AppSpacing.radiusXl),
                  boxShadow: AppSpacing.heroCardShadow,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: Text(
                            s.isHindi
                                ? result.config.mode.titleHi
                                : result.config.mode.titleEn,
                            style: AppTextStyles.heroSubtitle.copyWith(
                              fontWeight: FontWeight.w600,
                              color: AppColors.textOnDark,
                            ),
                          ),
                        ),
                        if (result.wasAutoSubmitted)
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0x33E8A23A),
                              borderRadius:
                                  BorderRadius.circular(AppSpacing.radiusPill),
                            ),
                            child: const Text(
                              'Auto-Submitted',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: AppColors.textOnDark,
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: AppSpacing.md),
                    Text(
                      '${result.totalScore} / ${result.maxScore}',
                      style: const TextStyle(
                        fontSize: 34,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textOnDark,
                        height: 1.1,
                      ),
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    Text(
                      'Accuracy: ${result.accuracyPercent}%  •  Time: ${_formatDuration(result.timeTakenSeconds)}',
                      style: AppTextStyles.heroSubtitle,
                    ),
                    const SizedBox(height: AppSpacing.md),
                    Text(
                      result.performanceSummary,
                      style: AppTextStyles.heroSubtitle.copyWith(
                        color: AppColors.textOnDark,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.lg),

              // Breakdown Metrics
              Row(
                children: <Widget>[
                  Expanded(
                    child: _MetricTile(
                      label: s.correct,
                      value: '${result.correctCount}',
                      color: AppColors.success,
                      background: AppColors.softGreenOf(context),
                      border: border,
                    ),
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: _MetricTile(
                      label: s.incorrect,
                      value: '${result.incorrectCount}',
                      color: AppColors.danger,
                      background: AppColors.isDark(context)
                          ? const Color(0xFF3A1C22)
                          : const Color(0xFFFDECEC),
                      border: border,
                    ),
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: _MetricTile(
                      label: s.skipped,
                      value: '${result.unattemptedCount}',
                      color: AppColors.textSecondaryOf(context),
                      background: surface,
                      border: border,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.md),

              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(AppSpacing.md),
                decoration: BoxDecoration(
                  color: surface,
                  borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
                  border: Border.all(color: border, width: 1),
                ),
                child: Text(
                  '${s.t(hi: 'अंक योजना', en: 'Marking Scheme')}: ${result.config.scoringRules.label}',
                  style: AppTextStyles.bodyPrimary.copyWith(color: textPrimary),
                ),
              ),
              const SizedBox(height: AppSpacing.lg),

              PremiumButton(
                label: s.reviewAnswers,
                variant: PremiumButtonVariant.primary,
                trailingIcon: Icons.fact_check_outlined,
                fullWidth: true,
                onPressed: () {
                  Navigator.of(context).push(
                    SmoothPageRoute<void>(
                      builder: (_) => AnswerReviewScreen(
                        result: result,
                        learningRepository: environment.learningRepository,
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: AppSpacing.sm),
              // Optional voluntary Rewarded Ad card (never gates core study features)
              if (!isHistoricalView) ...<Widget>[
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(AppSpacing.md),
                  decoration: BoxDecoration(
                    color: surface,
                    borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
                    border: Border.all(color: border, width: 1),
                  ),
                  child: Row(
                    children: <Widget>[
                      const Icon(
                        Icons.card_giftcard_rounded,
                        color: AppColors.accentTeal,
                        size: 22,
                      ),
                      const SizedBox(width: AppSpacing.sm),
                      Expanded(
                        child: Text(
                          s.t(
                            hi: 'वैकल्पिक: एक छोटा टेस्ट विज्ञापन देखकर बोनस रिवीजन टिप क्रेडिट पाएँ।',
                            en: 'Optional: Watch a short test ad to unlock a bonus revision tip credit.',
                          ),
                          style: AppTextStyles.cardSubtitle.copyWith(
                            color: AppColors.textSecondaryOf(context),
                          ),
                        ),
                      ),
                      const SizedBox(width: AppSpacing.xs),
                      TextButton(
                        onPressed: () async {
                          final RewardedAdResult res = await environment
                              .adManager
                              .showVoluntaryRewardedAd();
                          if (!context.mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(res.message)),
                          );
                        },
                        child: Text(s.t(hi: 'देखें', en: 'Watch')),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: AppSpacing.sm),
              ],
                            Row(
                children: <Widget>[
                  Expanded(
                    child: PremiumButton(
                      label: s.retryTest,
                      variant: PremiumButtonVariant.soft,
                      onPressed: () => _retryTest(context),
                    ),
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size(0, 46),
                        shape: RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(AppSpacing.radiusSm),
                        ),
                      ),
                      onPressed: () {
                        if (isHistoricalView) {
                          Navigator.of(context).pop();
                        } else {
                          environment.adManager.maybeShowPostTestInterstitial();
                          Navigator.of(context)
                              .popUntil((Route<dynamic> r) => r.isFirst);
                        }
                      },
                      child: Text(isHistoricalView ? s.back : s.backToTests),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MetricTile extends StatelessWidget {
  const _MetricTile({
    required this.label,
    required this.value,
    required this.color,
    required this.background,
    required this.border,
  });

  final String label;
  final String value;
  final Color color;
  final Color background;
  final Color border;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.sm,
        vertical: AppSpacing.md,
      ),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        border: Border.all(color: border, width: 1),
      ),
      child: Column(
        children: <Widget>[
          Text(
            value,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: AppTextStyles.cardSubtitle.copyWith(
              color: AppColors.textSecondaryOf(context),
            ),
          ),
        ],
      ),
    );
  }
}
