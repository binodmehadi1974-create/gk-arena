import 'package:flutter/material.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/settings/localization/app_strings.dart';
import 'package:gk_arena/features/settings/models/app_settings.dart';
import 'package:gk_arena/features/quiz/controllers/quiz_session_controller.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/features/quiz/services/quiz_environment.dart';
import 'package:gk_arena/features/quiz/ui/screens/quiz_result_screen.dart';
import 'package:gk_arena/features/quiz/ui/widgets/question_palette_sheet.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/navigation/smooth_page_route.dart';
import 'package:gk_arena/ui/widgets/premium_button.dart';

/// Professional active Quiz / Test screen with timer, palette, mark-for-review,
/// clear answer, bookmark toggle, auto-submit, persistent history recording,
/// and safe app-lifecycle pause/resume handling.
class QuizScreen extends StatefulWidget {
  const QuizScreen({
    super.key,
    required this.config,
    required this.questions,
    required this.environment,
  });

  final QuizConfig config;
  final List<Question> questions;
  final QuizEnvironment environment;

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> with WidgetsBindingObserver {
  late final QuizSessionController _controller;
  bool _navigatedToResult = false;
  Set<String> _bookmarkedIds = <String>{};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _controller = QuizSessionController(
      config: widget.config,
      questions: widget.questions,
      scoringService: widget.environment.scoringService,
      recentTracker: widget.environment.recentTracker,
      onSubmitted: _handleSubmitted,
    );
    widget.environment.adManager.setQuizActive(true);
    _controller.startTimer();
    _loadBookmarkState();
  }

  Future<void> _loadBookmarkState() async {
    await widget.environment.ensureInitialized();
    final Set<String> ids =
        await widget.environment.learningRepository.getBookmarkedQuestionIds();
    if (!mounted) return;
    setState(() {
      _bookmarkedIds = ids;
    });
  }

  Future<void> _toggleCurrentBookmark(Question question) async {
    await widget.environment.ensureInitialized();
    final bool nowBookmarked =
        await widget.environment.learningRepository.toggleBookmark(question);
    if (!mounted) return;
    setState(() {
      if (nowBookmarked) {
        _bookmarkedIds = <String>{..._bookmarkedIds, question.id};
      } else {
        _bookmarkedIds = <String>{..._bookmarkedIds}..remove(question.id);
      }
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        duration: const Duration(seconds: 1),
        content: Text(
          nowBookmarked
              ? 'प्रश्न बुकमार्क में सहेजा गया।'
              : 'प्रश्न बुकमार्क से हटाया गया।',
        ),
      ),
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      _controller.pauseTimer();
    } else if (state == AppLifecycleState.resumed) {
      _controller.resumeTimer();
    }
  }

  @override
  void dispose() {
    widget.environment.adManager.setQuizActive(false);
    WidgetsBinding.instance.removeObserver(this);
    _controller.dispose();
    super.dispose();
  }

  Future<void> _handleSubmitted(QuizResult result) async {
    if (_navigatedToResult) return;
    _navigatedToResult = true;

    try {
      await widget.environment.ensureInitialized();
      await widget.environment.learningRepository.recordCompletedTest(result);
    } catch (_) {
      // Never block displaying the test result if local persistence encounters an error.
    }

    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      SmoothPageRoute<void>(
        builder: (_) => QuizResultScreen(
          result: result,
          environment: widget.environment,
        ),
      ),
    );
  }

  String _formatTime(int totalSeconds) {
    final int mins = totalSeconds ~/ 60;
    final int secs = totalSeconds % 60;
    return '${mins.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
  }

  Future<void> _confirmManualSubmit() async {
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Submit Test?'),
          content: Text(
            'Answered: ${_controller.answeredCount} / ${_controller.totalQuestions}\n'
            'Unanswered: ${_controller.unansweredCount}\n'
            'Marked for Review: ${_controller.markedCount}\n\n'
            'क्या आप यह टेस्ट सबमिट करना चाहते हैं?',
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Submit Test'),
            ),
          ],
        );
      },
    );
    if (confirmed == true) {
      _controller.submit(autoSubmitted: false);
    }
  }

  Future<bool> _confirmExit() async {
    if (_controller.isSubmitted) return true;
    final bool? shouldLeave = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Leave Test?'),
          content: const Text(
            'टेस्ट अभी पूरा नहीं हुआ है। क्या आप वास्तव में बाहर जाना चाहते हैं?',
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Stay'),
            ),
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Exit'),
            ),
          ],
        );
      },
    );
    return shouldLeave ?? false;
  }

  void _openPalette() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.surfaceOf(context),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(AppSpacing.radiusXl),
        ),
      ),
      builder: (_) => QuestionPaletteSheet(
        states: _controller.states,
        currentIndex: _controller.currentIndex,
        onSelectIndex: _controller.jumpToQuestion,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (bool didPop, Object? _) async {
        if (didPop) return;
        final bool leave = await _confirmExit();
        if (leave && context.mounted) {
          Navigator.of(context).pop();
        }
      },
      child: AnimatedBuilder(
        animation: _controller,
        builder: (BuildContext context, _) {
          final QuizQuestionState state = _controller.currentState;
          final Question question = state.question;
          final QuestionLanguage displayLang =
              AppLanguageScope.languageOf(context) == AppLanguage.english
                  ? QuestionLanguage.english
                  : QuestionLanguage.hindi;
          final List<String> displayOptions = question.displayOptions(displayLang);
          final bool isBookmarked = _bookmarkedIds.contains(question.id);
          final bool lowTime =
              _controller.isTimed && _controller.remainingSeconds <= 60;

          return Scaffold(
            appBar: AppBar(
              title: Text(
                'Q ${_controller.currentIndex + 1} / ${_controller.totalQuestions}',
                style: AppTextStyles.sectionTitle,
              ),
              actions: <Widget>[
                if (_controller.isTimed)
                  Container(
                    margin: const EdgeInsets.symmetric(vertical: 10),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: lowTime
                          ? AppColors.softAmberSurface
                          : AppColors.softBlueSurface,
                      borderRadius: BorderRadius.circular(AppSpacing.radiusPill),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Icon(
                          Icons.timer_outlined,
                          size: 15,
                          color: lowTime ? AppColors.warning : AppColors.primary,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          _formatTime(_controller.remainingSeconds),
                          style: AppTextStyles.chipLabel.copyWith(
                            color: lowTime
                                ? AppColors.warning
                                : AppColors.deepNavy,
                          ),
                        ),
                      ],
                    ),
                  ),
                IconButton(
                  tooltip: isBookmarked ? 'Remove Bookmark' : 'Bookmark Question',
                  onPressed: () => _toggleCurrentBookmark(question),
                  icon: Icon(
                    isBookmarked
                        ? Icons.bookmark_rounded
                        : Icons.bookmark_border_rounded,
                    color:
                        isBookmarked ? AppColors.primary : AppColors.deepNavy,
                  ),
                ),
                IconButton(
                  tooltip: 'Question Palette',
                  onPressed: _openPalette,
                  icon: const Icon(Icons.grid_view_rounded),
                ),
                TextButton(
                  onPressed: _confirmManualSubmit,
                  child: const Text(
                    'Submit',
                    style: AppTextStyles.linkAction,
                  ),
                ),
              ],
            ),
            body: SafeArea(
              child: Column(
                children: <Widget>[
                  LinearProgressIndicator(
                    value: (_controller.currentIndex + 1) /
                        _controller.totalQuestions,
                    backgroundColor: AppColors.border,
                    valueColor: const AlwaysStoppedAnimation<Color>(
                      AppColors.primary,
                    ),
                    minHeight: 3,
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.fromLTRB(
                        20,
                        AppSpacing.md,
                        20,
                        AppSpacing.lg,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Wrap(
                            spacing: AppSpacing.xs,
                            runSpacing: AppSpacing.xs,
                            children: <Widget>[
                              _MetaPill(label: question.subject.titleEn),
                              _MetaPill(label: question.difficulty.labelEn),
                              if (state.isMarkedForReview)
                                const _MetaPill(
                                  label: 'Marked for Review',
                                  background: AppColors.softAmberSurface,
                                  textColor: AppColors.warning,
                                ),
                            ],
                          ),
                          const SizedBox(height: AppSpacing.md),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(AppSpacing.md),
                            decoration: BoxDecoration(
                              color: AppColors.surfaceOf(context),
                              borderRadius:
                                  BorderRadius.circular(AppSpacing.radiusLg),
                              border:
                                  Border.all(color: AppColors.borderOf(context), width: 1),
                              boxShadow: AppSpacing.softCardShadow,
                            ),
                            child: Text(
                              question.displayQuestionText(displayLang),
                              style: AppTextStyles.bodyPrimary.copyWith(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                height: 1.5,
                              ),
                            ),
                          ),
                          const SizedBox(height: AppSpacing.md),
                          ...List<Widget>.generate(
                            displayOptions.length,
                            (int index) {
                              final bool isSelected =
                                  state.selectedOptionIndex == index;
                              const List<String> labels = <String>[
                                'A',
                                'B',
                                'C',
                                'D',
                              ];
                              return Padding(
                                padding:
                                    const EdgeInsets.only(bottom: AppSpacing.sm),
                                child: _OptionTile(
                                  letter: labels[index],
                                  text: displayOptions[index],
                                  isSelected: isSelected,
                                  onTap: () => _controller.selectOption(index),
                                ),
                              );
                            },
                          ),
                          const SizedBox(height: AppSpacing.xs),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: _controller.toggleMarkForReview,
                                  icon: Icon(
                                    state.isMarkedForReview
                                        ? Icons.flag_rounded
                                        : Icons.outlined_flag_rounded,
                                    size: 18,
                                    color: state.isMarkedForReview
                                        ? AppColors.warning
                                        : AppColors.textSecondary,
                                  ),
                                  label: Text(
                                    state.isMarkedForReview
                                        ? 'Marked'
                                        : 'Mark Review',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                              const SizedBox(width: AppSpacing.sm),
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: state.isAnswered
                                      ? _controller.clearAnswer
                                      : null,
                                  icon: const Icon(
                                    Icons.backspace_outlined,
                                    size: 18,
                                  ),
                                  label: const Text(
                                    'Clear Answer',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.fromLTRB(
                      20,
                      AppSpacing.sm,
                      20,
                      AppSpacing.md,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.surfaceOf(context),
                      border: Border(
                        top: BorderSide(color: AppColors.border, width: 1),
                      ),
                    ),
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: PremiumButton(
                            label: 'Previous',
                            variant: PremiumButtonVariant.soft,
                            onPressed: _controller.isFirstQuestion
                                ? () {}
                                : _controller.previousQuestion,
                          ),
                        ),
                        const SizedBox(width: AppSpacing.sm),
                        Expanded(
                          child: PremiumButton(
                            label: _controller.isLastQuestion
                                ? 'Submit Test'
                                : 'Next',
                            variant: PremiumButtonVariant.primary,
                            trailingIcon: _controller.isLastQuestion
                                ? Icons.check_rounded
                                : Icons.arrow_forward_rounded,
                            onPressed: _controller.isLastQuestion
                                ? _confirmManualSubmit
                                : _controller.nextQuestion,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _MetaPill extends StatelessWidget {
  const _MetaPill({
    required this.label,
    this.background = AppColors.softBlueSurface,
    this.textColor = AppColors.primary,
  });

  final String label;
  final Color background;
  final Color textColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(AppSpacing.radiusPill),
      ),
      child: Text(
        label,
        style: AppTextStyles.badgeLabel.copyWith(color: textColor),
      ),
    );
  }
}

class _OptionTile extends StatelessWidget {
  const _OptionTile({
    required this.letter,
    required this.text,
    required this.isSelected,
    required this.onTap,
  });

  final String letter;
  final String text;
  final bool isSelected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: AppSpacing.motionFast,
      curve: Curves.easeOutCubic,
      decoration: BoxDecoration(
        color: isSelected ? AppColors.softBlueSurface : AppColors.surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        border: Border.all(
          color: isSelected ? AppColors.primary : AppColors.border,
          width: isSelected ? 1.6 : 1,
        ),
        boxShadow: AppSpacing.softCardShadow,
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.md),
            child: Row(
              children: <Widget>[
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color:
                        isSelected ? AppColors.primary : AppColors.background,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: isSelected ? AppColors.primary : AppColors.border,
                    ),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    letter,
                    style: AppTextStyles.chipLabel.copyWith(
                      color: isSelected
                          ? AppColors.textOnDark
                          : AppColors.textPrimary,
                    ),
                  ),
                ),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: Text(
                    text,
                    style: AppTextStyles.bodyPrimary.copyWith(
                      fontWeight:
                          isSelected ? FontWeight.w600 : FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
