import 'package:flutter/material.dart';
import 'package:gk_arena/features/learning/repositories/learning_repository.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/settings/localization/app_strings.dart';
import 'package:gk_arena/features/settings/models/app_settings.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/screens/explore/widgets/category_filter_bar.dart';
import 'package:gk_arena/ui/widgets/state_views.dart';

/// Post-submission Answer Review screen showing selected answer, correct answer,
/// question status, marks awarded, bookmark toggle, and full explanation.
class AnswerReviewScreen extends StatefulWidget {
  const AnswerReviewScreen({
    super.key,
    required this.result,
    this.learningRepository,
  });

  final QuizResult result;
  final LearningRepository? learningRepository;

  @override
  State<AnswerReviewScreen> createState() => _AnswerReviewScreenState();
}

class _AnswerReviewScreenState extends State<AnswerReviewScreen> {
  static const List<String> _filters = <String>[
    'All',
    'Correct',
    'Incorrect',
    'Unattempted',
    'Marked',
  ];

  String _selectedFilter = 'All';
  Set<String> _bookmarkedIds = <String>{};

  @override
  void initState() {
    super.initState();
    _loadBookmarks();
  }

  Future<void> _loadBookmarks() async {
    final LearningRepository? repo = widget.learningRepository;
    if (repo == null) return;
    final Set<String> ids = await repo.getBookmarkedQuestionIds();
    if (!mounted) return;
    setState(() {
      _bookmarkedIds = ids;
    });
  }

  Future<void> _toggleBookmark(Question question) async {
    final LearningRepository? repo = widget.learningRepository;
    if (repo == null) return;
    final bool nowBookmarked = await repo.toggleBookmark(question);
    if (!mounted) return;
    setState(() {
      if (nowBookmarked) {
        _bookmarkedIds = <String>{..._bookmarkedIds, question.id};
      } else {
        _bookmarkedIds = <String>{..._bookmarkedIds}..remove(question.id);
      }
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        duration: const Duration(seconds: 1),
        content: Text(
          nowBookmarked
              ? 'प्रश्न बुकमार्क में सहेजा गया।'
              : 'प्रश्न बुकमार्क से हटाया गया।',
        ),
      ),
    );
  }

  List<QuestionReviewItem> get _filteredItems {
    return widget.result.reviewItems.where((QuestionReviewItem item) {
      switch (_selectedFilter) {
        case 'Correct':
          return item.outcome == AnswerOutcome.correct;
        case 'Incorrect':
          return item.outcome == AnswerOutcome.incorrect;
        case 'Unattempted':
          return item.outcome == AnswerOutcome.unattempted;
        case 'Marked':
          return item.isMarkedForReview;
        default:
          return true;
      }
    }).toList(growable: false);
  }

  @override
  Widget build(BuildContext context) {
    final List<QuestionReviewItem> items = _filteredItems;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Answer Review'),
      ),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Padding(
              padding:
                  const EdgeInsets.fromLTRB(20, AppSpacing.xs, 20, AppSpacing.sm),
              child: CategoryFilterBar(
                categories: _filters,
                selectedCategory: _selectedFilter,
                onSelected: (String value) {
                  setState(() => _selectedFilter = value);
                },
              ),
            ),
            Expanded(
              child: items.isEmpty
                  ? Padding(
                      padding: const EdgeInsets.all(20),
                      child: GkEmptyStateCard(
                        icon: Icons.filter_list_off_rounded,
                        title: 'इस श्रेणी में कोई प्रश्न नहीं है',
                        description:
                            'सभी प्रश्नों की व्याख्या देखने के लिए "All" फ़िल्टर चुनें।',
                        actionLabel: 'सभी देखें',
                        onActionTap: () {
                          setState(() => _selectedFilter = 'All');
                        },
                      ),
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(
                        20,
                        AppSpacing.xs,
                        20,
                        AppSpacing.lg,
                      ),
                      itemCount: items.length,
                      separatorBuilder: (_, __) =>
                          const SizedBox(height: AppSpacing.md),
                      itemBuilder: (BuildContext context, int i) {
                        final QuestionReviewItem item = items[i];
                        return _ReviewCard(
                          item: item,
                          isBookmarked:
                              _bookmarkedIds.contains(item.question.id),
                          onToggleBookmark: widget.learningRepository == null
                              ? null
                              : () => _toggleBookmark(item.question),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ReviewCard extends StatelessWidget {
  const _ReviewCard({
    required this.item,
    required this.isBookmarked,
    this.onToggleBookmark,
  });

  final QuestionReviewItem item;
  final bool isBookmarked;
  final VoidCallback? onToggleBookmark;

  @override
  Widget build(BuildContext context) {
    final Color statusColor;
    final Color statusBg;
    final String statusText;

    switch (item.outcome) {
      case AnswerOutcome.correct:
        statusColor = AppColors.success;
        statusBg = AppColors.softGreenSurface;
        statusText = 'Correct (+${item.marksAwarded})';
      case AnswerOutcome.incorrect:
        statusColor = const Color(0xFFD64545);
        statusBg = const Color(0xFFFDECEC);
        statusText = 'Incorrect (${item.marksAwarded})';
      case AnswerOutcome.unattempted:
        statusColor = AppColors.textSecondary;
        statusBg = AppColors.background;
        statusText = 'Unattempted (0)';
    }

    const List<String> labels = <String>['A', 'B', 'C', 'D'];
    final QuestionLanguage displayLang =
        AppLanguageScope.languageOf(context) == AppLanguage.english
            ? QuestionLanguage.english
            : QuestionLanguage.hindi;
    final List<String> displayOptions =
        item.question.displayOptions(displayLang);

    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: AppColors.surfaceOf(context),
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        border: Border.all(color: AppColors.borderOf(context), width: 1),
        boxShadow: AppSpacing.softCardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Text(
                'Q${item.index + 1}',
                style: AppTextStyles.cardTitle.copyWith(
                  color: AppColors.primary,
                ),
              ),
              const SizedBox(width: AppSpacing.xs),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                decoration: BoxDecoration(
                  color: statusBg,
                  borderRadius: BorderRadius.circular(AppSpacing.radiusPill),
                ),
                child: Text(
                  statusText,
                  style: AppTextStyles.badgeLabel.copyWith(color: statusColor),
                ),
              ),
              if (item.isMarkedForReview) ...<Widget>[
                const SizedBox(width: 6),
                const Icon(
                  Icons.flag_rounded,
                  size: 16,
                  color: AppColors.warning,
                ),
              ],
              const Spacer(),
              if (onToggleBookmark != null)
                IconButton(
                  tooltip: isBookmarked ? 'Remove Bookmark' : 'Bookmark',
                  visualDensity: VisualDensity.compact,
                  onPressed: onToggleBookmark,
                  icon: Icon(
                    isBookmarked
                        ? Icons.bookmark_rounded
                        : Icons.bookmark_border_rounded,
                    size: 20,
                    color:
                        isBookmarked ? AppColors.primary : AppColors.textSecondary,
                  ),
                ),
            ],
          ),
          const SizedBox(height: AppSpacing.sm),
          Text(
            item.question.displayQuestionText(displayLang),
            style: AppTextStyles.bodyPrimary.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
          ...List<Widget>.generate(displayOptions.length, (int idx) {
            final bool isCorrect = idx == item.question.correctOptionIndex;
            final bool isUserWrong =
                item.selectedOptionIndex == idx && !isCorrect;

            final Color bg = isCorrect
                ? AppColors.softGreenSurface
                : isUserWrong
                    ? const Color(0xFFFDECEC)
                    : AppColors.background;
            final Color borderColor = isCorrect
                ? AppColors.success
                : isUserWrong
                    ? const Color(0xFFD64545)
                    : AppColors.border;

            return Container(
              width: double.infinity,
              margin: const EdgeInsets.only(bottom: 6),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: bg,
                borderRadius: BorderRadius.circular(AppSpacing.radiusSm),
                border: Border.all(color: borderColor, width: 1),
              ),
              child: Row(
                children: <Widget>[
                  Text(
                    '${labels[idx]}. ',
                    style: AppTextStyles.chipLabel,
                  ),
                  Expanded(
                    child: Text(
                      displayOptions[idx],
                      style: AppTextStyles.bodyPrimary,
                    ),
                  ),
                  if (isCorrect)
                    const Icon(
                      Icons.check_circle_rounded,
                      size: 18,
                      color: AppColors.success,
                    )
                  else if (isUserWrong)
                    const Icon(
                      Icons.cancel_rounded,
                      size: 18,
                      color: Color(0xFFD64545),
                    ),
                ],
              ),
            );
          }),
          const SizedBox(height: AppSpacing.xs),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(AppSpacing.sm),
            decoration: BoxDecoration(
              color: AppColors.softBlueSurface,
              borderRadius: BorderRadius.circular(AppSpacing.radiusSm),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text(
                  'व्याख्या / Explanation',
                  style: AppTextStyles.badgeLabel,
                ),
                const SizedBox(height: 3),
                Text(
                  item.question.displayExplanation(displayLang),
                  style: AppTextStyles.body.copyWith(
                    color: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
