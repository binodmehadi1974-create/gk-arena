import 'package:flutter/material.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/features/quiz/services/quiz_environment.dart';
import 'package:gk_arena/features/quiz/services/quiz_question_loader.dart';
import 'package:gk_arena/features/quiz/ui/screens/quiz_screen.dart';
import 'package:gk_arena/features/settings/localization/app_strings.dart';
import 'package:gk_arena/features/settings/models/app_settings.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/navigation/smooth_page_route.dart';
import 'package:gk_arena/ui/widgets/premium_button.dart';
import 'package:gk_arena/ui/widgets/state_views.dart';

/// Test Configuration screen allowing selection of subject(s), topic, count,
/// difficulty, question language, duration, negative marking, and revision mode.
/// Initializes defaults from persisted StudyPreferences cleanly.
class TestConfigScreen extends StatefulWidget {
  const TestConfigScreen({
    super.key,
    required this.mode,
    required this.environment,
    this.initialSubject,
  });

  final TestMode mode;
  final QuizEnvironment environment;
  final QuestionSubject? initialSubject;

  @override
  State<TestConfigScreen> createState() => _TestConfigScreenState();
}

class _TestConfigScreenState extends State<TestConfigScreen> {
  static const List<int> _questionCountOptions = <int>[5, 10, 15, 20];
  static const List<int> _durationMinuteOptions = <int>[5, 10, 15, 20, 30];

  late Set<QuestionSubject> _selectedSubjects;
  String? _selectedTopic;
  List<String> _availableTopics = <String>[];
  late int _questionCount;
  QuestionDifficulty? _selectedDifficulty;
  QuestionLanguage? _selectedLanguage;
  late bool _isTimed;
  late int _durationMinutes;
  ScoringRules _scoringRules = ScoringRules.noNegative;
  bool _allowRepeatRecent = false;
  bool _loading = true;
  QuizLoadResult? _previewResult;

  bool get _isSingleSubjectMode =>
      widget.mode == TestMode.subjectWise || widget.mode == TestMode.topicWise;

  @override
  void initState() {
    super.initState();
    final StudyPreferences studyPrefs =
        widget.environment.settingsController.studyPreferences;

    _selectedSubjects = <QuestionSubject>{
      if (widget.initialSubject != null)
        widget.initialSubject!
      else if (_isSingleSubjectMode)
        QuestionSubject.history,
    };
    _questionCount = widget.mode.defaultQuestionCount;
    _selectedDifficulty = studyPrefs.preferredDifficulty;
    _selectedLanguage = studyPrefs.defaultQuestionLanguage;
    _isTimed = widget.mode.isTimedByDefault;
    _durationMinutes = studyPrefs.preferredTestDurationMinutes > 0
        ? studyPrefs.preferredTestDurationMinutes
        : (widget.mode.defaultDurationMinutes > 0
            ? widget.mode.defaultDurationMinutes
            : 10);
    _refreshAvailability();
  }

  QuizConfig _buildConfig({int? overrideCount}) {
    return QuizConfig(
      mode: widget.mode,
      subjects: _selectedSubjects.toList(growable: false),
      topic: widget.mode == TestMode.topicWise ? _selectedTopic : null,
      questionCount: overrideCount ?? _questionCount,
      difficulty: _selectedDifficulty,
      language: _selectedLanguage,
      durationSeconds: _isTimed ? _durationMinutes * 60 : null,
      scoringRules: _scoringRules,
      allowRepeatRecent: _allowRepeatRecent,
    );
  }

  Future<void> _refreshAvailability() async {
    setState(() => _loading = true);
    await widget.environment.ensureInitialized();

    if (widget.mode == TestMode.topicWise) {
      final QuestionSubject? activeSubject =
          _selectedSubjects.isNotEmpty ? _selectedSubjects.first : null;
      final List<String> topics =
          await widget.environment.questionLoader.getAvailableTopics(
        subject: activeSubject,
        language: _selectedLanguage,
      );
      if (!topics.contains(_selectedTopic)) {
        _selectedTopic = topics.isNotEmpty ? topics.first : null;
      }
      _availableTopics = topics;
    }

    final QuizLoadResult result =
        await widget.environment.questionLoader.loadForConfig(_buildConfig());
    if (!mounted) return;
    setState(() {
      _previewResult = result;
      _loading = false;
    });
  }

  void _startQuiz({bool useAvailablePartial = false}) {
    final QuizLoadResult? preview = _previewResult;
    if (preview == null || preview.questions.isEmpty) return;

    final int actualCount =
        useAvailablePartial ? preview.questions.length : _questionCount;
    final QuizConfig finalConfig = _buildConfig(overrideCount: actualCount);

    Navigator.of(context).push(
      SmoothPageRoute<void>(
        builder: (_) => QuizScreen(
          config: finalConfig,
          questions: preview.questions,
          environment: widget.environment,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final AppStrings s = AppLanguageScope.of(context);
    final QuizLoadResult? preview = _previewResult;
    final Color textPrimary = AppColors.textPrimaryOf(context);
    final Color textSecondary = AppColors.textSecondaryOf(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(s.isHindi ? widget.mode.titleHi : widget.mode.titleEn),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(
            20,
            AppSpacing.sm,
            20,
            AppSpacing.lg,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                s.isHindi ? widget.mode.titleHi : widget.mode.titleEn,
                style: AppTextStyles.sectionTitle.copyWith(color: textPrimary),
              ),
              const SizedBox(height: 4),
              Text(
                widget.mode.description,
                style: AppTextStyles.body.copyWith(color: textSecondary),
              ),
              const SizedBox(height: AppSpacing.lg),

              // Subject Selector
              Text(
                s.t(hi: 'विषय चुनें', en: 'Select Subject'),
                style: AppTextStyles.cardTitle.copyWith(color: textPrimary),
              ),
              const SizedBox(height: AppSpacing.xs),
              Wrap(
                spacing: AppSpacing.xs,
                runSpacing: AppSpacing.xs,
                children: <Widget>[
                  if (!_isSingleSubjectMode)
                    _SelectChip(
                      label: s.t(hi: 'सभी विषय', en: 'All Subjects'),
                      selected: _selectedSubjects.isEmpty,
                      onTap: () {
                        _selectedSubjects.clear();
                        _refreshAvailability();
                      },
                    ),
                  for (final QuestionSubject subject in QuestionSubject.values)
                    _SelectChip(
                      label: s.isHindi ? subject.titleHi : subject.titleEn,
                      selected: _selectedSubjects.contains(subject),
                      onTap: () {
                        if (_isSingleSubjectMode) {
                          _selectedSubjects = <QuestionSubject>{subject};
                        } else if (_selectedSubjects.contains(subject)) {
                          _selectedSubjects.remove(subject);
                        } else {
                          _selectedSubjects.add(subject);
                        }
                        _refreshAvailability();
                      },
                    ),
                ],
              ),

              // Topic Selector (Topic-wise mode)
              if (widget.mode == TestMode.topicWise) ...<Widget>[
                const SizedBox(height: AppSpacing.md),
                Text(
                  s.t(hi: 'अध्याय चुनें', en: 'Topic'),
                  style: AppTextStyles.cardTitle.copyWith(color: textPrimary),
                ),
                const SizedBox(height: AppSpacing.xs),
                if (_availableTopics.isEmpty)
                  Text(
                    s.t(
                      hi: 'चयनित विषय और भाषा के लिए कोई अध्याय उपलब्ध नहीं है।',
                      en: 'No topics available for the selected subject and language.',
                    ),
                    style: AppTextStyles.cardSubtitle
                        .copyWith(color: textSecondary),
                  )
                else
                  Wrap(
                    spacing: AppSpacing.xs,
                    runSpacing: AppSpacing.xs,
                    children: _availableTopics.map((String topic) {
                      return _SelectChip(
                        label: topic,
                        selected: _selectedTopic == topic,
                        onTap: () {
                          _selectedTopic = topic;
                          _refreshAvailability();
                        },
                      );
                    }).toList(growable: false),
                  ),
              ],

              const SizedBox(height: AppSpacing.md),
              Text(
                s.t(hi: 'प्रश्नों की भाषा', en: 'Question Language'),
                style: AppTextStyles.cardTitle.copyWith(color: textPrimary),
              ),
              const SizedBox(height: AppSpacing.xs),
              Wrap(
                spacing: AppSpacing.xs,
                runSpacing: AppSpacing.xs,
                children: <Widget>[
                  _SelectChip(
                    label: s.t(hi: 'दोनों (हिन्दी + EN)', en: 'Both (HI + EN)'),
                    selected: _selectedLanguage == null,
                    onTap: () {
                      _selectedLanguage = null;
                      _refreshAvailability();
                    },
                  ),
                  _SelectChip(
                    label: 'हिन्दी',
                    selected: _selectedLanguage == QuestionLanguage.hindi,
                    onTap: () {
                      _selectedLanguage = QuestionLanguage.hindi;
                      _refreshAvailability();
                    },
                  ),
                  _SelectChip(
                    label: 'English',
                    selected: _selectedLanguage == QuestionLanguage.english,
                    onTap: () {
                      _selectedLanguage = QuestionLanguage.english;
                      _refreshAvailability();
                    },
                  ),
                ],
              ),

              const SizedBox(height: AppSpacing.md),
              Text(
                s.t(hi: 'कठिनाई स्तर', en: 'Difficulty'),
                style: AppTextStyles.cardTitle.copyWith(color: textPrimary),
              ),
              const SizedBox(height: AppSpacing.xs),
              Wrap(
                spacing: AppSpacing.xs,
                runSpacing: AppSpacing.xs,
                children: <Widget>[
                  _SelectChip(
                    label: s.all,
                    selected: _selectedDifficulty == null,
                    onTap: () {
                      _selectedDifficulty = null;
                      _refreshAvailability();
                    },
                  ),
                  for (final QuestionDifficulty diff
                      in QuestionDifficulty.values)
                    _SelectChip(
                      label: s.isHindi ? diff.labelHi : diff.labelEn,
                      selected: _selectedDifficulty == diff,
                      onTap: () {
                        _selectedDifficulty = diff;
                        _refreshAvailability();
                      },
                    ),
                ],
              ),

              const SizedBox(height: AppSpacing.md),
              Text(
                s.t(hi: 'प्रश्नों की संख्या', en: 'Number of Questions'),
                style: AppTextStyles.cardTitle.copyWith(color: textPrimary),
              ),
              const SizedBox(height: AppSpacing.xs),
              Wrap(
                spacing: AppSpacing.xs,
                runSpacing: AppSpacing.xs,
                children: _questionCountOptions.map((int count) {
                  return _SelectChip(
                    label: '$count Qs',
                    selected: _questionCount == count,
                    onTap: () {
                      _questionCount = count;
                      _refreshAvailability();
                    },
                  );
                }).toList(growable: false),
              ),

              const SizedBox(height: AppSpacing.md),
              Text(
                s.t(hi: 'अंक योजना', en: 'Scoring Rules'),
                style: AppTextStyles.cardTitle.copyWith(color: textPrimary),
              ),
              const SizedBox(height: AppSpacing.xs),
              Wrap(
                spacing: AppSpacing.xs,
                runSpacing: AppSpacing.xs,
                children: ScoringRules.presets.map((ScoringRules rule) {
                  return _SelectChip(
                    label: rule.label,
                    selected: _scoringRules.label == rule.label,
                    onTap: () {
                      setState(() => _scoringRules = rule);
                    },
                  );
                }).toList(growable: false),
              ),

              if (widget.mode != TestMode.practice) ...<Widget>[
                const SizedBox(height: AppSpacing.md),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: Text(
                        s.t(hi: 'समय सीमा (Timed Mode)', en: 'Timed Mode'),
                        style: AppTextStyles.cardTitle
                            .copyWith(color: textPrimary),
                      ),
                    ),
                    Switch(
                      value: _isTimed,
                      onChanged: (bool value) {
                        _isTimed = value;
                        _refreshAvailability();
                      },
                    ),
                  ],
                ),
                if (_isTimed) ...<Widget>[
                  const SizedBox(height: AppSpacing.xs),
                  Wrap(
                    spacing: AppSpacing.xs,
                    runSpacing: AppSpacing.xs,
                    children: _durationMinuteOptions.map((int mins) {
                      return _SelectChip(
                        label: '$mins min',
                        selected: _durationMinutes == mins,
                        onTap: () {
                          setState(() => _durationMinutes = mins);
                        },
                      );
                    }).toList(growable: false),
                  ),
                ],
              ],

              const SizedBox(height: AppSpacing.sm),
              Row(
                children: <Widget>[
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          s.t(
                            hi: 'रिवीजन मोड (हाल के प्रश्न शामिल करें)',
                            en: 'Revision Mode (Allow Recent)',
                          ),
                          style: AppTextStyles.cardTitle
                              .copyWith(color: textPrimary),
                        ),
                        Text(
                          s.t(
                            hi: 'हाल के हल किए गए प्रश्नों को दोहराने की अनुमति दें।',
                            en: 'Allow recently attempted questions to appear again.',
                          ),
                          style: AppTextStyles.cardSubtitle
                              .copyWith(color: textSecondary),
                        ),
                      ],
                    ),
                  ),
                  Switch(
                    value: _allowRepeatRecent,
                    onChanged: (bool value) {
                      _allowRepeatRecent = value;
                      _refreshAvailability();
                    },
                  ),
                ],
              ),

              const SizedBox(height: AppSpacing.lg),

              if (_loading)
                const GkLoadingPlaceholderCard(lineCount: 2)
              else if (preview == null || preview.questions.isEmpty)
                GkEmptyStateCard(
                  icon: Icons.quiz_outlined,
                  badgeText: s.t(
                    hi: 'कोई प्रश्न नहीं मिला',
                    en: 'No Questions Matched',
                  ),
                  title: s.t(
                    hi: 'उपलब्ध प्रश्न नहीं मिले',
                    en: 'No Available Questions Found',
                  ),
                  description: preview?.message ??
                      s.t(
                        hi: 'कृपया विषय, भाषा या कठिनाई स्तर बदलकर पुनः प्रयास करें।',
                        en: 'Try changing the subject, language, or difficulty filter.',
                      ),
                )
              else ...<Widget>[
                if (preview.status ==
                    QuizLoadStatus.insufficientQuestions) ...<Widget>[
                  GkStageNoticeBanner(
                    icon: Icons.warning_amber_rounded,
                    message: preview.message ??
                        s.t(
                          hi: 'उपलब्ध प्रश्न चयनित संख्या से कम हैं। आप उपलब्ध ${preview.availableCount} प्रश्नों के साथ टेस्ट शुरू कर सकते हैं।',
                          en: 'Fewer questions are available than requested. You can start with ${preview.availableCount} available questions.',
                        ),
                  ),
                  const SizedBox(height: AppSpacing.md),
                ],
                PremiumButton(
                  key: const Key('start_configured_test_button'),
                  label: preview.canStartPartial
                      ? s.t(
                          hi: 'उपलब्ध ${preview.questions.length} प्रश्नों के साथ शुरू करें',
                          en: 'Start with ${preview.questions.length} Available Questions',
                        )
                      : s.t(
                          hi: 'टेस्ट शुरू करें (${preview.questions.length} प्रश्न)',
                          en: 'Start Test (${preview.questions.length} Questions)',
                        ),
                  variant: PremiumButtonVariant.primary,
                  trailingIcon: Icons.play_arrow_rounded,
                  fullWidth: true,
                  onPressed: () =>
                      _startQuiz(useAvailablePartial: preview.canStartPartial),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _SelectChip extends StatelessWidget {
  const _SelectChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final Color surface = AppColors.surfaceOf(context);
    final Color border = AppColors.borderOf(context);
    final Color textPrimary = AppColors.textPrimaryOf(context);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppSpacing.radiusPill),
        child: AnimatedContainer(
          duration: AppSpacing.motionFast,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            color: selected ? AppColors.primary : surface,
            borderRadius: BorderRadius.circular(AppSpacing.radiusPill),
            border: Border.all(
              color: selected ? AppColors.primary : border,
              width: 1,
            ),
          ),
          child: Text(
            label,
            style: AppTextStyles.chipLabel.copyWith(
              color: selected ? AppColors.textOnDark : textPrimary,
            ),
          ),
        ),
      ),
    );
  }
}
