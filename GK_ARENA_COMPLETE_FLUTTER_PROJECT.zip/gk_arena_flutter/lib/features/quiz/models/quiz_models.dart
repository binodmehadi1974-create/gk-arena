import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';

/// All supported GK ARENA test modes.
enum TestMode {
  subjectWise(
    id: 'subject_wise',
    titleEn: 'Subject-wise Test',
    titleHi: 'विषय के अनुसार टेस्ट',
    description: 'किसी एक चयनित विषय पर केंद्रित अभ्यास करें।',
    isTimedByDefault: false,
    defaultDurationMinutes: 15,
    defaultQuestionCount: 10,
  ),
  topicWise(
    id: 'topic_wise',
    titleEn: 'Topic-wise Test',
    titleHi: 'अध्याय के अनुसार टेस्ट',
    description: 'चयनित विषय के विशिष्ट अध्याय पर सटीक अभ्यास।',
    isTimedByDefault: false,
    defaultDurationMinutes: 10,
    defaultQuestionCount: 10,
  ),
  mixedGk(
    id: 'mixed_gk',
    titleEn: 'Mixed GK Test',
    titleHi: 'सभी विषयों का मिश्रित टेस्ट',
    description: 'विभिन्न विषयों के मिश्रित प्रश्नों का समग्र अभ्यास।',
    isTimedByDefault: true,
    defaultDurationMinutes: 15,
    defaultQuestionCount: 15,
  ),
  practice(
    id: 'practice',
    titleEn: 'Practice Test',
    titleHi: 'अपनी गति से अभ्यास',
    description: 'बिना किसी समय दबाव के अपनी गति से सीखें।',
    isTimedByDefault: false,
    defaultDurationMinutes: 0,
    defaultQuestionCount: 10,
  ),
  timed(
    id: 'timed',
    titleEn: 'Timed Test',
    titleHi: 'समय सीमा वाला अभ्यास',
    description: 'गति और सटीकता बढ़ाने के लिए निश्चित समय का टेस्ट।',
    isTimedByDefault: true,
    defaultDurationMinutes: 10,
    defaultQuestionCount: 10,
  ),
  fullMock(
    id: 'full_mock',
    titleEn: 'Full Mock Test',
    titleHi: 'पूर्ण मॉक टेस्ट',
    description: 'एक वास्तविक परीक्षा जैसा अभ्यास अनुभव।',
    isTimedByDefault: true,
    defaultDurationMinutes: 20,
    defaultQuestionCount: 20,
  ),
  dailyChallenge(
    id: 'daily_challenge',
    titleEn: 'Daily Challenge',
    titleHi: 'आज का ज्ञान चैलेंज',
    description: 'हर दिन कुछ नया सीखने के लिए दैनिक चैलेंज।',
    isTimedByDefault: true,
    defaultDurationMinutes: 10,
    defaultQuestionCount: 10,
  ),
  previousYear(
    id: 'previous_year',
    titleEn: 'Previous Year Questions',
    titleHi: 'पिछले वर्षों के प्रश्न',
    description: 'परीक्षा पैटर्न पर आधारित प्रश्नों का अभ्यास।',
    isTimedByDefault: false,
    defaultDurationMinutes: 15,
    defaultQuestionCount: 10,
  );

  const TestMode({
    required this.id,
    required this.titleEn,
    required this.titleHi,
    required this.description,
    required this.isTimedByDefault,
    required this.defaultDurationMinutes,
    required this.defaultQuestionCount,
  });

  final String id;
  final String titleEn;
  final String titleHi;
  final String description;
  final bool isTimedByDefault;
  final int defaultDurationMinutes;
  final int defaultQuestionCount;
}

/// Configurable marking scheme attached to each test configuration.
class ScoringRules {
  const ScoringRules({
    this.marksPerCorrect = 1.0,
    this.negativeMarkingPerWrong = 0.0,
    this.marksPerUnattempted = 0.0,
    this.label = 'Standard (+1 / 0)',
  });

  final double marksPerCorrect;
  final double negativeMarkingPerWrong;
  final double marksPerUnattempted;
  final String label;

  static const ScoringRules noNegative = ScoringRules(
    marksPerCorrect: 1.0,
    negativeMarkingPerWrong: 0.0,
    label: 'No Negative (+1 / 0)',
  );

  static const ScoringRules negativeQuarter = ScoringRules(
    marksPerCorrect: 1.0,
    negativeMarkingPerWrong: 0.25,
    label: 'Negative 1/4 (+1 / -0.25)',
  );

  static const ScoringRules negativeOneThird = ScoringRules(
    marksPerCorrect: 1.0,
    negativeMarkingPerWrong: 0.33,
    label: 'Negative 1/3 (+1 / -0.33)',
  );

  static const List<ScoringRules> presets = <ScoringRules>[
    noNegative,
    negativeQuarter,
    negativeOneThird,
  ];
}

/// Complete configuration chosen before starting a quiz session.
class QuizConfig {
  const QuizConfig({
    required this.mode,
    this.subjects = const <QuestionSubject>[],
    this.topic,
    required this.questionCount,
    this.difficulty,
    this.language,
    this.durationSeconds,
    this.scoringRules = ScoringRules.noNegative,
    this.allowRepeatRecent = false,
  });

  final TestMode mode;
  final List<QuestionSubject> subjects;
  final String? topic;
  final int questionCount;
  final QuestionDifficulty? difficulty;
  final QuestionLanguage? language;
  final int? durationSeconds;
  final ScoringRules scoringRules;
  final bool allowRepeatRecent;

  bool get isTimed => durationSeconds != null && durationSeconds! > 0;

  QuizConfig copyWith({
    TestMode? mode,
    List<QuestionSubject>? subjects,
    String? topic,
    bool clearTopic = false,
    int? questionCount,
    QuestionDifficulty? difficulty,
    bool clearDifficulty = false,
    QuestionLanguage? language,
    bool clearLanguage = false,
    int? durationSeconds,
    bool clearDuration = false,
    ScoringRules? scoringRules,
    bool? allowRepeatRecent,
  }) {
    return QuizConfig(
      mode: mode ?? this.mode,
      subjects: subjects ?? this.subjects,
      topic: clearTopic ? null : (topic ?? this.topic),
      questionCount: questionCount ?? this.questionCount,
      difficulty: clearDifficulty ? null : (difficulty ?? this.difficulty),
      language: clearLanguage ? null : (language ?? this.language),
      durationSeconds:
          clearDuration ? null : (durationSeconds ?? this.durationSeconds),
      scoringRules: scoringRules ?? this.scoringRules,
      allowRepeatRecent: allowRepeatRecent ?? this.allowRepeatRecent,
    );
  }
}

enum QuestionPaletteStatus {
  unanswered,
  answered,
  markedForReview,
  answeredAndMarked,
}

class QuizQuestionState {
  const QuizQuestionState({
    required this.question,
    this.selectedOptionIndex,
    this.isMarkedForReview = false,
  });

  final Question question;
  final int? selectedOptionIndex;
  final bool isMarkedForReview;

  bool get isAnswered => selectedOptionIndex != null;

  QuestionPaletteStatus get paletteStatus {
    if (isAnswered && isMarkedForReview) {
      return QuestionPaletteStatus.answeredAndMarked;
    }
    if (isAnswered) return QuestionPaletteStatus.answered;
    if (isMarkedForReview) return QuestionPaletteStatus.markedForReview;
    return QuestionPaletteStatus.unanswered;
  }

  QuizQuestionState copyWith({
    int? selectedOptionIndex,
    bool clearSelection = false,
    bool? isMarkedForReview,
  }) {
    return QuizQuestionState(
      question: question,
      selectedOptionIndex: clearSelection
          ? null
          : (selectedOptionIndex ?? this.selectedOptionIndex),
      isMarkedForReview: isMarkedForReview ?? this.isMarkedForReview,
    );
  }
}

/// Serializable state snapshot enabling safe restoration after app interruption.
class QuizSessionSnapshot {
  const QuizSessionSnapshot({
    required this.currentIndex,
    required this.selectedOptionsByIndex,
    required this.markedIndices,
    required this.remainingSeconds,
    required this.elapsedSeconds,
    required this.isSubmitted,
  });

  final int currentIndex;
  final Map<int, int> selectedOptionsByIndex;
  final List<int> markedIndices;
  final int remainingSeconds;
  final int elapsedSeconds;
  final bool isSubmitted;

  Map<String, Object?> toJson() {
    return <String, Object?>{
      'current_index': currentIndex,
      'selected_options': selectedOptionsByIndex.map(
        (int key, int value) => MapEntry<String, int>(key.toString(), value),
      ),
      'marked_indices': markedIndices,
      'remaining_seconds': remainingSeconds,
      'elapsed_seconds': elapsedSeconds,
      'is_submitted': isSubmitted,
    };
  }

  factory QuizSessionSnapshot.fromJson(Map<String, Object?> json) {
    final Map<String, dynamic> rawSelected =
        (json['selected_options'] as Map<String, dynamic>?) ??
            <String, dynamic>{};
    final Map<int, int> selected = <int, int>{};
    for (final MapEntry<String, dynamic> entry in rawSelected.entries) {
      final int? key = int.tryParse(entry.key);
      if (key != null && entry.value is int) {
        selected[key] = entry.value as int;
      }
    }

    final List<dynamic> rawMarked =
        (json['marked_indices'] as List<dynamic>?) ?? <dynamic>[];
    return QuizSessionSnapshot(
      currentIndex: (json['current_index'] as int?) ?? 0,
      selectedOptionsByIndex: selected,
      markedIndices: rawMarked.whereType<int>().toList(growable: false),
      remainingSeconds: (json['remaining_seconds'] as int?) ?? 0,
      elapsedSeconds: (json['elapsed_seconds'] as int?) ?? 0,
      isSubmitted: (json['is_submitted'] as bool?) ?? false,
    );
  }
}

enum AnswerOutcome {
  correct,
  incorrect,
  unattempted,
}

class QuestionReviewItem {
  const QuestionReviewItem({
    required this.index,
    required this.question,
    required this.selectedOptionIndex,
    required this.isMarkedForReview,
    required this.outcome,
    required this.marksAwarded,
  });

  final int index;
  final Question question;
  final int? selectedOptionIndex;
  final bool isMarkedForReview;
  final AnswerOutcome outcome;
  final double marksAwarded;
}

class QuizResult {
  const QuizResult({
    required this.config,
    required this.totalQuestions,
    required this.correctCount,
    required this.incorrectCount,
    required this.unattemptedCount,
    required this.totalScore,
    required this.maxScore,
    required this.accuracyPercent,
    required this.timeTakenSeconds,
    required this.wasAutoSubmitted,
    required this.performanceSummary,
    required this.reviewItems,
  });

  final QuizConfig config;
  final int totalQuestions;
  final int correctCount;
  final int incorrectCount;
  final int unattemptedCount;
  final double totalScore;
  final double maxScore;
  final double accuracyPercent;
  final int timeTakenSeconds;
  final bool wasAutoSubmitted;
  final String performanceSummary;
  final List<QuestionReviewItem> reviewItems;

  int get attemptedCount => correctCount + incorrectCount;
}
