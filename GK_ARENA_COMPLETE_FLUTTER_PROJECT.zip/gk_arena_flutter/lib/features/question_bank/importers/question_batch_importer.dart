import 'dart:convert';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';

/// Future-scale JSON & CSV batch importer ready for 100,000+ validated MCQs.
class QuestionBatchImporter {
  const QuestionBatchImporter({required this.repository});

  final QuestionRepository repository;

  /// Parses and imports either a JSON array of questions or a batch wrapper object
  /// containing a top-level "questions" array.
  Future<BatchImportReport> importFromJsonString(String jsonContent) async {
    final Object? decoded = jsonDecode(jsonContent);
    final List<dynamic> rawList;

    if (decoded is List<dynamic>) {
      rawList = decoded;
    } else if (decoded is Map<String, dynamic> && decoded['questions'] is List) {
      rawList = decoded['questions'] as List<dynamic>;
    } else {
      throw const FormatException(
        'Expected a JSON list of questions or an object with a "questions" key.',
      );
    }

    final List<Question> parsed = <Question>[];
    final List<String> parseErrors = <String>[];
    int parseFailures = 0;

    for (int i = 0; i < rawList.length; i++) {
      final dynamic item = rawList[i];
      if (item is! Map<String, dynamic>) {
        parseFailures++;
        parseErrors.add('Row $i: Expected JSON object.');
        continue;
      }
      try {
        parsed.add(Question.fromJson(item));
      } catch (e) {
        parseFailures++;
        parseErrors.add('Row $i: $e');
      }
    }

    final BatchImportReport report = await repository.saveBatch(parsed);
    return BatchImportReport(
      totalReceived: rawList.length,
      insertedCount: report.insertedCount,
      duplicateCount: report.duplicateCount,
      invalidCount: report.invalidCount + parseFailures,
      errors: List<String>.unmodifiable(<String>[
        ...parseErrors,
        ...report.errors,
      ]),
    );
  }

  /// Parses and imports CSV content with header row:
  /// id,question_text,option_a,option_b,option_c,option_d,correct_option_index,
  /// explanation,subject,topic,subtopic,difficulty,language,exam_category,
  /// question_type,source_reference,verification_status
  Future<BatchImportReport> importFromCsvString(String csvContent) async {
    final List<String> lines = const LineSplitter()
        .convert(csvContent)
        .where((String line) => line.trim().isNotEmpty)
        .toList(growable: false);

    if (lines.length <= 1) {
      return const BatchImportReport(
        totalReceived: 0,
        insertedCount: 0,
        duplicateCount: 0,
        invalidCount: 0,
        errors: <String>[],
      );
    }

    final List<Question> parsed = <Question>[];
    final List<String> parseErrors = <String>[];
    int parseFailures = 0;
    final DateTime now = DateTime.now().toUtc();

    for (int i = 1; i < lines.length; i++) {
      final List<String> cols = _parseCsvRow(lines[i]);
      if (cols.length < 17) {
        parseFailures++;
        parseErrors.add('CSV row ${i + 1}: Expected 17 columns, found ${cols.length}.');
        continue;
      }
      try {
        parsed.add(
          Question(
            id: cols[0].trim(),
            questionText: cols[1].trim(),
            options: <String>[
              cols[2].trim(),
              cols[3].trim(),
              cols[4].trim(),
              cols[5].trim(),
            ],
            correctOptionIndex: int.parse(cols[6].trim()),
            explanation: cols[7].trim(),
            subject: QuestionSubject.fromId(cols[8]),
            topic: cols[9].trim(),
            subtopic: cols[10].trim(),
            difficulty: QuestionDifficulty.fromCode(cols[11]),
            language: QuestionLanguage.fromCode(cols[12]),
            examCategory: ExamCategory.fromCode(cols[13]),
            questionType: QuestionType.fromCode(cols[14]),
            sourceReference: cols[15].trim(),
            verificationStatus: VerificationStatus.fromCode(cols[16]),
            createdAt: now,
            updatedAt: now,
            isSample: cols[16].trim().toLowerCase() == 'demo_unverified',
          ),
        );
      } catch (e) {
        parseFailures++;
        parseErrors.add('CSV row ${i + 1}: $e');
      }
    }

    final BatchImportReport report = await repository.saveBatch(parsed);
    return BatchImportReport(
      totalReceived: lines.length - 1,
      insertedCount: report.insertedCount,
      duplicateCount: report.duplicateCount,
      invalidCount: report.invalidCount + parseFailures,
      errors: List<String>.unmodifiable(<String>[
        ...parseErrors,
        ...report.errors,
      ]),
    );
  }

  List<String> _parseCsvRow(String line) {
    final List<String> fields = <String>[];
    final StringBuffer current = StringBuffer();
    bool inQuotes = false;

    for (int i = 0; i < line.length; i++) {
      final String ch = line[i];
      if (ch == '"') {
        if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
          current.write('"');
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (ch == ',' && !inQuotes) {
        fields.add(current.toString());
        current.clear();
      } else {
        current.write(ch);
      }
    }
    fields.add(current.toString());
    return fields;
  }
}
