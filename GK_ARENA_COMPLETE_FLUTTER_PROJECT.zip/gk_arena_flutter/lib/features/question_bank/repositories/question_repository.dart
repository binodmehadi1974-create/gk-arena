import 'package:gk_arena/features/question_bank/database/question_data_source.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/services/question_bank_cache.dart';
import 'package:gk_arena/features/question_bank/validation/question_validator.dart';

class QuestionSaveResult {
  const QuestionSaveResult({
    required this.saved,
    this.isDuplicate = false,
    this.errors = const <String>[],
  });

  final bool saved;
  final bool isDuplicate;
  final List<String> errors;
}

class BatchImportReport {
  const BatchImportReport({
    required this.totalReceived,
    required this.insertedCount,
    required this.duplicateCount,
    required this.invalidCount,
    required this.errors,
  });

  final int totalReceived;
  final int insertedCount;
  final int duplicateCount;
  final int invalidCount;
  final List<String> errors;
}

/// Separate repository/service layer abstracting Question Bank retrieval,
/// validation, duplicate detection, bounded metadata caching, and scalable
/// batch persistence for 100,000+ MCQs.
class QuestionRepository {
  QuestionRepository({
    required this.dataSource,
    this.validator = const QuestionValidator(),
  });

  final QuestionDataSource dataSource;
  final QuestionValidator validator;
  final BoundedMemoryCache<String, List<String>> _topicsCache =
      BoundedMemoryCache<String, List<String>>(maxEntries: 64);
  final BoundedMemoryCache<String, int> _countCache =
      BoundedMemoryCache<String, int>(maxEntries: 128);

  void _invalidateCaches() {
    _topicsCache.clear();
    _countCache.clear();
  }

  Future<void> initialize() => dataSource.initialize();

  Future<void> close() {
    _invalidateCaches();
    return dataSource.close();
  }

  QuestionValidationResult validateQuestion(Question question) =>
      validator.validate(question);

  Future<bool> isDuplicateQuestion(
    String questionText, {
    QuestionLanguage? language,
  }) async {
    final String normalized = QuestionTextNormalizer.normalize(questionText);
    if (normalized.isEmpty) return false;
    return dataSource.existsByNormalizedText(normalized, language: language);
  }

  Future<QuestionSaveResult> saveQuestion(Question question) async {
    final QuestionValidationResult validation = validator.validate(question);
    if (!validation.isValid) {
      return QuestionSaveResult(saved: false, errors: validation.errors);
    }

    final bool idExists = await dataSource.existsById(question.id);
    if (idExists) {
      return QuestionSaveResult(
        saved: false,
        isDuplicate: true,
        errors: <String>['Question ID "${question.id}" already exists.'],
      );
    }

    final String normalized =
        QuestionTextNormalizer.normalize(question.questionText);
    final bool textExists = await dataSource.existsByNormalizedText(
      normalized,
      language: question.language,
    );
    if (textExists) {
      return const QuestionSaveResult(
        saved: false,
        isDuplicate: true,
        errors: <String>['Duplicate question text already exists.'],
      );
    }

    await dataSource.insertQuestion(question, normalizedText: normalized);
    _invalidateCaches();
    return const QuestionSaveResult(saved: true);
  }

  Future<BatchImportReport> saveBatch(List<Question> questions) async {
    int duplicateCount = 0;
    int invalidCount = 0;
    final List<String> errors = <String>[];
    final Set<String> batchIds = <String>{};
    final Set<String> batchTextKeys = <String>{};
    final List<({Question question, String normalizedText})> validRecords =
        <({Question question, String normalizedText})>[];

    for (final Question q in questions) {
      final QuestionValidationResult validation = validator.validate(q);
      if (!validation.isValid) {
        invalidCount++;
        errors.add('${q.id}: ${validation.errors.join(' ')}');
        continue;
      }

      final String normalized = QuestionTextNormalizer.normalize(q.questionText);
      final String textKey = '${q.language.code}::$normalized';

      if (!batchIds.add(q.id) ||
          !batchTextKeys.add(textKey) ||
          await dataSource.existsById(q.id) ||
          await dataSource.existsByNormalizedText(
            normalized,
            language: q.language,
          )) {
        duplicateCount++;
        continue;
      }

      validRecords.add((question: q, normalizedText: normalized));
    }

    final int inserted = await dataSource.insertBatch(validRecords);
    if (inserted > 0) {
      _invalidateCaches();
    }
    return BatchImportReport(
      totalReceived: questions.length,
      insertedCount: inserted,
      duplicateCount: duplicateCount + (validRecords.length - inserted),
      invalidCount: invalidCount,
      errors: List<String>.unmodifiable(errors),
    );
  }

  Future<QuestionSaveResult> updateQuestion(Question question) async {
    final QuestionValidationResult validation = validator.validate(question);
    if (!validation.isValid) {
      return QuestionSaveResult(saved: false, errors: validation.errors);
    }
    final String normalized =
        QuestionTextNormalizer.normalize(question.questionText);
    try {
      await dataSource.updateQuestion(question, normalizedText: normalized);
      _invalidateCaches();
      return const QuestionSaveResult(saved: true);
    } catch (e) {
      return QuestionSaveResult(
        saved: false,
        errors: <String>[e.toString()],
      );
    }
  }

  Future<bool> deleteQuestion(String id) async {
    final bool deleted = await dataSource.deleteQuestion(id);
    if (deleted) _invalidateCaches();
    return deleted;
  }

  Future<int> deleteBatch(List<String> ids) async {
    final int deleted = await dataSource.deleteBatch(ids);
    if (deleted > 0) _invalidateCaches();
    return deleted;
  }

  Future<Question?> getById(String id) => dataSource.findById(id);

  /// Batched ID lookup eliminating N+1 queries for Bookmarks & Wrong Answers.
  Future<Map<String, Question>> getByIds(List<String> ids) =>
      dataSource.findByIds(ids);

  Future<List<String>> getDistinctTopics({
    QuestionSubject? subject,
    QuestionLanguage? language,
    PublicationStatus? publicationStatus,
  }) async {
    final String cacheKey =
        '${subject?.id ?? 'all'}|${language?.code ?? 'all'}|${publicationStatus?.code ?? 'all'}';
    final List<String>? cached = _topicsCache.get(cacheKey);
    if (cached != null) return cached;

    final List<String> topics = await dataSource.getDistinctTopics(
      subject: subject,
      language: language,
      publicationStatus: publicationStatus,
    );
    _topicsCache.put(cacheKey, topics);
    return topics;
  }

  Future<List<Question>> query(QuestionFilter filter) =>
      dataSource.query(filter);

  Future<List<Question>> getBySubject(
    QuestionSubject subject, {
    QuestionLanguage? language,
    QuestionDifficulty? difficulty,
    bool includeSamples = true,
    int? limit,
    int offset = 0,
  }) {
    return dataSource.query(
      QuestionFilter(
        subject: subject,
        language: language,
        difficulty: difficulty,
        includeSamples: includeSamples,
        limit: limit,
        offset: offset,
      ),
    );
  }

  Future<List<Question>> getByTopic(
    String topic, {
    QuestionSubject? subject,
    String? subtopic,
    QuestionLanguage? language,
    bool includeSamples = true,
    int? limit,
    int offset = 0,
  }) {
    return dataSource.query(
      QuestionFilter(
        subject: subject,
        topic: topic,
        subtopic: subtopic,
        language: language,
        includeSamples: includeSamples,
        limit: limit,
        offset: offset,
      ),
    );
  }

  Future<List<Question>> getByDifficulty(
    QuestionDifficulty difficulty, {
    QuestionSubject? subject,
    QuestionLanguage? language,
    bool includeSamples = true,
    int? limit,
    int offset = 0,
  }) {
    return dataSource.query(
      QuestionFilter(
        subject: subject,
        difficulty: difficulty,
        language: language,
        includeSamples: includeSamples,
        limit: limit,
        offset: offset,
      ),
    );
  }

  Future<List<Question>> getByLanguage(
    QuestionLanguage language, {
    QuestionSubject? subject,
    QuestionDifficulty? difficulty,
    bool includeSamples = true,
    int? limit,
    int offset = 0,
  }) {
    return dataSource.query(
      QuestionFilter(
        subject: subject,
        language: language,
        difficulty: difficulty,
        includeSamples: includeSamples,
        limit: limit,
        offset: offset,
      ),
    );
  }

  Future<List<Question>> getMixed({
    QuestionLanguage? language,
    QuestionDifficulty? difficulty,
    ExamCategory? examCategory,
    PublicationStatus? publicationStatus,
    bool includeSamples = true,
    int limit = 20,
  }) {
    return dataSource.queryMixed(
      language: language,
      difficulty: difficulty,
      examCategory: examCategory,
      publicationStatus: publicationStatus,
      includeSamples: includeSamples,
      limit: limit,
    );
  }

  Future<int> count({QuestionFilter filter = const QuestionFilter()}) async {
    final String key =
        '${filter.subject?.id}|${filter.topic}|${filter.subtopic}|'
        '${filter.difficulty?.code}|${filter.language?.code}|'
        '${filter.examCategory?.code}|${filter.questionType?.code}|'
        '${filter.verificationStatus?.code}|${filter.publicationStatus?.code}|'
        '${filter.searchQuery}|${filter.includeSamples}';
    final int? cached = _countCache.get(key);
    if (cached != null) return cached;

    final int result = await dataSource.count(filter);
    _countCache.put(key, result);
    return result;
  }
}
