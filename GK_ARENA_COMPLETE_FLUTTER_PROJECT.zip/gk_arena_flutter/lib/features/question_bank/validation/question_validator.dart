import 'package:gk_arena/features/question_bank/models/question_model.dart';

/// Normalizes question text consistently for duplicate detection across Hindi & English.
abstract final class QuestionTextNormalizer {
  static final RegExp _multiWhitespace = RegExp(r'\s+');
  static final RegExp _trailingPunctuation = RegExp(r'[?।.!,;:\-]+$');

  static String normalize(String text) {
    final String collapsed = text.trim().replaceAll(_multiWhitespace, ' ').toLowerCase();
    return collapsed.replaceAll(_trailingPunctuation, '').trim();
  }
}

class QuestionValidationResult {
  const QuestionValidationResult({
    required this.isValid,
    required this.errors,
  });

  final bool isValid;
  final List<String> errors;
}

/// Validates Question integrity before persistence or batch import.
class QuestionValidator {
  const QuestionValidator();

  static const int maxQuestionLength = 2000;
  static const int maxOptionLength = 500;
  static const int maxExplanationLength = 4000;

  QuestionValidationResult validate(Question question) {
    final List<String> errors = <String>[];

    if (question.id.trim().isEmpty) {
      errors.add('Question ID must not be empty.');
    }
    if (QuestionTextNormalizer.normalize(question.questionText).length < 5) {
      errors.add('Question text must contain at least 5 meaningful characters.');
    }
    if (question.options.length != 4) {
      errors.add('Question must have exactly 4 answer options.');
    } else {
      final Set<String> seenOptions = <String>{};
      for (int i = 0; i < question.options.length; i++) {
        final String normOpt = QuestionTextNormalizer.normalize(question.options[i]);
        if (normOpt.isEmpty) {
          errors.add('Option ${i + 1} must not be empty.');
        } else if (!seenOptions.add(normOpt)) {
          errors.add('Duplicate answer option detected at position ${i + 1}.');
        }
      }
    }
    if (question.correctOptionIndex < 0 || question.correctOptionIndex > 3) {
      errors.add('correctOptionIndex must be between 0 and 3.');
    }
    if (question.explanation.trim().isEmpty) {
      errors.add('Explanation must not be empty.');
    }
    if (question.topic.trim().isEmpty) {
      errors.add('Topic must not be empty.');
    }
    if (question.subtopic.trim().isEmpty) {
      errors.add('Subtopic must not be empty.');
    }
    if (question.questionText.length > maxQuestionLength) {
      errors.add('Question text exceeds maximum allowed length ($maxQuestionLength chars).');
    }
    if (question.explanation.length > maxExplanationLength) {
      errors.add('Explanation exceeds maximum allowed length ($maxExplanationLength chars).');
    }
    if (question.questionText.contains('\u0000') || question.explanation.contains('\u0000')) {
      errors.add('Question contains unsafe null-byte characters.');
    }
    for (int i = 0; i < question.options.length; i++) {
      if (question.options[i].length > maxOptionLength) {
        errors.add('Option ${i + 1} exceeds maximum allowed length ($maxOptionLength chars).');
      }
    }
    if (question.updatedAt.isBefore(question.createdAt)) {
      errors.add('updatedAt cannot be earlier than createdAt.');
    }

    return QuestionValidationResult(
      isValid: errors.isEmpty,
      errors: List<String>.unmodifiable(errors),
    );
  }
}
