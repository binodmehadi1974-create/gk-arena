import 'dart:convert';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';

/// Scalable, immutable bilingual MCQ record model designed for 100,000+ to
/// millions of questions with safe translation fallbacks and flexible taxonomy.
class Question {
  const Question({
    required this.id,
    required this.questionText,
    required this.options,
    required this.correctOptionIndex,
    required this.explanation,
    required this.subject,
    this.chapter = '',
    required this.topic,
    required this.subtopic,
    required this.difficulty,
    required this.language,
    required this.examCategory,
    required this.questionType,
    required this.sourceReference,
    required this.verificationStatus,
    required this.createdAt,
    required this.updatedAt,
    this.isSample = false,
    this.publicationStatus = PublicationStatus.published,
    this.questionTextHi,
    this.questionTextEn,
    this.optionsHi,
    this.optionsEn,
    this.explanationHi,
    this.explanationEn,
    this.tags = const <String>[],
  });

  final String id;
  final String questionText;
  final List<String> options;
  final int correctOptionIndex;
  final String explanation;
  final QuestionSubject subject;
  final String chapter;
  final String topic;
  final String subtopic;
  final QuestionDifficulty difficulty;
  final QuestionLanguage language;
  final ExamCategory examCategory;
  final QuestionType questionType;
  final String sourceReference;
  final VerificationStatus verificationStatus;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isSample;
  final PublicationStatus publicationStatus;

  // Bilingual content fields (optional for backwards compatibility with single-language records)
  final String? questionTextHi;
  final String? questionTextEn;
  final List<String>? optionsHi;
  final List<String>? optionsEn;
  final String? explanationHi;
  final String? explanationEn;
  final List<String> tags;

  String get correctAnswer =>
      (correctOptionIndex >= 0 && correctOptionIndex < options.length)
          ? options[correctOptionIndex]
          : '';

  /// Returns question text in [preferred] language with safe fallback so broken
  /// or missing translations are never displayed.
  String displayQuestionText(QuestionLanguage preferred) {
    if (preferred == QuestionLanguage.hindi) {
      if (questionTextHi != null && questionTextHi!.trim().isNotEmpty) {
        return questionTextHi!.trim();
      }
      if (language == QuestionLanguage.hindi && questionText.trim().isNotEmpty) {
        return questionText.trim();
      }
      if (questionTextEn != null && questionTextEn!.trim().isNotEmpty) {
        return questionTextEn!.trim();
      }
      return questionText;
    } else {
      if (questionTextEn != null && questionTextEn!.trim().isNotEmpty) {
        return questionTextEn!.trim();
      }
      if (language == QuestionLanguage.english &&
          questionText.trim().isNotEmpty) {
        return questionText.trim();
      }
      if (questionTextHi != null && questionTextHi!.trim().isNotEmpty) {
        return questionTextHi!.trim();
      }
      return questionText;
    }
  }

  /// Returns 4 options in [preferred] language with safe fallback.
  List<String> displayOptions(QuestionLanguage preferred) {
    bool isComplete(List<String>? list) =>
        list != null &&
        list.length == 4 &&
        list.every((String o) => o.trim().isNotEmpty);

    if (preferred == QuestionLanguage.hindi) {
      if (isComplete(optionsHi)) return optionsHi!;
      if (language == QuestionLanguage.hindi && isComplete(options)) {
        return options;
      }
      if (isComplete(optionsEn)) return optionsEn!;
      return options;
    } else {
      if (isComplete(optionsEn)) return optionsEn!;
      if (language == QuestionLanguage.english && isComplete(options)) {
        return options;
      }
      if (isComplete(optionsHi)) return optionsHi!;
      return options;
    }
  }

  /// Returns explanation in [preferred] language with safe fallback.
  String displayExplanation(QuestionLanguage preferred) {
    if (preferred == QuestionLanguage.hindi) {
      if (explanationHi != null && explanationHi!.trim().isNotEmpty) {
        return explanationHi!.trim();
      }
      if (language == QuestionLanguage.hindi && explanation.trim().isNotEmpty) {
        return explanation.trim();
      }
      if (explanationEn != null && explanationEn!.trim().isNotEmpty) {
        return explanationEn!.trim();
      }
      return explanation;
    } else {
      if (explanationEn != null && explanationEn!.trim().isNotEmpty) {
        return explanationEn!.trim();
      }
      if (language == QuestionLanguage.english &&
          explanation.trim().isNotEmpty) {
        return explanation.trim();
      }
      if (explanationHi != null && explanationHi!.trim().isNotEmpty) {
        return explanationHi!.trim();
      }
      return explanation;
    }
  }

  bool hasTranslation(QuestionLanguage target) {
    if (target == QuestionLanguage.hindi) {
      return (questionTextHi != null && questionTextHi!.trim().isNotEmpty) ||
          language == QuestionLanguage.hindi;
    }
    return (questionTextEn != null && questionTextEn!.trim().isNotEmpty) ||
        language == QuestionLanguage.english;
  }

  Question copyWith({
    String? questionText,
    List<String>? options,
    int? correctOptionIndex,
    String? explanation,
    QuestionSubject? subject,
    String? chapter,
    String? topic,
    String? subtopic,
    QuestionDifficulty? difficulty,
    QuestionLanguage? language,
    ExamCategory? examCategory,
    QuestionType? questionType,
    String? sourceReference,
    VerificationStatus? verificationStatus,
    DateTime? updatedAt,
    bool? isSample,
    PublicationStatus? publicationStatus,
    String? questionTextHi,
    String? questionTextEn,
    List<String>? optionsHi,
    List<String>? optionsEn,
    String? explanationHi,
    String? explanationEn,
    List<String>? tags,
  }) {
    return Question(
      id: id,
      questionText: questionText ?? this.questionText,
      options: options ?? this.options,
      correctOptionIndex: correctOptionIndex ?? this.correctOptionIndex,
      explanation: explanation ?? this.explanation,
      subject: subject ?? this.subject,
      chapter: chapter ?? this.chapter,
      topic: topic ?? this.topic,
      subtopic: subtopic ?? this.subtopic,
      difficulty: difficulty ?? this.difficulty,
      language: language ?? this.language,
      examCategory: examCategory ?? this.examCategory,
      questionType: questionType ?? this.questionType,
      sourceReference: sourceReference ?? this.sourceReference,
      verificationStatus: verificationStatus ?? this.verificationStatus,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      isSample: isSample ?? this.isSample,
      publicationStatus: publicationStatus ?? this.publicationStatus,
      questionTextHi: questionTextHi ?? this.questionTextHi,
      questionTextEn: questionTextEn ?? this.questionTextEn,
      optionsHi: optionsHi ?? this.optionsHi,
      optionsEn: optionsEn ?? this.optionsEn,
      explanationHi: explanationHi ?? this.explanationHi,
      explanationEn: explanationEn ?? this.explanationEn,
      tags: tags ?? this.tags,
    );
  }

  Map<String, Object?> toJson() {
    return <String, Object?>{
      'id': id,
      'question_text': questionText,
      'options': options,
      'correct_option_index': correctOptionIndex,
      'explanation': explanation,
      'subject': subject.id,
      'chapter': chapter,
      'topic': topic,
      'subtopic': subtopic,
      'difficulty': difficulty.code,
      'language': language.code,
      'exam_category': examCategory.code,
      'question_type': questionType.code,
      'source_reference': sourceReference,
      'verification_status': verificationStatus.code,
      'publication_status': publicationStatus.code,
      'created_at': createdAt.toUtc().toIso8601String(),
      'updated_at': updatedAt.toUtc().toIso8601String(),
      'is_sample': isSample,
      if (questionTextHi != null) 'question_text_hi': questionTextHi,
      if (questionTextEn != null) 'question_text_en': questionTextEn,
      if (optionsHi != null) 'options_hi': optionsHi,
      if (optionsEn != null) 'options_en': optionsEn,
      if (explanationHi != null) 'explanation_hi': explanationHi,
      if (explanationEn != null) 'explanation_en': explanationEn,
      'tags': tags,
    };
  }

  /// SQLite row representation (Schema v3) with flattened bilingual columns.
  Map<String, Object?> toDbRow({required String normalizedText}) {
    return <String, Object?>{
      'id': id,
      'question_text': questionText,
      'normalized_text': normalizedText,
      'options_json': jsonEncode(options),
      'correct_option_index': correctOptionIndex,
      'explanation': explanation,
      'subject': subject.id,
      'chapter': chapter,
      'topic': topic,
      'subtopic': subtopic,
      'difficulty': difficulty.code,
      'language': language.code,
      'exam_category': examCategory.code,
      'question_type': questionType.code,
      'source_reference': sourceReference,
      'verification_status': verificationStatus.code,
      'publication_status': publicationStatus.code,
      'created_at': createdAt.toUtc().toIso8601String(),
      'updated_at': updatedAt.toUtc().toIso8601String(),
      'is_sample': isSample ? 1 : 0,
      'question_text_hi': questionTextHi,
      'question_text_en': questionTextEn,
      'options_hi_json': optionsHi == null ? null : jsonEncode(optionsHi),
      'options_en_json': optionsEn == null ? null : jsonEncode(optionsEn),
      'explanation_hi': explanationHi,
      'explanation_en': explanationEn,
      'tags_json': jsonEncode(tags),
    };
  }

  static List<String>? _parseStringListOrNull(Object? raw) {
    if (raw == null) return null;
    if (raw is List) {
      return raw.map((Object? e) => e.toString()).toList(growable: false);
    }
    if (raw is String && raw.trim().isNotEmpty) {
      final Object? decoded = jsonDecode(raw);
      if (decoded is List) {
        return decoded.map((Object? e) => e.toString()).toList(growable: false);
      }
    }
    return null;
  }

  factory Question.fromJson(Map<String, Object?> json) {
    final List<String> parsedOptions =
        _parseStringListOrNull(json['options']) ??
            _parseStringListOrNull(json['options_hi']) ??
            _parseStringListOrNull(json['options_en']) ??
            <String>[];

    final String? textHi = json['question_text_hi']?.toString();
    final String? textEn = json['question_text_en']?.toString();
    final String primaryText = (json['question_text'] ?? textHi ?? textEn ?? '')
        .toString();

    final String? explHi = json['explanation_hi']?.toString();
    final String? explEn = json['explanation_en']?.toString();
    final String primaryExpl =
        (json['explanation'] ?? explHi ?? explEn ?? '').toString();

    final String? pubRaw = json['publication_status']?.toString();

    return Question(
      id: (json['id'] ?? '').toString(),
      questionText: primaryText,
      options: parsedOptions,
      correctOptionIndex: (json['correct_option_index'] is int)
          ? json['correct_option_index']! as int
          : int.tryParse((json['correct_option_index'] ?? '-1').toString()) ?? -1,
      explanation: primaryExpl,
      subject: QuestionSubject.fromId((json['subject'] ?? '').toString()),
      chapter: (json['chapter'] ?? '').toString(),
      topic: (json['topic'] ?? '').toString(),
      subtopic: (json['subtopic'] ?? '').toString(),
      difficulty:
          QuestionDifficulty.fromCode((json['difficulty'] ?? 'medium').toString()),
      language:
          QuestionLanguage.fromCode((json['language'] ?? 'hi').toString()),
      examCategory: ExamCategory.fromCode(
        (json['exam_category'] ?? 'general').toString(),
      ),
      questionType: QuestionType.fromCode(
        (json['question_type'] ?? 'single_choice').toString(),
      ),
      sourceReference: (json['source_reference'] ?? '').toString(),
      verificationStatus: VerificationStatus.fromCode(
        (json['verification_status'] ?? 'unverified').toString(),
      ),
      publicationStatus: pubRaw == null || pubRaw.trim().isEmpty
          ? PublicationStatus.published
          : PublicationStatus.fromCode(pubRaw),
      createdAt: DateTime.parse(
        (json['created_at'] ?? DateTime.now().toUtc().toIso8601String())
            .toString(),
      ),
      updatedAt: DateTime.parse(
        (json['updated_at'] ?? DateTime.now().toUtc().toIso8601String())
            .toString(),
      ),
      isSample: json['is_sample'] == true || json['is_sample'] == 1,
      questionTextHi: textHi,
      questionTextEn: textEn,
      optionsHi: _parseStringListOrNull(json['options_hi']),
      optionsEn: _parseStringListOrNull(json['options_en']),
      explanationHi: explHi,
      explanationEn: explEn,
      tags: _parseStringListOrNull(json['tags']) ?? const <String>[],
    );
  }

  factory Question.fromDbRow(Map<String, Object?> row) {
    final List<dynamic> decoded =
        jsonDecode((row['options_json'] ?? '[]').toString()) as List<dynamic>;
    final String? pubRaw = row['publication_status']?.toString();
    return Question(
      id: (row['id'] ?? '').toString(),
      questionText: (row['question_text'] ?? '').toString(),
      options: decoded.map((dynamic e) => e.toString()).toList(growable: false),
      correctOptionIndex: row['correct_option_index']! as int,
      explanation: (row['explanation'] ?? '').toString(),
      subject: QuestionSubject.fromId((row['subject'] ?? '').toString()),
      chapter: (row['chapter'] ?? '').toString(),
      topic: (row['topic'] ?? '').toString(),
      subtopic: (row['subtopic'] ?? '').toString(),
      difficulty:
          QuestionDifficulty.fromCode((row['difficulty'] ?? '').toString()),
      language: QuestionLanguage.fromCode((row['language'] ?? '').toString()),
      examCategory:
          ExamCategory.fromCode((row['exam_category'] ?? '').toString()),
      questionType:
          QuestionType.fromCode((row['question_type'] ?? '').toString()),
      sourceReference: (row['source_reference'] ?? '').toString(),
      verificationStatus: VerificationStatus.fromCode(
        (row['verification_status'] ?? 'unverified').toString(),
      ),
      publicationStatus: pubRaw == null || pubRaw.trim().isEmpty
          ? PublicationStatus.published
          : PublicationStatus.fromCode(pubRaw),
      createdAt: DateTime.parse((row['created_at'] ?? '').toString()),
      updatedAt: DateTime.parse((row['updated_at'] ?? '').toString()),
      isSample: (row['is_sample'] as int? ?? 0) == 1,
      questionTextHi: row['question_text_hi']?.toString(),
      questionTextEn: row['question_text_en']?.toString(),
      optionsHi: _parseStringListOrNull(row['options_hi_json']),
      optionsEn: _parseStringListOrNull(row['options_en_json']),
      explanationHi: row['explanation_hi']?.toString(),
      explanationEn: row['explanation_en']?.toString(),
      tags: _parseStringListOrNull(row['tags_json']) ?? const <String>[],
    );
  }
}

/// Filter specification for querying questions across repository and data sources.
class QuestionFilter {
  const QuestionFilter({
    this.subject,
    this.chapter,
    this.topic,
    this.subtopic,
    this.difficulty,
    this.language,
    this.examCategory,
    this.questionType,
    this.verificationStatus,
    this.publicationStatus,
    this.searchQuery,
    this.keyword,
    this.includeSamples = true,
    this.limit,
    this.offset = 0,
  });

  final QuestionSubject? subject;
  final String? chapter;
  final String? topic;
  final String? subtopic;
  final QuestionDifficulty? difficulty;
  final QuestionLanguage? language;
  final ExamCategory? examCategory;
  final QuestionType? questionType;
  final VerificationStatus? verificationStatus;
  final PublicationStatus? publicationStatus;
  final String? searchQuery;
  final String? keyword;
  final bool includeSamples;
  final int? limit;
  final int offset;
}
