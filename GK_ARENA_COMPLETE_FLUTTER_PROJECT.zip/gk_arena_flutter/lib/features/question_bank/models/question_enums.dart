/// Core enums and subject registry for the GK ARENA Question Bank.
enum QuestionSubject {
  history('history', 'History', 'इतिहास'),
  geography('geography', 'Geography', 'भूगोल'),
  politicalScience(
    'political_science',
    'Political Science',
    'राजनीति विज्ञान / भारतीय राजव्यवस्था',
  ),
  economics('economics', 'Economics', 'अर्थशास्त्र'),
  physics('physics', 'Physics', 'भौतिक विज्ञान'),
  chemistry('chemistry', 'Chemistry', 'रसायन विज्ञान'),
  biology('biology', 'Biology', 'जीव विज्ञान'),
  generalScience('general_science', 'General Science', 'सामान्य विज्ञान'),
  mathematics('mathematics', 'Mathematics', 'गणित'),
  reasoning('reasoning', 'Reasoning', 'तार्किक क्षमता'),
  staticGk('static_gk', 'Static GK', 'स्थैतिक सामान्य ज्ञान'),
  currentAffairs('current_affairs', 'Current Affairs', 'समसामयिक घटनाएँ');

  const QuestionSubject(this.id, this.titleEn, this.titleHi);

  final String id;
  final String titleEn;
  final String titleHi;

  static QuestionSubject fromId(String value) {
    final String normalized = value.trim().toLowerCase();
    for (final QuestionSubject subject in QuestionSubject.values) {
      if (subject.id == normalized ||
          subject.titleEn.toLowerCase() == normalized) {
        return subject;
      }
    }
    throw ArgumentError('Unsupported QuestionSubject: $value');
  }
}

enum QuestionDifficulty {
  easy('easy', 'Easy', 'आसान'),
  medium('medium', 'Medium', 'मध्यम'),
  hard('hard', 'Hard', 'कठिन');

  const QuestionDifficulty(this.code, this.labelEn, this.labelHi);

  final String code;
  final String labelEn;
  final String labelHi;

  static QuestionDifficulty fromCode(String value) {
    final String normalized = value.trim().toLowerCase();
    for (final QuestionDifficulty item in QuestionDifficulty.values) {
      if (item.code == normalized) return item;
    }
    throw ArgumentError('Unsupported QuestionDifficulty: $value');
  }
}

enum QuestionLanguage {
  hindi('hi', 'Hindi', 'हिन्दी'),
  english('en', 'English', 'English');

  const QuestionLanguage(this.code, this.labelEn, this.labelNative);

  final String code;
  final String labelEn;
  final String labelNative;

  static QuestionLanguage fromCode(String value) {
    final String normalized = value.trim().toLowerCase();
    if (normalized == 'hi' || normalized == 'hindi') return QuestionLanguage.hindi;
    if (normalized == 'en' || normalized == 'english') {
      return QuestionLanguage.english;
    }
    throw ArgumentError('Unsupported QuestionLanguage: $value');
  }
}

enum QuestionType {
  singleChoice('single_choice'),
  statementBased('statement_based'),
  matchTheFollowing('match_the_following'),
  assertionReason('assertion_reason'),
  previousYear('previous_year');

  const QuestionType(this.code);

  final String code;

  static QuestionType fromCode(String value) {
    final String normalized = value.trim().toLowerCase();
    for (final QuestionType type in QuestionType.values) {
      if (type.code == normalized) return type;
    }
    throw ArgumentError('Unsupported QuestionType: $value');
  }
}

enum ExamCategory {
  general('general'),
  ssc('ssc'),
  railway('railway'),
  bpsc('bpsc'),
  statePsc('state_psc'),
  banking('banking'),
  defence('defence'),
  upsc('upsc');

  const ExamCategory(this.code);

  final String code;

  static ExamCategory fromCode(String value) {
    final String normalized = value.trim().toLowerCase();
    for (final ExamCategory category in ExamCategory.values) {
      if (category.code == normalized) return category;
    }
    throw ArgumentError('Unsupported ExamCategory: $value');
  }
}

enum VerificationStatus {
  demoUnverified('demo_unverified'),
  unverified('unverified'),
  draft('draft'),
  pendingReview('pending_review'),
  verified('verified'),
  rejected('rejected');

  const VerificationStatus(this.code);

  final String code;

  static VerificationStatus fromCode(String value) {
    final String normalized = value.trim().toLowerCase();
    for (final VerificationStatus status in VerificationStatus.values) {
      if (status.code == normalized) return status;
    }
    throw ArgumentError('Unsupported VerificationStatus: $value');
  }
}

/// Editorial & review workflow status (kept strictly separate from factual VerificationStatus).
enum PublicationStatus {
  draft('draft', 'Draft'),
  pendingReview('pending_review', 'Pending Review'),
  approved('approved', 'Approved'),
  published('published', 'Published'),
  rejected('rejected', 'Rejected');

  const PublicationStatus(this.code, this.label);

  final String code;
  final String label;

  static PublicationStatus fromCode(String value) {
    final String normalized = value.trim().toLowerCase();
    for (final PublicationStatus status in PublicationStatus.values) {
      if (status.code == normalized) return status;
    }
    return PublicationStatus.draft;
  }
}
