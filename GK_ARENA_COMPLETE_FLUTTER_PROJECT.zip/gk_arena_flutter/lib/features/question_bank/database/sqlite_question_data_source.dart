import 'dart:math';
import 'package:gk_arena/features/question_bank/database/question_data_source.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// Production-ready SQLite Question Bank database optimized for 100,000+ MCQs.
/// Features WAL mode, page caching, composite indexes, normalized-text
/// uniqueness, chunked batch transactions, pagination, and safe schema v2 migrations.
class SqliteQuestionDataSource implements QuestionDataSource {
  SqliteQuestionDataSource({
    this.databaseName = 'gk_arena_question_bank.db',
  });

  static const int schemaVersion = 3;
  static const String tableQuestions = 'questions';
  static const int _batchChunkSize = 500;
  static const int _inClauseChunkSize = 400;

  final String databaseName;
  final Random _random = Random();
  Database? _db;

  Database get _database {
    final Database? db = _db;
    if (db == null) {
      throw StateError(
        'SqliteQuestionDataSource.initialize() must be called before querying.',
      );
    }
    return db;
  }

  @override
  Future<void> initialize() async {
    if (_db != null) return;
    final String dbDir = await getDatabasesPath();
    final String fullPath = p.join(dbDir, databaseName);

    _db = await openDatabase(
      fullPath,
      version: schemaVersion,
      onConfigure: _onConfigure,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onConfigure(Database db) async {
    // Performance PRAGMAs for smooth 100k+ MCQ reads and chunked batch writes.
    await db.rawQuery('PRAGMA journal_mode = WAL');
    await db.execute('PRAGMA synchronous = NORMAL');
    await db.execute('PRAGMA temp_store = MEMORY');
    await db.execute('PRAGMA cache_size = -8000');
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $tableQuestions (
        id TEXT PRIMARY KEY NOT NULL,
        question_text TEXT NOT NULL,
        normalized_text TEXT NOT NULL,
        options_json TEXT NOT NULL,
        correct_option_index INTEGER NOT NULL CHECK(correct_option_index BETWEEN 0 AND 3),
        explanation TEXT NOT NULL,
        subject TEXT NOT NULL,
        chapter TEXT NOT NULL DEFAULT '',
        topic TEXT NOT NULL,
        subtopic TEXT NOT NULL,
        difficulty TEXT NOT NULL,
        language TEXT NOT NULL,
        exam_category TEXT NOT NULL,
        question_type TEXT NOT NULL,
        source_reference TEXT NOT NULL,
        verification_status TEXT NOT NULL,
        publication_status TEXT NOT NULL DEFAULT 'published',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        is_sample INTEGER NOT NULL DEFAULT 0,
        question_text_hi TEXT,
        question_text_en TEXT,
        options_hi_json TEXT,
        options_en_json TEXT,
        explanation_hi TEXT,
        explanation_en TEXT,
        tags_json TEXT NOT NULL DEFAULT '[]',
        UNIQUE(language, normalized_text)
      )
    ''');

    await db.execute(
      'CREATE INDEX idx_q_subject_lang_diff ON $tableQuestions (subject, language, difficulty)',
    );
    await db.execute(
      'CREATE INDEX idx_q_topic ON $tableQuestions (subject, topic, subtopic)',
    );
    await db.execute(
      'CREATE INDEX idx_q_exam_type ON $tableQuestions (exam_category, question_type)',
    );
    await db.execute(
      'CREATE INDEX idx_q_normalized_text ON $tableQuestions (normalized_text)',
    );
    await db.execute(
      'CREATE INDEX idx_q_sample_status ON $tableQuestions (is_sample, verification_status)',
    );
    await db.execute(
      'CREATE INDEX idx_q_pub_status ON $tableQuestions (publication_status, subject, language, difficulty)',
    );
    await db.execute(
      'CREATE INDEX idx_q_subject_chapter_topic ON $tableQuestions (subject, chapter, topic)',
    );
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 1) {
      await _onCreate(db, newVersion);
      return;
    }
    if (oldVersion < 2) {
      await db.execute(
        "ALTER TABLE $tableQuestions ADD COLUMN publication_status TEXT NOT NULL DEFAULT 'published'",
      );
      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_q_pub_status ON $tableQuestions (publication_status, subject, language, difficulty)',
      );
    }
    if (oldVersion < 3) {
      await db.execute("ALTER TABLE $tableQuestions ADD COLUMN chapter TEXT NOT NULL DEFAULT ''");
      await db.execute('ALTER TABLE $tableQuestions ADD COLUMN question_text_hi TEXT');
      await db.execute('ALTER TABLE $tableQuestions ADD COLUMN question_text_en TEXT');
      await db.execute('ALTER TABLE $tableQuestions ADD COLUMN options_hi_json TEXT');
      await db.execute('ALTER TABLE $tableQuestions ADD COLUMN options_en_json TEXT');
      await db.execute('ALTER TABLE $tableQuestions ADD COLUMN explanation_hi TEXT');
      await db.execute('ALTER TABLE $tableQuestions ADD COLUMN explanation_en TEXT');
      await db.execute("ALTER TABLE $tableQuestions ADD COLUMN tags_json TEXT NOT NULL DEFAULT '[]'");
      await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_q_subject_chapter_topic ON $tableQuestions (subject, chapter, topic)',
      );
    }
  }

  @override
  Future<void> close() async {
    await _db?.close();
    _db = null;
  }

  @override
  Future<void> insertQuestion(
    Question question, {
    required String normalizedText,
  }) async {
    await _database.insert(
      tableQuestions,
      question.toDbRow(normalizedText: normalizedText),
      conflictAlgorithm: ConflictAlgorithm.abort,
    );
  }

  @override
  Future<int> insertBatch(
    List<({Question question, String normalizedText})> records,
  ) async {
    if (records.isEmpty) return 0;
    int inserted = 0;

    for (int start = 0; start < records.length; start += _batchChunkSize) {
      final int end = (start + _batchChunkSize < records.length)
          ? start + _batchChunkSize
          : records.length;
      final List<({Question question, String normalizedText})> chunk =
          records.sublist(start, end);

      await _database.transaction((Transaction txn) async {
        final Batch batch = txn.batch();
        for (final ({Question question, String normalizedText}) item in chunk) {
          batch.insert(
            tableQuestions,
            item.question.toDbRow(normalizedText: item.normalizedText),
            conflictAlgorithm: ConflictAlgorithm.ignore,
          );
        }
        final List<Object?> results = await batch.commit(noResult: false);
        for (final Object? res in results) {
          if (res is int && res > 0) {
            inserted++;
          }
        }
      });
    }
    return inserted;
  }

  @override
  Future<void> updateQuestion(
    Question question, {
    required String normalizedText,
  }) async {
    final int updated = await _database.update(
      tableQuestions,
      question.toDbRow(normalizedText: normalizedText),
      where: 'id = ?',
      whereArgs: <Object?>[question.id],
      conflictAlgorithm: ConflictAlgorithm.abort,
    );
    if (updated == 0) {
      throw StateError('Question ID "${question.id}" not found for update.');
    }
  }

  @override
  Future<bool> deleteQuestion(String id) async {
    final int deleted = await _database.delete(
      tableQuestions,
      where: 'id = ?',
      whereArgs: <Object?>[id],
    );
    return deleted > 0;
  }

  @override
  Future<int> deleteBatch(List<String> ids) async {
    if (ids.isEmpty) return 0;
    int deletedTotal = 0;
    await _database.transaction((Transaction txn) async {
      for (final String id in ids) {
        deletedTotal += await txn.delete(
          tableQuestions,
          where: 'id = ?',
          whereArgs: <Object?>[id],
        );
      }
    });
    return deletedTotal;
  }

  @override
  Future<Question?> findById(String id) async {
    final List<Map<String, Object?>> rows = await _database.query(
      tableQuestions,
      where: 'id = ?',
      whereArgs: <Object?>[id],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return Question.fromDbRow(rows.first);
  }

  @override
  Future<Map<String, Question>> findByIds(List<String> ids) async {
    if (ids.isEmpty) return const <String, Question>{};
    final List<String> uniqueIds = ids.toSet().toList(growable: false);
    final Map<String, Question> found = <String, Question>{};

    for (int start = 0; start < uniqueIds.length; start += _inClauseChunkSize) {
      final int end = (start + _inClauseChunkSize < uniqueIds.length)
          ? start + _inClauseChunkSize
          : uniqueIds.length;
      final List<String> chunk = uniqueIds.sublist(start, end);
      final String placeholders = List<String>.filled(chunk.length, '?').join(',');
      final List<Map<String, Object?>> rows = await _database.query(
        tableQuestions,
        where: 'id IN ($placeholders)',
        whereArgs: chunk,
      );
      for (final Map<String, Object?> row in rows) {
        final Question q = Question.fromDbRow(row);
        found[q.id] = q;
      }
    }
    return found;
  }

  @override
  Future<bool> existsById(String id) async {
    final List<Map<String, Object?>> rows = await _database.query(
      tableQuestions,
      columns: <String>['id'],
      where: 'id = ?',
      whereArgs: <Object?>[id],
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  @override
  Future<bool> existsByNormalizedText(
    String normalizedText, {
    QuestionLanguage? language,
  }) async {
    final String where = language != null
        ? 'normalized_text = ? AND language = ?'
        : 'normalized_text = ?';
    final List<Object?> args = language != null
        ? <Object?>[normalizedText, language.code]
        : <Object?>[normalizedText];

    final List<Map<String, Object?>> rows = await _database.query(
      tableQuestions,
      columns: <String>['id'],
      where: where,
      whereArgs: args,
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  @override
  Future<List<String>> getDistinctTopics({
    QuestionSubject? subject,
    QuestionLanguage? language,
    PublicationStatus? publicationStatus,
  }) async {
    final ({String? where, List<Object?> args}) clause = _buildWhere(
      QuestionFilter(
        subject: subject,
        language: language,
        publicationStatus: publicationStatus,
      ),
    );
    final String sql = clause.where == null
        ? 'SELECT DISTINCT topic FROM $tableQuestions WHERE topic != "" ORDER BY topic ASC'
        : 'SELECT DISTINCT topic FROM $tableQuestions WHERE ${clause.where} AND topic != "" ORDER BY topic ASC';

    final List<Map<String, Object?>> rows =
        await _database.rawQuery(sql, clause.args);
    return rows
        .map((Map<String, Object?> r) => (r['topic'] ?? '').toString().trim())
        .where((String t) => t.isNotEmpty)
        .toList(growable: false);
  }

  @override
  Future<List<Question>> query(QuestionFilter filter) async {
    final ({String? where, List<Object?> args}) clause = _buildWhere(filter);
    final List<Map<String, Object?>> rows = await _database.query(
      tableQuestions,
      where: clause.where,
      whereArgs: clause.args.isEmpty ? null : clause.args,
      orderBy: 'id ASC',
      limit: filter.limit,
      offset: filter.offset > 0 ? filter.offset : null,
    );
    return rows.map(Question.fromDbRow).toList(growable: false);
  }

  @override
  Future<List<Question>> queryMixed({
    QuestionLanguage? language,
    QuestionDifficulty? difficulty,
    ExamCategory? examCategory,
    PublicationStatus? publicationStatus,
    bool includeSamples = true,
    int limit = 20,
  }) async {
    final QuestionFilter baseFilter = QuestionFilter(
      language: language,
      difficulty: difficulty,
      examCategory: examCategory,
      publicationStatus: publicationStatus,
      includeSamples: includeSamples,
    );
    final int total = await count(baseFilter);
    if (total == 0) return const <Question>[];

    // Indexed bounded window sampling avoids O(N) full-table ORDER BY RANDOM() on 100k+ rows.
    final int maxOffset = total > limit ? total - limit : 0;
    final int offset = maxOffset > 0 ? _random.nextInt(maxOffset + 1) : 0;

    final ({String? where, List<Object?> args}) clause = _buildWhere(baseFilter);
    final List<Map<String, Object?>> rows = await _database.query(
      tableQuestions,
      where: clause.where,
      whereArgs: clause.args.isEmpty ? null : clause.args,
      orderBy: 'id ASC',
      limit: limit,
      offset: offset > 0 ? offset : null,
    );
    return rows.map(Question.fromDbRow).toList(growable: false);
  }

  @override
  Future<int> count(QuestionFilter filter) async {
    final ({String? where, List<Object?> args}) clause = _buildWhere(filter);
    final String sql = clause.where == null
        ? 'SELECT COUNT(*) AS cnt FROM $tableQuestions'
        : 'SELECT COUNT(*) AS cnt FROM $tableQuestions WHERE ${clause.where}';
    final List<Map<String, Object?>> result =
        await _database.rawQuery(sql, clause.args);
    return (result.first['cnt'] as int?) ?? 0;
  }

  ({String? where, List<Object?> args}) _buildWhere(QuestionFilter filter) {
    final List<String> conditions = <String>[];
    final List<Object?> args = <Object?>[];

    if (!filter.includeSamples) {
      conditions.add('is_sample = 0');
    }
    if (filter.subject != null) {
      conditions.add('subject = ?');
      args.add(filter.subject!.id);
    }
    if (filter.chapter != null && filter.chapter!.trim().isNotEmpty) {
      conditions.add('LOWER(chapter) = ?');
      args.add(filter.chapter!.trim().toLowerCase());
    }
    if (filter.topic != null && filter.topic!.trim().isNotEmpty) {
      conditions.add('LOWER(topic) = ?');
      args.add(filter.topic!.trim().toLowerCase());
    }
    if (filter.subtopic != null && filter.subtopic!.trim().isNotEmpty) {
      conditions.add('LOWER(subtopic) = ?');
      args.add(filter.subtopic!.trim().toLowerCase());
    }
    if (filter.difficulty != null) {
      conditions.add('difficulty = ?');
      args.add(filter.difficulty!.code);
    }
    if (filter.language != null) {
      conditions.add('language = ?');
      args.add(filter.language!.code);
    }
    if (filter.examCategory != null) {
      conditions.add('exam_category = ?');
      args.add(filter.examCategory!.code);
    }
    if (filter.questionType != null) {
      conditions.add('question_type = ?');
      args.add(filter.questionType!.code);
    }
    if (filter.verificationStatus != null) {
      conditions.add('verification_status = ?');
      args.add(filter.verificationStatus!.code);
    }
    if (filter.publicationStatus != null) {
      conditions.add('publication_status = ?');
      args.add(filter.publicationStatus!.code);
    }
    final String? kw = (filter.keyword ?? filter.searchQuery)?.trim();
    if (kw != null && kw.isNotEmpty) {
      final String pattern = '%${kw.toLowerCase()}%';
      conditions.add(
        '(LOWER(id) LIKE ? OR LOWER(question_text) LIKE ? OR LOWER(COALESCE(question_text_hi, "")) LIKE ? '
        'OR LOWER(COALESCE(question_text_en, "")) LIKE ? OR LOWER(chapter) LIKE ? OR LOWER(topic) LIKE ? OR LOWER(tags_json) LIKE ?)',
      );
      for (int k = 0; k < 7; k++) {
        args.add(pattern);
      }
    }

    return (
      where: conditions.isEmpty ? null : conditions.join(' AND '),
      args: args,
    );
  }
}
