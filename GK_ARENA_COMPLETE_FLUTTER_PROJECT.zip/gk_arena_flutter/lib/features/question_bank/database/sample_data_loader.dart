import 'package:flutter/services.dart';
import 'package:gk_arena/features/question_bank/importers/question_batch_importer.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';

/// Loads the strictly separated 20-question demo dataset for local dev/testing.
class SampleDataLoader {
  const SampleDataLoader({required this.repository});

  static const String sampleAssetPath =
      'assets/sample_data/demo_sample_questions.json';

  final QuestionRepository repository;

  Future<BatchImportReport> loadDemoSamples({AssetBundle? bundle}) async {
    final AssetBundle activeBundle = bundle ?? rootBundle;
    final String rawJson = await activeBundle.loadString(sampleAssetPath);
    final QuestionBatchImporter importer =
        QuestionBatchImporter(repository: repository);
    return importer.importFromJsonString(rawJson);
  }
}
