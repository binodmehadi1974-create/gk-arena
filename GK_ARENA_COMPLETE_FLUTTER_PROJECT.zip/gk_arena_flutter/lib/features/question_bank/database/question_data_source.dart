import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';

/// Storage-agnostic interface for Question Bank persistence.
/// Supports both SQLite (production 100,000+ MCQs) and in-memory (tests/dev).
abstract class QuestionDataSource {
  Future<void> initialize();
  Future<void> close();

  Future<void> insertQuestion(Question question, {required String normalizedText});
  Future<int> insertBatch(List<({Question question, String normalizedText})> records);
  Future<void> updateQuestion(Question question, {required String normalizedText});
  Future<bool> deleteQuestion(String id);
  Future<int> deleteBatch(List<String> ids);

  Future<Question?> findById(String id);
  Future<Map<String, Question>> findByIds(List<String> ids);
  Future<bool> existsById(String id);
  Future<bool> existsByNormalizedText(
    String normalizedText, {
    QuestionLanguage? language,
  });

  Future<List<String>> getDistinctTopics({
    QuestionSubject? subject,
    QuestionLanguage? language,
    PublicationStatus? publicationStatus,
  });

  Future<List<Question>> query(QuestionFilter filter);
  Future<List<Question>> queryMixed({
    QuestionLanguage? language,
    QuestionDifficulty? difficulty,
    ExamCategory? examCategory,
    PublicationStatus? publicationStatus,
    bool includeSamples = true,
    int limit = 20,
  });
  Future<int> count(QuestionFilter filter);
}
