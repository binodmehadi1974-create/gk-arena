import 'package:gk_arena/features/question_bank/database/question_data_source.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';

/// Pure-Dart indexed in-memory implementation mirroring SQLite constraints for tests/dev.
class InMemoryQuestionDataSource implements QuestionDataSource {
  final Map<String, Question> _byId = <String, Question>{};
  final Map<String, String> _keyById = <String, String>{};
  final Set<String> _normalizedKeys = <String>{};
  final List<Question> _ordered = <Question>[];

  String _dedupKey(String normalizedText, QuestionLanguage language) =>
      '${language.code}::$normalizedText';

  @override
  Future<void> initialize() async {}

  @override
  Future<void> close() async {
    _byId.clear();
    _keyById.clear();
    _normalizedKeys.clear();
    _ordered.clear();
  }

  @override
  Future<void> insertQuestion(
    Question question, {
    required String normalizedText,
  }) async {
    if (_byId.containsKey(question.id)) {
      throw StateError('Duplicate question ID: ${question.id}');
    }
    final String key = _dedupKey(normalizedText, question.language);
    if (_normalizedKeys.contains(key)) {
      throw StateError('Duplicate normalized question text detected.');
    }
    _byId[question.id] = question;
    _keyById[question.id] = key;
    _normalizedKeys.add(key);
    _ordered.add(question);
  }

  @override
  Future<int> insertBatch(
    List<({Question question, String normalizedText})> records,
  ) async {
    int inserted = 0;
    for (final ({Question question, String normalizedText}) item in records) {
      final String key = _dedupKey(item.normalizedText, item.question.language);
      if (_byId.containsKey(item.question.id) || _normalizedKeys.contains(key)) {
        continue;
      }
      _byId[item.question.id] = item.question;
      _keyById[item.question.id] = key;
      _normalizedKeys.add(key);
      _ordered.add(item.question);
      inserted++;
    }
    return inserted;
  }

  @override
  Future<void> updateQuestion(
    Question question, {
    required String normalizedText,
  }) async {
    if (!_byId.containsKey(question.id)) {
      throw StateError('Question ID "${question.id}" not found for update.');
    }
    final String? oldKey = _keyById[question.id];
    final String newKey = _dedupKey(normalizedText, question.language);
    if (oldKey != newKey && _normalizedKeys.contains(newKey)) {
      throw StateError('Duplicate normalized question text detected.');
    }
    if (oldKey != null) {
      _normalizedKeys.remove(oldKey);
    }
    _normalizedKeys.add(newKey);
    _keyById[question.id] = newKey;
    _byId[question.id] = question;
    final int idx = _ordered.indexWhere((Question q) => q.id == question.id);
    if (idx != -1) {
      _ordered[idx] = question;
    }
  }

  @override
  Future<bool> deleteQuestion(String id) async {
    final Question? removed = _byId.remove(id);
    if (removed == null) return false;
    final String? oldKey = _keyById.remove(id);
    if (oldKey != null) {
      _normalizedKeys.remove(oldKey);
    }
    _ordered.removeWhere((Question q) => q.id == id);
    return true;
  }

  @override
  Future<int> deleteBatch(List<String> ids) async {
    int deleted = 0;
    for (final String id in ids) {
      if (await deleteQuestion(id)) {
        deleted++;
      }
    }
    return deleted;
  }

  @override
  Future<Question?> findById(String id) async => _byId[id];

  @override
  Future<Map<String, Question>> findByIds(List<String> ids) async {
    final Map<String, Question> found = <String, Question>{};
    for (final String id in ids) {
      final Question? q = _byId[id];
      if (q != null) found[id] = q;
    }
    return found;
  }

  @override
  Future<bool> existsById(String id) async => _byId.containsKey(id);

  @override
  Future<bool> existsByNormalizedText(
    String normalizedText, {
    QuestionLanguage? language,
  }) async {
    if (language != null) {
      return _normalizedKeys.contains(_dedupKey(normalizedText, language));
    }
    for (final QuestionLanguage lang in QuestionLanguage.values) {
      if (_normalizedKeys.contains(_dedupKey(normalizedText, lang))) {
        return true;
      }
    }
    return false;
  }

  @override
  Future<List<String>> getDistinctTopics({
    QuestionSubject? subject,
    QuestionLanguage? language,
    PublicationStatus? publicationStatus,
  }) async {
    final Set<String> topics = <String>{};
    for (final Question q in _applyFilter(
      QuestionFilter(
        subject: subject,
        language: language,
        publicationStatus: publicationStatus,
      ),
    )) {
      final String t = q.topic.trim();
      if (t.isNotEmpty) topics.add(t);
    }
    final List<String> sorted = topics.toList()..sort();
    return sorted;
  }

  @override
  Future<List<Question>> query(QuestionFilter filter) async {
    final Iterable<Question> matches = _applyFilter(filter);
    final Iterable<Question> skipped =
        filter.offset > 0 ? matches.skip(filter.offset) : matches;
    final Iterable<Question> limited =
        filter.limit != null ? skipped.take(filter.limit!) : skipped;
    return limited.toList(growable: false);
  }

  @override
  Future<List<Question>> queryMixed({
    QuestionLanguage? language,
    QuestionDifficulty? difficulty,
    ExamCategory? examCategory,
    PublicationStatus? publicationStatus,
    bool includeSamples = true,
    int limit = 20,
  }) async {
    final List<Question> filtered = _applyFilter(
      QuestionFilter(
        language: language,
        difficulty: difficulty,
        examCategory: examCategory,
        publicationStatus: publicationStatus,
        includeSamples: includeSamples,
      ),
    ).toList(growable: false);

    final Map<QuestionSubject, List<Question>> buckets =
        <QuestionSubject, List<Question>>{};
    for (final Question q in filtered) {
      buckets.putIfAbsent(q.subject, () => <Question>[]).add(q);
    }

    final List<Question> mixed = <Question>[];
    int depth = 0;
    while (mixed.length < limit) {
      bool addedAny = false;
      for (final List<Question> bucket in buckets.values) {
        if (depth < bucket.length && mixed.length < limit) {
          mixed.add(bucket[depth]);
          addedAny = true;
        }
      }
      if (!addedAny) break;
      depth++;
    }
    return mixed;
  }

  @override
  Future<int> count(QuestionFilter filter) async => _applyFilter(filter).length;

  Iterable<Question> _applyFilter(QuestionFilter filter) {
    final String? chapterLower = filter.chapter?.trim().toLowerCase();
    final String? topicLower = filter.topic?.trim().toLowerCase();
    final String? subtopicLower = filter.subtopic?.trim().toLowerCase();
    final String? searchLower = (filter.keyword ?? filter.searchQuery)?.trim().toLowerCase();

    return _ordered.where((Question q) {
      if (!filter.includeSamples && q.isSample) return false;
      if (filter.subject != null && q.subject != filter.subject) return false;
      if (chapterLower != null &&
          chapterLower.isNotEmpty &&
          q.chapter.trim().toLowerCase() != chapterLower) {
        return false;
      }
      if (topicLower != null &&
          topicLower.isNotEmpty &&
          q.topic.trim().toLowerCase() != topicLower) {
        return false;
      }
      if (subtopicLower != null &&
          subtopicLower.isNotEmpty &&
          q.subtopic.trim().toLowerCase() != subtopicLower) {
        return false;
      }
      if (filter.difficulty != null && q.difficulty != filter.difficulty) {
        return false;
      }
      if (filter.language != null && q.language != filter.language) {
        return false;
      }
      if (filter.examCategory != null && q.examCategory != filter.examCategory) {
        return false;
      }
      if (filter.questionType != null && q.questionType != filter.questionType) {
        return false;
      }
      if (filter.verificationStatus != null &&
          q.verificationStatus != filter.verificationStatus) {
        return false;
      }
      if (filter.publicationStatus != null &&
          q.publicationStatus != filter.publicationStatus) {
        return false;
      }
      if (searchLower != null && searchLower.isNotEmpty) {
        final bool match = q.id.toLowerCase().contains(searchLower) ||
            q.questionText.toLowerCase().contains(searchLower) ||
            (q.questionTextHi?.toLowerCase().contains(searchLower) ?? false) ||
            (q.questionTextEn?.toLowerCase().contains(searchLower) ?? false) ||
            q.chapter.toLowerCase().contains(searchLower) ||
            q.topic.toLowerCase().contains(searchLower) ||
            q.tags.any((String tag) => tag.toLowerCase().contains(searchLower));
        if (!match) return false;
      }
      return true;
    });
  }
}
