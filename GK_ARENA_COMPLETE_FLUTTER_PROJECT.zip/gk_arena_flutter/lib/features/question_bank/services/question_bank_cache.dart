import 'dart:collection';

/// Lightweight bounded LRU cache for frequently queried metadata (topic lists,
/// aggregate counts) so 100k+ MCQ queries stay fast with minimal memory usage.
class BoundedMemoryCache<K, V> {
  BoundedMemoryCache({this.maxEntries = 128});

  final int maxEntries;
  final LinkedHashMap<K, V> _store = LinkedHashMap<K, V>();

  V? get(K key) {
    final V? value = _store.remove(key);
    if (value != null) {
      _store[key] = value;
    }
    return value;
  }

  void put(K key, V value) {
    _store.remove(key);
    _store[key] = value;
    if (_store.length > maxEntries) {
      _store.remove(_store.keys.first);
    }
  }

  void clear() => _store.clear();

  int get length => _store.length;
}
