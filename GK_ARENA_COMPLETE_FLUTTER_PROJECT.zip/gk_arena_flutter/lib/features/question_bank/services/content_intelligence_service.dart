import 'dart:convert';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/validation/question_validator.dart';

/// Flexible subject & taxonomy descriptor allowing future subjects and chapters
/// to be registered cleanly beyond the 12 core GK ARENA subjects.
class SubjectTaxonomyEntry {
  const SubjectTaxonomyEntry({
    required this.id,
    required this.titleEn,
    required this.titleHi,
    this.chapters = const <String>[],
  });

  final String id;
  final String titleEn;
  final String titleHi;
  final List<String> chapters;
}

class SubjectTaxonomyRegistry {
  SubjectTaxonomyRegistry() {
    for (final QuestionSubject subject in QuestionSubject.values) {
      _entries[subject.id] = SubjectTaxonomyEntry(
        id: subject.id,
        titleEn: subject.titleEn,
        titleHi: subject.titleHi,
      );
    }
  }

  final Map<String, SubjectTaxonomyEntry> _entries =
      <String, SubjectTaxonomyEntry>{};

  List<SubjectTaxonomyEntry> get allSubjects =>
      List<SubjectTaxonomyEntry>.unmodifiable(_entries.values);

  bool containsSubject(String id) =>
      _entries.containsKey(id.trim().toLowerCase());

  void registerSubject(SubjectTaxonomyEntry entry) {
    _entries[entry.id.trim().toLowerCase()] = entry;
  }
}

class QuestionQualityReport {
  const QuestionQualityReport({
    required this.isTechnicallyValid,
    required this.errors,
    required this.warnings,
    required this.hasHindiTranslation,
    required this.hasEnglishTranslation,
  });

  final bool isTechnicallyValid;
  final List<String> errors;
  final List<String> warnings;
  final bool hasHindiTranslation;
  final bool hasEnglishTranslation;
}

/// Advanced Question Quality Control service checking structural integrity,
/// bilingual completeness, source tracking, and strict verification separation.
class QuestionQualityController {
  const QuestionQualityController({
    this.baseValidator = const QuestionValidator(),
  });

  final QuestionValidator baseValidator;

  QuestionQualityReport inspect(Question question) {
    final QuestionValidationResult base = baseValidator.validate(question);
    final List<String> errors = <String>[...base.errors];
    final List<String> warnings = <String>[];

    if (question.sourceReference.trim().isEmpty) {
      warnings.add('Source/reference is missing.');
    }
    if (question.chapter.trim().isEmpty) {
      warnings.add('Chapter metadata is empty.');
    }

    // Validate Hindi translation options if Hindi text is provided
    if (question.questionTextHi != null &&
        question.questionTextHi!.trim().isNotEmpty) {
      final List<String>? hiOpts = question.optionsHi;
      if (hiOpts != null) {
        if (hiOpts.length != 4) {
          errors.add('Hindi options must contain exactly 4 entries.');
        } else {
          final Set<String> seen = <String>{};
          for (int i = 0; i < 4; i++) {
            final String norm = QuestionTextNormalizer.normalize(hiOpts[i]);
            if (norm.isEmpty) {
              errors.add('Hindi option ${i + 1} must not be empty.');
            } else if (!seen.add(norm)) {
              errors.add('Duplicate Hindi option at position ${i + 1}.');
            }
          }
        }
      }
      if (question.explanationHi == null ||
          question.explanationHi!.trim().isEmpty) {
        warnings.add('Hindi explanation is missing (will fallback safely).');
      }
    }

    // Validate English translation options if English text is provided
    if (question.questionTextEn != null &&
        question.questionTextEn!.trim().isNotEmpty) {
      final List<String>? enOpts = question.optionsEn;
      if (enOpts != null) {
        if (enOpts.length != 4) {
          errors.add('English options must contain exactly 4 entries.');
        } else {
          final Set<String> seen = <String>{};
          for (int i = 0; i < 4; i++) {
            final String norm = QuestionTextNormalizer.normalize(enOpts[i]);
            if (norm.isEmpty) {
              errors.add('English option ${i + 1} must not be empty.');
            } else if (!seen.add(norm)) {
              errors.add('Duplicate English option at position ${i + 1}.');
            }
          }
        }
      }
      if (question.explanationEn == null ||
          question.explanationEn!.trim().isEmpty) {
        warnings.add('English explanation is missing (will fallback safely).');
      }
    }

    return QuestionQualityReport(
      isTechnicallyValid: errors.isEmpty,
      errors: List<String>.unmodifiable(errors),
      warnings: List<String>.unmodifiable(warnings),
      hasHindiTranslation: question.hasTranslation(QuestionLanguage.hindi),
      hasEnglishTranslation: question.hasTranslation(QuestionLanguage.english),
    );
  }
}

/// Exports question collections to clean JSON for Admin backup/exchange.
class QuestionBankExportService {
  const QuestionBankExportService();

  String exportToJson(List<Question> questions) {
    final Map<String, Object?> payload = <String, Object?>{
      'schema_version': 3,
      'exported_at': DateTime.now().toUtc().toIso8601String(),
      'count': questions.length,
      'questions': questions.map((Question q) => q.toJson()).toList(growable: false),
    };
    return const JsonEncoder.withIndent('  ').convert(payload);
  }
}
