import 'dart:convert';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';

/// Serializable snapshot of a single reviewed question inside a completed test.
class SavedReviewEntry {
  const SavedReviewEntry({
    required this.index,
    required this.question,
    required this.selectedOptionIndex,
    required this.isMarkedForReview,
    required this.outcome,
    required this.marksAwarded,
  });

  final int index;
  final Question question;
  final int? selectedOptionIndex;
  final bool isMarkedForReview;
  final AnswerOutcome outcome;
  final double marksAwarded;

  factory SavedReviewEntry.fromReviewItem(QuestionReviewItem item) {
    return SavedReviewEntry(
      index: item.index,
      question: item.question,
      selectedOptionIndex: item.selectedOptionIndex,
      isMarkedForReview: item.isMarkedForReview,
      outcome: item.outcome,
      marksAwarded: item.marksAwarded,
    );
  }

  QuestionReviewItem toReviewItem() {
    return QuestionReviewItem(
      index: index,
      question: question,
      selectedOptionIndex: selectedOptionIndex,
      isMarkedForReview: isMarkedForReview,
      outcome: outcome,
      marksAwarded: marksAwarded,
    );
  }

  Map<String, Object?> toJson() {
    return <String, Object?>{
      'index': index,
      'question': question.toJson(),
      'selected_option_index': selectedOptionIndex,
      'is_marked_for_review': isMarkedForReview,
      'outcome': outcome.name,
      'marks_awarded': marksAwarded,
    };
  }

  factory SavedReviewEntry.fromJson(Map<String, Object?> json) {
    final String outcomeName = (json['outcome'] ?? 'unattempted').toString();
    final AnswerOutcome parsedOutcome = AnswerOutcome.values.firstWhere(
      (AnswerOutcome e) => e.name == outcomeName,
      orElse: () => AnswerOutcome.unattempted,
    );
    final Map<String, Object?> questionMap =
        (json['question'] as Map<dynamic, dynamic>).map(
      (dynamic k, dynamic v) => MapEntry<String, Object?>(k.toString(), v),
    );
    return SavedReviewEntry(
      index: (json['index'] as num?)?.toInt() ?? 0,
      question: Question.fromJson(questionMap),
      selectedOptionIndex: (json['selected_option_index'] as num?)?.toInt(),
      isMarkedForReview: json['is_marked_for_review'] == true,
      outcome: parsedOutcome,
      marksAwarded: (json['marks_awarded'] as num?)?.toDouble() ?? 0.0,
    );
  }
}

/// Persistent record of a completed test attempt, including review snapshot.
class TestHistoryRecord {
  const TestHistoryRecord({
    required this.testId,
    required this.testMode,
    required this.subjects,
    required this.subjectLabel,
    required this.completedAt,
    required this.totalQuestions,
    required this.correctCount,
    required this.incorrectCount,
    required this.unattemptedCount,
    required this.score,
    required this.maxScore,
    required this.accuracyPercent,
    required this.timeTakenSeconds,
    required this.wasAutoSubmitted,
    required this.performanceSummary,
    required this.scoringLabel,
    required this.marksPerCorrect,
    required this.negativeMarkingPerWrong,
    required this.reviewEntries,
  });

  final String testId;
  final TestMode testMode;
  final List<QuestionSubject> subjects;
  final String subjectLabel;
  final DateTime completedAt;
  final int totalQuestions;
  final int correctCount;
  final int incorrectCount;
  final int unattemptedCount;
  final double score;
  final double maxScore;
  final double accuracyPercent;
  final int timeTakenSeconds;
  final bool wasAutoSubmitted;
  final String performanceSummary;
  final String scoringLabel;
  final double marksPerCorrect;
  final double negativeMarkingPerWrong;
  final List<SavedReviewEntry> reviewEntries;

  int get attemptedCount => correctCount + incorrectCount;

  /// Reconstructs a full [QuizResult] so the user can reopen past results
  /// and review every answer and explanation.
  QuizResult toQuizResult() {
    return QuizResult(
      config: QuizConfig(
        mode: testMode,
        subjects: subjects,
        questionCount: totalQuestions,
        scoringRules: ScoringRules(
          marksPerCorrect: marksPerCorrect,
          negativeMarkingPerWrong: negativeMarkingPerWrong,
          label: scoringLabel,
        ),
      ),
      totalQuestions: totalQuestions,
      correctCount: correctCount,
      incorrectCount: incorrectCount,
      unattemptedCount: unattemptedCount,
      totalScore: score,
      maxScore: maxScore,
      accuracyPercent: accuracyPercent,
      timeTakenSeconds: timeTakenSeconds,
      wasAutoSubmitted: wasAutoSubmitted,
      performanceSummary: performanceSummary,
      reviewItems: reviewEntries
          .map((SavedReviewEntry e) => e.toReviewItem())
          .toList(growable: false),
    );
  }

  Map<String, Object?> toDbRow() {
    return <String, Object?>{
      'test_id': testId,
      'test_mode': testMode.id,
      'subjects_json':
          jsonEncode(subjects.map((QuestionSubject s) => s.id).toList()),
      'subject_label': subjectLabel,
      'completed_at': completedAt.toUtc().toIso8601String(),
      'total_questions': totalQuestions,
      'correct_count': correctCount,
      'incorrect_count': incorrectCount,
      'unattempted_count': unattemptedCount,
      'score': score,
      'max_score': maxScore,
      'accuracy_percent': accuracyPercent,
      'time_taken_seconds': timeTakenSeconds,
      'was_auto_submitted': wasAutoSubmitted ? 1 : 0,
      'performance_summary': performanceSummary,
      'scoring_label': scoringLabel,
      'marks_per_correct': marksPerCorrect,
      'negative_marking_per_wrong': negativeMarkingPerWrong,
      'review_json': jsonEncode(
        reviewEntries.map((SavedReviewEntry e) => e.toJson()).toList(),
      ),
    };
  }

  factory TestHistoryRecord.fromDbRow(Map<String, Object?> row) {
    final String modeId = (row['test_mode'] ?? 'practice').toString();
    final TestMode mode = TestMode.values.firstWhere(
      (TestMode m) => m.id == modeId,
      orElse: () => TestMode.practice,
    );

    final List<dynamic> rawSubjects =
        jsonDecode((row['subjects_json'] ?? '[]').toString()) as List<dynamic>;
    final List<QuestionSubject> parsedSubjects = <QuestionSubject>[];
    for (final dynamic item in rawSubjects) {
      try {
        parsedSubjects.add(QuestionSubject.fromId(item.toString()));
      } catch (_) {
        // Ignore unknown legacy subject IDs safely.
      }
    }

    final List<dynamic> rawReview =
        jsonDecode((row['review_json'] ?? '[]').toString()) as List<dynamic>;
    final List<SavedReviewEntry> parsedReview = rawReview
        .whereType<Map<dynamic, dynamic>>()
        .map(
          (Map<dynamic, dynamic> m) => SavedReviewEntry.fromJson(
            m.map(
              (dynamic k, dynamic v) => MapEntry<String, Object?>(
                k.toString(),
                v,
              ),
            ),
          ),
        )
        .toList(growable: false);

    return TestHistoryRecord(
      testId: (row['test_id'] ?? '').toString(),
      testMode: mode,
      subjects: parsedSubjects,
      subjectLabel: (row['subject_label'] ?? 'Mixed GK').toString(),
      completedAt: DateTime.parse((row['completed_at'] ?? '').toString()),
      totalQuestions: (row['total_questions'] as num?)?.toInt() ?? 0,
      correctCount: (row['correct_count'] as num?)?.toInt() ?? 0,
      incorrectCount: (row['incorrect_count'] as num?)?.toInt() ?? 0,
      unattemptedCount: (row['unattempted_count'] as num?)?.toInt() ?? 0,
      score: (row['score'] as num?)?.toDouble() ?? 0.0,
      maxScore: (row['max_score'] as num?)?.toDouble() ?? 0.0,
      accuracyPercent: (row['accuracy_percent'] as num?)?.toDouble() ?? 0.0,
      timeTakenSeconds: (row['time_taken_seconds'] as num?)?.toInt() ?? 0,
      wasAutoSubmitted: (row['was_auto_submitted'] as num?)?.toInt() == 1,
      performanceSummary: (row['performance_summary'] ?? '').toString(),
      scoringLabel:
          (row['scoring_label'] ?? ScoringRules.noNegative.label).toString(),
      marksPerCorrect: (row['marks_per_correct'] as num?)?.toDouble() ?? 1.0,
      negativeMarkingPerWrong:
          (row['negative_marking_per_wrong'] as num?)?.toDouble() ?? 0.0,
      reviewEntries: parsedReview,
    );
  }
}

/// Persistent bookmark row linked to a unique Question ID.
class BookmarkedQuestionRecord {
  const BookmarkedQuestionRecord({
    required this.questionId,
    required this.subject,
    required this.savedAt,
  });

  final String questionId;
  final QuestionSubject subject;
  final DateTime savedAt;

  Map<String, Object?> toDbRow() {
    return <String, Object?>{
      'question_id': questionId,
      'subject': subject.id,
      'saved_at': savedAt.toUtc().toIso8601String(),
    };
  }

  factory BookmarkedQuestionRecord.fromDbRow(Map<String, Object?> row) {
    return BookmarkedQuestionRecord(
      questionId: (row['question_id'] ?? '').toString(),
      subject: QuestionSubject.fromId((row['subject'] ?? 'static_gk').toString()),
      savedAt: DateTime.parse((row['saved_at'] ?? '').toString()),
    );
  }
}

/// Bookmark record resolved with its full Question entity from the Question Bank.
class ResolvedBookmark {
  const ResolvedBookmark({
    required this.record,
    required this.question,
  });

  final BookmarkedQuestionRecord record;
  final Question question;
}

/// Persistent wrong-answer revision tracking record for a unique Question ID.
class WrongAnswerRecord {
  const WrongAnswerRecord({
    required this.questionId,
    required this.subject,
    required this.wrongCount,
    required this.revisionAttempts,
    required this.isMastered,
    required this.lastWrongAt,
    this.lastRevisedAt,
    this.masteredAt,
  });

  final String questionId;
  final QuestionSubject subject;
  final int wrongCount;
  final int revisionAttempts;
  final bool isMastered;
  final DateTime lastWrongAt;
  final DateTime? lastRevisedAt;
  final DateTime? masteredAt;

  WrongAnswerRecord copyWith({
    int? wrongCount,
    int? revisionAttempts,
    bool? isMastered,
    DateTime? lastWrongAt,
    DateTime? lastRevisedAt,
    DateTime? masteredAt,
    bool clearMasteredAt = false,
  }) {
    return WrongAnswerRecord(
      questionId: questionId,
      subject: subject,
      wrongCount: wrongCount ?? this.wrongCount,
      revisionAttempts: revisionAttempts ?? this.revisionAttempts,
      isMastered: isMastered ?? this.isMastered,
      lastWrongAt: lastWrongAt ?? this.lastWrongAt,
      lastRevisedAt: lastRevisedAt ?? this.lastRevisedAt,
      masteredAt: clearMasteredAt ? null : (masteredAt ?? this.masteredAt),
    );
  }

  Map<String, Object?> toDbRow() {
    return <String, Object?>{
      'question_id': questionId,
      'subject': subject.id,
      'wrong_count': wrongCount,
      'revision_attempts': revisionAttempts,
      'is_mastered': isMastered ? 1 : 0,
      'last_wrong_at': lastWrongAt.toUtc().toIso8601String(),
      'last_revised_at': lastRevisedAt?.toUtc().toIso8601String(),
      'mastered_at': masteredAt?.toUtc().toIso8601String(),
    };
  }

  factory WrongAnswerRecord.fromDbRow(Map<String, Object?> row) {
    final String? revisedRaw = row['last_revised_at']?.toString();
    final String? masteredRaw = row['mastered_at']?.toString();
    return WrongAnswerRecord(
      questionId: (row['question_id'] ?? '').toString(),
      subject: QuestionSubject.fromId((row['subject'] ?? 'static_gk').toString()),
      wrongCount: (row['wrong_count'] as num?)?.toInt() ?? 1,
      revisionAttempts: (row['revision_attempts'] as num?)?.toInt() ?? 0,
      isMastered: (row['is_mastered'] as num?)?.toInt() == 1,
      lastWrongAt: DateTime.parse((row['last_wrong_at'] ?? '').toString()),
      lastRevisedAt: (revisedRaw != null && revisedRaw.isNotEmpty)
          ? DateTime.parse(revisedRaw)
          : null,
      masteredAt: (masteredRaw != null && masteredRaw.isNotEmpty)
          ? DateTime.parse(masteredRaw)
          : null,
    );
  }
}

/// Wrong answer record paired with its full Question from the Question Bank.
class ResolvedWrongAnswer {
  const ResolvedWrongAnswer({
    required this.record,
    required this.question,
  });

  final WrongAnswerRecord record;
  final Question question;
}

/// Real subject-wise performance analytics calculated from stored history.
class SubjectAnalytics {
  const SubjectAnalytics({
    required this.subject,
    required this.testsAttempted,
    required this.questionsPracticed,
    required this.correctCount,
    required this.incorrectCount,
    required this.unattemptedCount,
    required this.accuracyPercent,
    required this.pendingWrongCount,
    required this.masteredWrongCount,
  });

  final QuestionSubject subject;
  final int testsAttempted;
  final int questionsPracticed;
  final int correctCount;
  final int incorrectCount;
  final int unattemptedCount;
  final double accuracyPercent;
  final int pendingWrongCount;
  final int masteredWrongCount;

  bool get hasActivity => testsAttempted > 0 || questionsPracticed > 0;

  bool get needsRevision =>
      hasActivity && (pendingWrongCount > 0 || accuracyPercent < 60.0);
}

/// Optional, pressure-free daily learning goal preference.
class DailyLearningGoal {
  const DailyLearningGoal({
    required this.isEnabled,
    required this.dailyQuestionTarget,
    required this.updatedAt,
  });

  final bool isEnabled;
  final int dailyQuestionTarget;
  final DateTime updatedAt;

  static DailyLearningGoal defaultGoal() => DailyLearningGoal(
        isEnabled: false,
        dailyQuestionTarget: 10,
        updatedAt: DateTime.now().toUtc(),
      );

  DailyLearningGoal copyWith({
    bool? isEnabled,
    int? dailyQuestionTarget,
    DateTime? updatedAt,
  }) {
    return DailyLearningGoal(
      isEnabled: isEnabled ?? this.isEnabled,
      dailyQuestionTarget: dailyQuestionTarget ?? this.dailyQuestionTarget,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, Object?> toDbRow() {
    return <String, Object?>{
      'id': 1,
      'is_enabled': isEnabled ? 1 : 0,
      'daily_question_target': dailyQuestionTarget,
      'updated_at': updatedAt.toUtc().toIso8601String(),
    };
  }

  factory DailyLearningGoal.fromDbRow(Map<String, Object?> row) {
    return DailyLearningGoal(
      isEnabled: (row['is_enabled'] as num?)?.toInt() == 1,
      dailyQuestionTarget:
          (row['daily_question_target'] as num?)?.toInt() ?? 10,
      updatedAt: DateTime.parse(
        (row['updated_at'] ?? DateTime.now().toUtc().toIso8601String())
            .toString(),
      ),
    );
  }
}

/// Complete real-data summary powering the Student Dashboard & Profile screens.
class StudentDashboardSummary {
  const StudentDashboardSummary({
    required this.totalTestsAttempted,
    required this.totalQuestionsAttempted,
    required this.totalCorrect,
    required this.totalIncorrect,
    required this.totalUnattempted,
    required this.overallAccuracyPercent,
    required this.totalTimeSpentSeconds,
    required this.todayQuestionsAttempted,
    required this.todayTestsAttempted,
    required this.bookmarksCount,
    required this.pendingWrongAnswersCount,
    required this.masteredWrongAnswersCount,
    required this.dailyGoal,
    required this.subjectAnalytics,
    required this.recentTests,
  });

  final int totalTestsAttempted;
  final int totalQuestionsAttempted;
  final int totalCorrect;
  final int totalIncorrect;
  final int totalUnattempted;
  final double overallAccuracyPercent;
  final int totalTimeSpentSeconds;
  final int todayQuestionsAttempted;
  final int todayTestsAttempted;
  final int bookmarksCount;
  final int pendingWrongAnswersCount;
  final int masteredWrongAnswersCount;
  final DailyLearningGoal dailyGoal;
  final List<SubjectAnalytics> subjectAnalytics;
  final List<TestHistoryRecord> recentTests;

  bool get hasActivity => totalTestsAttempted > 0;

  double get dailyGoalProgress {
    if (!dailyGoal.isEnabled || dailyGoal.dailyQuestionTarget <= 0) return 0.0;
    final double ratio =
        todayQuestionsAttempted / dailyGoal.dailyQuestionTarget;
    if (ratio < 0.0) return 0.0;
    if (ratio > 1.0) return 1.0;
    return ratio;
  }

  bool get isDailyGoalMet =>
      dailyGoal.isEnabled &&
      todayQuestionsAttempted >= dailyGoal.dailyQuestionTarget;

  List<SubjectAnalytics> get subjectsNeedingRevision => subjectAnalytics
      .where((SubjectAnalytics s) => s.needsRevision)
      .toList(growable: false);
}
