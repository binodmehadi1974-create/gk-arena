import 'package:flutter/material.dart';
import 'package:gk_arena/features/learning/models/learning_models.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/features/quiz/services/quiz_environment.dart';
import 'package:gk_arena/features/quiz/ui/screens/quiz_screen.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/navigation/smooth_page_route.dart';
import 'package:gk_arena/ui/screens/explore/widgets/category_filter_bar.dart';
import 'package:gk_arena/ui/widgets/premium_button.dart';
import 'package:gk_arena/ui/widgets/state_views.dart';

/// Dedicated Wrong Answer Revision screen collecting missed questions from
/// completed tests, supporting subject filtering, direct retry via QuizScreen,
/// and automatic/manual mastered tracking.
class WrongAnswerRevisionScreen extends StatefulWidget {
  const WrongAnswerRevisionScreen({
    super.key,
    required this.environment,
  });

  final QuizEnvironment environment;

  @override
  State<WrongAnswerRevisionScreen> createState() =>
      _WrongAnswerRevisionScreenState();
}

class _WrongAnswerRevisionScreenState extends State<WrongAnswerRevisionScreen> {
  static const String _allFilter = 'All';

  late final List<String> _subjectFilters = <String>[
    _allFilter,
    ...QuestionSubject.values.map((QuestionSubject s) => s.titleEn),
  ];

  String _selectedSubjectLabel = _allFilter;
  bool _includeMastered = false;
  bool _loading = true;
  List<ResolvedWrongAnswer> _items = const <ResolvedWrongAnswer>[];

  @override
  void initState() {
    super.initState();
    widget.environment.learningRepository.addListener(_onLearningChanged);
    _loadWrongAnswers();
  }

  @override
  void dispose() {
    widget.environment.learningRepository.removeListener(_onLearningChanged);
    super.dispose();
  }

  void _onLearningChanged() {
    _loadWrongAnswers();
  }

  QuestionSubject? get _selectedSubject {
    if (_selectedSubjectLabel == _allFilter) return null;
    for (final QuestionSubject subject in QuestionSubject.values) {
      if (subject.titleEn == _selectedSubjectLabel) return subject;
    }
    return null;
  }

  Future<void> _loadWrongAnswers() async {
    await widget.environment.ensureInitialized();
    final List<ResolvedWrongAnswer> items =
        await widget.environment.learningRepository.getResolvedWrongAnswers(
      subject: _selectedSubject,
      includeMastered: _includeMastered,
    );
    if (!mounted) return;
    setState(() {
      _items = items;
      _loading = false;
    });
  }

  void _practiceWrongQuestions() {
    final List<Question> pendingQuestions = _items
        .where((ResolvedWrongAnswer e) => !e.record.isMastered)
        .map((ResolvedWrongAnswer e) => e.question)
        .toList(growable: false);

    final List<Question> pool = pendingQuestions.isNotEmpty
        ? pendingQuestions
        : _items.map((ResolvedWrongAnswer e) => e.question).toList(growable: false);

    if (pool.isEmpty) return;

    final Set<QuestionSubject> subjects =
        pool.map((Question q) => q.subject).toSet();

    Navigator.of(context).push(
      SmoothPageRoute<void>(
        builder: (_) => QuizScreen(
          config: QuizConfig(
            mode: TestMode.practice,
            subjects: subjects.toList(growable: false),
            questionCount: pool.length,
            scoringRules: ScoringRules.noNegative,
            allowRepeatRecent: true,
          ),
          questions: pool,
          environment: widget.environment,
        ),
      ),
    );
  }

  Future<void> _markMastered(String questionId) async {
    await widget.environment.learningRepository
        .markWrongAnswerMastered(questionId);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        duration: Duration(seconds: 1),
        content: Text('प्रश्न को Mastered के रूप में चिह्नित किया गया।'),
      ),
    );
  }

  void _showQuestionDetail(ResolvedWrongAnswer item) {
    const List<String> labels = <String>['A', 'B', 'C', 'D'];
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surfaceOf(context),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(AppSpacing.radiusXl),
        ),
      ),
      builder: (BuildContext sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Text(
                        item.question.subject.titleEn,
                        style: AppTextStyles.badgeLabel.copyWith(
                          color: AppColors.primary,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () => Navigator.of(sheetContext).pop(),
                        icon: const Icon(Icons.close_rounded),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.xs),
                  Text(
                    item.question.questionText,
                    style: AppTextStyles.bodyPrimary.copyWith(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  ...List<Widget>.generate(
                    item.question.options.length,
                    (int i) {
                      final bool isCorrect =
                          i == item.question.correctOptionIndex;
                      return Container(
                        width: double.infinity,
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 10,
                        ),
                        decoration: BoxDecoration(
                          color: isCorrect
                              ? AppColors.softGreenSurface
                              : AppColors.background,
                          borderRadius:
                              BorderRadius.circular(AppSpacing.radiusSm),
                          border: Border.all(
                            color:
                                isCorrect ? AppColors.success : AppColors.border,
                          ),
                        ),
                        child: Text(
                          '${labels[i]}. ${item.question.options[i]}',
                          style: AppTextStyles.bodyPrimary.copyWith(
                            fontWeight:
                                isCorrect ? FontWeight.w600 : FontWeight.w500,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: AppSpacing.xs),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(AppSpacing.sm),
                    decoration: BoxDecoration(
                      color: AppColors.softBlueSurface,
                      borderRadius: BorderRadius.circular(AppSpacing.radiusSm),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        const Text(
                          'व्याख्या / Explanation',
                          style: AppTextStyles.badgeLabel,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          item.question.explanation,
                          style: AppTextStyles.body.copyWith(
                            color: AppColors.textPrimary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final int pendingCount =
        _items.where((ResolvedWrongAnswer e) => !e.record.isMastered).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Wrong Answer Revision'),
      ),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(
                20,
                AppSpacing.xs,
                20,
                AppSpacing.xs,
              ),
              child: CategoryFilterBar(
                categories: _subjectFilters,
                selectedCategory: _selectedSubjectLabel,
                onSelected: (String value) {
                  setState(() {
                    _selectedSubjectLabel = value;
                    _loading = true;
                  });
                  _loadWrongAnswers();
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: <Widget>[
                  FilterChip(
                    label: const Text('Show Mastered'),
                    selected: _includeMastered,
                    onSelected: (bool selected) {
                      setState(() {
                        _includeMastered = selected;
                        _loading = true;
                      });
                      _loadWrongAnswers();
                    },
                  ),
                  const Spacer(),
                  if (_items.isNotEmpty)
                    Text(
                      '$pendingCount pending',
                      style: AppTextStyles.cardSubtitle,
                    ),
                ],
              ),
            ),
            if (!_loading && _items.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  20,
                  AppSpacing.xs,
                  20,
                  AppSpacing.sm,
                ),
                child: PremiumButton(
                  label: pendingCount > 0
                      ? 'Retry Wrong Questions ($pendingCount)'
                      : 'Practice Again (${_items.length})',
                  variant: PremiumButtonVariant.primary,
                  trailingIcon: Icons.replay_rounded,
                  fullWidth: true,
                  onPressed: _practiceWrongQuestions,
                ),
              ),
            Expanded(
              child: _loading
                  ? const Padding(
                    padding: EdgeInsets.all(20),
                    child: GkLoadingPlaceholderCard(lineCount: 4),
                  )
                  : _items.isEmpty
                      ? Padding(
                          padding: const EdgeInsets.all(20),
                          child: GkEmptyStateCard(
                            icon: Icons.check_circle_outline_rounded,
                            badgeText: 'All Caught Up',
                            title: 'रिवीजन के लिए कोई गलत उत्तर लंबित नहीं है',
                            description:
                                'टेस्ट के दौरान गलत हुए प्रश्न यहाँ स्वतः जुड़ जाएंगे। सही अभ्यास के बाद वे Mastered के रूप में अपडेट हो जाएंगे।',
                            actionLabel: 'वापस जाएं',
                            onActionTap: () => Navigator.of(context).pop(),
                          ),
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(
                            20,
                            AppSpacing.xs,
                            20,
                            AppSpacing.lg,
                          ),
                          itemCount: _items.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: AppSpacing.md),
                          itemBuilder: (BuildContext context, int index) {
                            final ResolvedWrongAnswer item = _items[index];
                            return _WrongAnswerCard(
                              item: item,
                              onTap: () => _showQuestionDetail(item),
                              onMarkMastered: item.record.isMastered
                                  ? null
                                  : () => _markMastered(item.question.id),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WrongAnswerCard extends StatelessWidget {
  const _WrongAnswerCard({
    required this.item,
    required this.onTap,
    this.onMarkMastered,
  });

  final ResolvedWrongAnswer item;
  final VoidCallback onTap;
  final VoidCallback? onMarkMastered;

  @override
  Widget build(BuildContext context) {
    final bool mastered = item.record.isMastered;
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceOf(context),
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        border: Border.all(color: AppColors.borderOf(context), width: 1),
        boxShadow: AppSpacing.softCardShadow,
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.md),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.softBlueSurface,
                        borderRadius:
                            BorderRadius.circular(AppSpacing.radiusPill),
                      ),
                      child: Text(
                        item.question.subject.titleEn,
                        style: AppTextStyles.badgeLabel.copyWith(
                          color: AppColors.primary,
                        ),
                      ),
                    ),
                    const SizedBox(width: AppSpacing.xs),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: mastered
                            ? AppColors.softGreenSurface
                            : const Color(0xFFFDECEC),
                        borderRadius:
                            BorderRadius.circular(AppSpacing.radiusPill),
                      ),
                      child: Text(
                        mastered ? 'Mastered' : 'Needs Revision',
                        style: AppTextStyles.badgeLabel.copyWith(
                          color: mastered
                              ? AppColors.success
                              : const Color(0xFFD64545),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppSpacing.sm),
                Text(
                  item.question.questionText,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.bodyPrimary.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: AppSpacing.sm),
                Row(
                  children: <Widget>[
                    Text(
                      'Missed ${item.record.wrongCount}x  •  Revised ${item.record.revisionAttempts}x',
                      style: AppTextStyles.cardSubtitle,
                    ),
                    const Spacer(),
                    if (onMarkMastered != null)
                      TextButton(
                        onPressed: onMarkMastered,
                        child: const Text(
                          'Mark Mastered',
                          style: AppTextStyles.linkAction,
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
