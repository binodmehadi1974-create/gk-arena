import 'package:flutter/material.dart';
import 'package:gk_arena/features/learning/models/learning_models.dart';
import 'package:gk_arena/features/quiz/services/quiz_environment.dart';
import 'package:gk_arena/features/quiz/ui/screens/quiz_result_screen.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/navigation/smooth_page_route.dart';
import 'package:gk_arena/ui/widgets/state_views.dart';

/// Persistent Test History screen listing all completed attempts and allowing
/// students to reopen previous results and review answers.
class TestHistoryScreen extends StatefulWidget {
  const TestHistoryScreen({
    super.key,
    required this.environment,
  });

  final QuizEnvironment environment;

  @override
  State<TestHistoryScreen> createState() => _TestHistoryScreenState();
}

class _TestHistoryScreenState extends State<TestHistoryScreen> {
  bool _loading = true;
  String? _loadError;
  List<TestHistoryRecord> _records = const <TestHistoryRecord>[];

  @override
  void initState() {
    super.initState();
    widget.environment.learningRepository.addListener(_onLearningChanged);
    _loadHistory();
  }

  @override
  void dispose() {
    widget.environment.learningRepository.removeListener(_onLearningChanged);
    super.dispose();
  }

  void _onLearningChanged() {
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    try {
      await widget.environment.ensureInitialized();
      final List<TestHistoryRecord> items =
          await widget.environment.learningRepository.getTestHistory();
      if (!mounted) return;
      setState(() {
        _records = items;
        _loadError = null;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loadError = 'टेस्ट इतिहास लोड करने में समस्या आई। कृपया पुनः प्रयास करें।';
        _loading = false;
      });
    }
  }

  String _formatDateTime(DateTime utcDate) {
    final DateTime local = utcDate.toLocal();
    const List<String> months = <String>[
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    final String hh = local.hour.toString().padLeft(2, '0');
    final String mm = local.minute.toString().padLeft(2, '0');
    return '${local.day} ${months[local.month - 1]} ${local.year} • $hh:$mm';
  }

  String _formatDuration(int seconds) {
    final int mins = seconds ~/ 60;
    final int secs = seconds % 60;
    if (mins == 0) return '${secs}s';
    return '${mins}m ${secs}s';
  }

  void _openResult(TestHistoryRecord record) {
    Navigator.of(context).push(
      SmoothPageRoute<void>(
        builder: (_) => QuizResultScreen(
          result: record.toQuizResult(),
          environment: widget.environment,
          isHistoricalView: true,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Test History'),
      ),
      body: SafeArea(
        child: _loading
            ? const Padding(
                padding: EdgeInsets.all(20),
                child: GkLoadingPlaceholderCard(lineCount: 4),
              )
            : _loadError != null
                ? Padding(
                    padding: const EdgeInsets.all(20),
                    child: GkErrorRetryCard(
                      title: 'डेटा लोड नहीं हो सका',
                      message: _loadError!,
                      retryLabel: 'पुनः प्रयास करें',
                      onRetry: () {
                        setState(() {
                          _loading = true;
                          _loadError = null;
                        });
                        _loadHistory();
                      },
                    ),
                  )
            : _records.isEmpty
                ? Padding(
                    padding: const EdgeInsets.all(20),
                    child: GkEmptyStateCard(
                      icon: Icons.history_rounded,
                      badgeText: 'No Tests Yet',
                      title: 'अभी कोई टेस्ट इतिहास उपलब्ध नहीं है',
                      description:
                          'जब आप कोई भी क्विज़ या मॉक टेस्ट पूरा करेंगे, उसका स्कोर, सटीकता और उत्तर समीक्षा यहाँ सुरक्षित रहेगी।',
                      actionLabel: 'वापस जाएं',
                      onActionTap: () => Navigator.of(context).pop(),
                    ),
                  )
                : RefreshIndicator(
                    onRefresh: _loadHistory,
                    child: ListView.separated(
                      padding: const EdgeInsets.fromLTRB(
                        20,
                        AppSpacing.sm,
                        20,
                        AppSpacing.lg,
                      ),
                      itemCount: _records.length,
                      separatorBuilder: (_, __) =>
                          const SizedBox(height: AppSpacing.md),
                      itemBuilder: (BuildContext context, int index) {
                        final TestHistoryRecord record = _records[index];
                        return _HistoryCard(
                          record: record,
                          dateText: _formatDateTime(record.completedAt),
                          durationText: _formatDuration(record.timeTakenSeconds),
                          onTap: () => _openResult(record),
                        );
                      },
                    ),
                  ),
      ),
    );
  }
}

class _HistoryCard extends StatelessWidget {
  const _HistoryCard({
    required this.record,
    required this.dateText,
    required this.durationText,
    required this.onTap,
  });

  final TestHistoryRecord record;
  final String dateText;
  final String durationText;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final bool goodAccuracy = record.accuracyPercent >= 70.0;
    final Color badgeBg =
        goodAccuracy ? AppColors.softGreenSurface : AppColors.softAmberSurface;
    final Color badgeFg =
        goodAccuracy ? AppColors.success : AppColors.warning;

    return Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceOf(context),
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        border: Border.all(color: AppColors.borderOf(context), width: 1),
        boxShadow: AppSpacing.softCardShadow,
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.md),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Expanded(
                      child: Text(
                        record.testMode.titleEn,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTextStyles.cardTitle,
                      ),
                    ),
                    const SizedBox(width: AppSpacing.xs),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: badgeBg,
                        borderRadius:
                            BorderRadius.circular(AppSpacing.radiusPill),
                      ),
                      child: Text(
                        '${record.accuracyPercent}% Acc',
                        style:
                            AppTextStyles.badgeLabel.copyWith(color: badgeFg),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  '${record.subjectLabel}  •  $dateText',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.cardSubtitle,
                ),
                const SizedBox(height: AppSpacing.sm),
                Wrap(
                  spacing: AppSpacing.xs,
                  runSpacing: AppSpacing.xs,
                  children: <Widget>[
                    _StatChip(
                      label: 'Score ${record.score}/${record.maxScore}',
                      color: AppColors.primary,
                      background: AppColors.softBlueSurface,
                    ),
                    _StatChip(
                      label: 'Correct ${record.correctCount}',
                      color: AppColors.success,
                      background: AppColors.softGreenSurface,
                    ),
                    _StatChip(
                      label: 'Wrong ${record.incorrectCount}',
                      color: const Color(0xFFD64545),
                      background: const Color(0xFFFDECEC),
                    ),
                    _StatChip(
                      label: 'Skipped ${record.unattemptedCount}',
                      color: AppColors.textSecondary,
                      background: AppColors.background,
                    ),
                    _StatChip(
                      label: durationText,
                      color: AppColors.deepNavy,
                      background: AppColors.softIndigoSurface,
                    ),
                  ],
                ),
                const SizedBox(height: AppSpacing.sm),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Text(
                      'Open Result & Review',
                      style: AppTextStyles.linkAction,
                    ),
                    SizedBox(width: 4),
                    Icon(
                      Icons.arrow_forward_rounded,
                      size: 16,
                      color: AppColors.primary,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  const _StatChip({
    required this.label,
    required this.color,
    required this.background,
  });

  final String label;
  final Color color;
  final Color background;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(AppSpacing.radiusSm),
      ),
      child: Text(
        label,
        style: AppTextStyles.badgeLabel.copyWith(color: color),
      ),
    );
  }
}
