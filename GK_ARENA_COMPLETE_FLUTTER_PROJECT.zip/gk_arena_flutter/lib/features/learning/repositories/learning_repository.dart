import 'package:flutter/foundation.dart';
import 'package:gk_arena/features/learning/database/learning_data_source.dart';
import 'package:gk_arena/features/learning/models/learning_models.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';

/// Central service/repository managing Test History, Bookmarks, Wrong Answer
/// Revision, Subject-wise Analytics, and optional Daily Learning Goals using
/// real stored data only.
class LearningRepository extends ChangeNotifier {
  LearningRepository({
    required this.dataSource,
    required this.questionRepository,
    DateTime Function()? clock,
  }) : _clock = clock ?? DateTime.now;

  final LearningDataSource dataSource;
  final QuestionRepository questionRepository;
  final DateTime Function() _clock;
  int _idSequence = 0;
  StudentDashboardSummary? _cachedDashboardSummary;

  Future<void> initialize() => dataSource.initialize();

  Future<void> close() => dataSource.close();

  /// Persists a completed test result, collects incorrect answers into the
  /// wrong-answer revision pool, and updates mastery when previously wrong
  /// questions are answered correctly.
  Future<TestHistoryRecord> recordCompletedTest(
    QuizResult result, {
    String? customTestId,
    DateTime? completedAt,
  }) async {
    final DateTime now = (completedAt ?? _clock()).toUtc();
    _idSequence++;
    final String testId = customTestId ??
        'test_${now.microsecondsSinceEpoch}_$_idSequence';

    final Set<QuestionSubject> detectedSubjects = <QuestionSubject>{
      ...result.config.subjects,
      for (final QuestionReviewItem item in result.reviewItems)
        item.question.subject,
    };
    final List<QuestionSubject> subjectList =
        detectedSubjects.toList(growable: false);

    final String subjectLabel = _buildSubjectLabel(
      subjectList,
      result.config.mode,
    );

    final TestHistoryRecord record = TestHistoryRecord(
      testId: testId,
      testMode: result.config.mode,
      subjects: subjectList,
      subjectLabel: subjectLabel,
      completedAt: now,
      totalQuestions: result.totalQuestions,
      correctCount: result.correctCount,
      incorrectCount: result.incorrectCount,
      unattemptedCount: result.unattemptedCount,
      score: result.totalScore,
      maxScore: result.maxScore,
      accuracyPercent: result.accuracyPercent,
      timeTakenSeconds: result.timeTakenSeconds,
      wasAutoSubmitted: result.wasAutoSubmitted,
      performanceSummary: result.performanceSummary,
      scoringLabel: result.config.scoringRules.label,
      marksPerCorrect: result.config.scoringRules.marksPerCorrect,
      negativeMarkingPerWrong:
          result.config.scoringRules.negativeMarkingPerWrong,
      reviewEntries: result.reviewItems
          .map(SavedReviewEntry.fromReviewItem)
          .toList(growable: false),
    );

    await dataSource.insertTestHistory(record);

    // Update wrong-answer revision bank from actual item outcomes.
    for (final QuestionReviewItem item in result.reviewItems) {
      final WrongAnswerRecord? existing =
          await dataSource.getWrongAnswer(item.question.id);

      if (item.outcome == AnswerOutcome.incorrect) {
        if (existing == null) {
          await dataSource.upsertWrongAnswer(
            WrongAnswerRecord(
              questionId: item.question.id,
              subject: item.question.subject,
              wrongCount: 1,
              revisionAttempts: 0,
              isMastered: false,
              lastWrongAt: now,
            ),
          );
        } else {
          await dataSource.upsertWrongAnswer(
            existing.copyWith(
              wrongCount: existing.wrongCount + 1,
              revisionAttempts: existing.revisionAttempts + 1,
              isMastered: false,
              lastWrongAt: now,
              lastRevisedAt: now,
              clearMasteredAt: true,
            ),
          );
        }
      } else if (item.outcome == AnswerOutcome.correct && existing != null) {
        await dataSource.upsertWrongAnswer(
          existing.copyWith(
            revisionAttempts: existing.revisionAttempts + 1,
            isMastered: true,
            lastRevisedAt: now,
            masteredAt: now,
          ),
        );
      }
    }

    notifyListeners();
    return record;
  }

  String _buildSubjectLabel(List<QuestionSubject> subjects, TestMode mode) {
    if (subjects.isEmpty) return mode.titleEn;
    if (subjects.length == 1) return subjects.first.titleEn;
    if (subjects.length == 2) {
      return '${subjects[0].titleEn}, ${subjects[1].titleEn}';
    }
    return 'Mixed (${subjects.length} Subjects)';
  }

  // ---------------------------------------------------------------------------
  // Test History
  // ---------------------------------------------------------------------------

  Future<List<TestHistoryRecord>> getTestHistory({int? limit}) {
    return dataSource.getTestHistory(limit: limit);
  }

  Future<TestHistoryRecord?> getTestHistoryById(String testId) {
    return dataSource.getTestHistoryById(testId);
  }

  // ---------------------------------------------------------------------------
  // Bookmarks
  // ---------------------------------------------------------------------------

  /// Saves a bookmark if not already present. Returns true if newly added,
  /// false if it was already bookmarked (prevents duplicates).
  Future<bool> addBookmark(Question question) async {
    final bool inserted = await dataSource.upsertBookmark(
      BookmarkedQuestionRecord(
        questionId: question.id,
        subject: question.subject,
        savedAt: _clock().toUtc(),
      ),
    );
    if (inserted) {
      notifyListeners();
    }
    return inserted;
  }

  Future<void> removeBookmark(String questionId) async {
    await dataSource.deleteBookmark(questionId);
    notifyListeners();
  }

  /// Toggles bookmark state and returns the resulting bookmarked status.
  Future<bool> toggleBookmark(Question question) async {
    final bool exists = await dataSource.isBookmarked(question.id);
    if (exists) {
      await removeBookmark(question.id);
      return false;
    } else {
      await addBookmark(question);
      return true;
    }
  }

  Future<bool> isBookmarked(String questionId) {
    return dataSource.isBookmarked(questionId);
  }

  Future<Set<String>> getBookmarkedQuestionIds() async {
    final List<BookmarkedQuestionRecord> rows = await dataSource.getBookmarks();
    return rows.map((BookmarkedQuestionRecord r) => r.questionId).toSet();
  }

  Future<List<ResolvedBookmark>> getResolvedBookmarks({
    QuestionSubject? subject,
  }) async {
    final List<BookmarkedQuestionRecord> records =
        await dataSource.getBookmarks(subject: subject);
    final Map<String, Question> questionsById = await questionRepository.getByIds(
      records.map((BookmarkedQuestionRecord r) => r.questionId).toList(growable: false),
    );
    final List<ResolvedBookmark> resolved = <ResolvedBookmark>[];
    for (final BookmarkedQuestionRecord record in records) {
      final Question? question = questionsById[record.questionId];
      if (question != null) {
        resolved.add(ResolvedBookmark(record: record, question: question));
      }
    }
    return List<ResolvedBookmark>.unmodifiable(resolved);
  }

  // ---------------------------------------------------------------------------
  // Wrong Answer Revision
  // ---------------------------------------------------------------------------

  Future<List<WrongAnswerRecord>> getWrongAnswerRecords({
    QuestionSubject? subject,
    bool includeMastered = false,
  }) {
    return dataSource.getWrongAnswers(
      subject: subject,
      includeMastered: includeMastered,
    );
  }

  Future<List<ResolvedWrongAnswer>> getResolvedWrongAnswers({
    QuestionSubject? subject,
    bool includeMastered = false,
  }) async {
    final List<WrongAnswerRecord> records = await dataSource.getWrongAnswers(
      subject: subject,
      includeMastered: includeMastered,
    );
    final Map<String, Question> questionsById = await questionRepository.getByIds(
      records.map((WrongAnswerRecord r) => r.questionId).toList(growable: false),
    );
    final List<ResolvedWrongAnswer> resolved = <ResolvedWrongAnswer>[];
    for (final WrongAnswerRecord record in records) {
      final Question? question = questionsById[record.questionId];
      if (question != null) {
        resolved.add(ResolvedWrongAnswer(record: record, question: question));
      }
    }
    return List<ResolvedWrongAnswer>.unmodifiable(resolved);
  }

  Future<void> markWrongAnswerMastered(String questionId) async {
    final WrongAnswerRecord? existing =
        await dataSource.getWrongAnswer(questionId);
    if (existing == null) return;
    final DateTime now = _clock().toUtc();
    await dataSource.upsertWrongAnswer(
      existing.copyWith(
        revisionAttempts: existing.revisionAttempts + 1,
        isMastered: true,
        lastRevisedAt: now,
        masteredAt: now,
      ),
    );
    notifyListeners();
  }

  // ---------------------------------------------------------------------------
  // Optional Daily Learning Goal
  // ---------------------------------------------------------------------------

  Future<DailyLearningGoal> getDailyGoal() => dataSource.getDailyGoal();

  Future<void> saveDailyGoal({
    required bool isEnabled,
    required int dailyQuestionTarget,
  }) async {
    final int safeTarget = dailyQuestionTarget.clamp(5, 200);
    await dataSource.saveDailyGoal(
      DailyLearningGoal(
        isEnabled: isEnabled,
        dailyQuestionTarget: safeTarget,
        updatedAt: _clock().toUtc(),
      ),
    );
    notifyListeners();
  }

  // ---------------------------------------------------------------------------
  // Student Dashboard & Subject-wise Analytics (100% real data)
  // ---------------------------------------------------------------------------

  Future<List<SubjectAnalytics>> getSubjectAnalytics() async {
    final List<TestHistoryRecord> history = await dataSource.getTestHistory();
    final List<WrongAnswerRecord> wrongAnswers =
        await dataSource.getWrongAnswers(includeMastered: true);
    return _computeSubjectAnalytics(history, wrongAnswers);
  }

  @override
  void notifyListeners() {
    _cachedDashboardSummary = null;
    super.notifyListeners();
  }

  Future<StudentDashboardSummary> getDashboardSummary() async {
    if (_cachedDashboardSummary != null) {
      return _cachedDashboardSummary!;
    }
    final List<TestHistoryRecord> history = await dataSource.getTestHistory();
    final List<BookmarkedQuestionRecord> bookmarks =
        await dataSource.getBookmarks();
    final List<WrongAnswerRecord> wrongAnswers =
        await dataSource.getWrongAnswers(includeMastered: true);
    final DailyLearningGoal dailyGoal = await dataSource.getDailyGoal();

    int totalCorrect = 0;
    int totalIncorrect = 0;
    int totalUnattempted = 0;
    int totalTimeSpentSeconds = 0;
    int todayQuestionsAttempted = 0;
    int todayTestsAttempted = 0;

    final DateTime localNow = _clock().toLocal();

    for (final TestHistoryRecord record in history) {
      totalCorrect += record.correctCount;
      totalIncorrect += record.incorrectCount;
      totalUnattempted += record.unattemptedCount;
      totalTimeSpentSeconds += record.timeTakenSeconds;

      final DateTime localCompleted = record.completedAt.toLocal();
      final bool isToday = localCompleted.year == localNow.year &&
          localCompleted.month == localNow.month &&
          localCompleted.day == localNow.day;
      if (isToday) {
        todayTestsAttempted++;
        todayQuestionsAttempted += record.attemptedCount;
      }
    }

    final int totalAttempted = totalCorrect + totalIncorrect;
    final double overallAccuracy = totalAttempted == 0
        ? 0.0
        : _roundToTwo((totalCorrect / totalAttempted) * 100.0);

    final int pendingWrong =
        wrongAnswers.where((WrongAnswerRecord r) => !r.isMastered).length;
    final int masteredWrong =
        wrongAnswers.where((WrongAnswerRecord r) => r.isMastered).length;

    final List<SubjectAnalytics> subjectAnalytics =
        _computeSubjectAnalytics(history, wrongAnswers);

    final StudentDashboardSummary summary = StudentDashboardSummary(
      totalTestsAttempted: history.length,
      totalQuestionsAttempted: totalAttempted,
      totalCorrect: totalCorrect,
      totalIncorrect: totalIncorrect,
      totalUnattempted: totalUnattempted,
      overallAccuracyPercent: overallAccuracy,
      totalTimeSpentSeconds: totalTimeSpentSeconds,
      todayQuestionsAttempted: todayQuestionsAttempted,
      todayTestsAttempted: todayTestsAttempted,
      bookmarksCount: bookmarks.length,
      pendingWrongAnswersCount: pendingWrong,
      masteredWrongAnswersCount: masteredWrong,
      dailyGoal: dailyGoal,
      subjectAnalytics: subjectAnalytics,
      recentTests: history.take(5).toList(growable: false),
    );
    _cachedDashboardSummary = summary;
    return summary;
  }

  List<SubjectAnalytics> _computeSubjectAnalytics(
    List<TestHistoryRecord> history,
    List<WrongAnswerRecord> wrongAnswers,
  ) {
    final Map<QuestionSubject, int> testsBySubject = <QuestionSubject, int>{};
    final Map<QuestionSubject, int> correctBySubject = <QuestionSubject, int>{};
    final Map<QuestionSubject, int> incorrectBySubject =
        <QuestionSubject, int>{};
    final Map<QuestionSubject, int> unattemptedBySubject =
        <QuestionSubject, int>{};
    final Map<QuestionSubject, int> pendingWrongBySubject =
        <QuestionSubject, int>{};
    final Map<QuestionSubject, int> masteredWrongBySubject =
        <QuestionSubject, int>{};

    for (final TestHistoryRecord record in history) {
      final Set<QuestionSubject> subjectsInTest = <QuestionSubject>{};

      if (record.reviewEntries.isNotEmpty) {
        for (final SavedReviewEntry entry in record.reviewEntries) {
          final QuestionSubject subject = entry.question.subject;
          subjectsInTest.add(subject);
          switch (entry.outcome) {
            case AnswerOutcome.correct:
              correctBySubject[subject] = (correctBySubject[subject] ?? 0) + 1;
            case AnswerOutcome.incorrect:
              incorrectBySubject[subject] =
                  (incorrectBySubject[subject] ?? 0) + 1;
            case AnswerOutcome.unattempted:
              unattemptedBySubject[subject] =
                  (unattemptedBySubject[subject] ?? 0) + 1;
          }
        }
      } else if (record.subjects.length == 1) {
        final QuestionSubject subject = record.subjects.first;
        subjectsInTest.add(subject);
        correctBySubject[subject] =
            (correctBySubject[subject] ?? 0) + record.correctCount;
        incorrectBySubject[subject] =
            (incorrectBySubject[subject] ?? 0) + record.incorrectCount;
        unattemptedBySubject[subject] =
            (unattemptedBySubject[subject] ?? 0) + record.unattemptedCount;
      }

      for (final QuestionSubject subject in subjectsInTest) {
        testsBySubject[subject] = (testsBySubject[subject] ?? 0) + 1;
      }
    }

    for (final WrongAnswerRecord wrong in wrongAnswers) {
      if (wrong.isMastered) {
        masteredWrongBySubject[wrong.subject] =
            (masteredWrongBySubject[wrong.subject] ?? 0) + 1;
      } else {
        pendingWrongBySubject[wrong.subject] =
            (pendingWrongBySubject[wrong.subject] ?? 0) + 1;
      }
    }

    return QuestionSubject.values.map((QuestionSubject subject) {
      final int correct = correctBySubject[subject] ?? 0;
      final int incorrect = incorrectBySubject[subject] ?? 0;
      final int unattempted = unattemptedBySubject[subject] ?? 0;
      final int practiced = correct + incorrect;
      final double accuracy = practiced == 0
          ? 0.0
          : _roundToTwo((correct / practiced) * 100.0);
      return SubjectAnalytics(
        subject: subject,
        testsAttempted: testsBySubject[subject] ?? 0,
        questionsPracticed: practiced,
        correctCount: correct,
        incorrectCount: incorrect,
        unattemptedCount: unattempted,
        accuracyPercent: accuracy,
        pendingWrongCount: pendingWrongBySubject[subject] ?? 0,
        masteredWrongCount: masteredWrongBySubject[subject] ?? 0,
      );
    }).toList(growable: false);
  }

  double _roundToTwo(double value) => (value * 100).round() / 100.0;

  /// Clears ONLY personal learning data (test history, bookmarks, wrong-answer
  /// revision progress, and daily goal). Never modifies the Question Bank.
  Future<void> clearAllLearningData() async {
    await dataSource.clearAllLearningData();
    notifyListeners();
  }

  String get activeUserId => dataSource.activeUserId;

  void setActiveUserId(String userId) {
    if (dataSource.activeUserId == userId) return;
    dataSource.setActiveUserId(userId);
    notifyListeners();
  }

  Future<List<BookmarkedQuestionRecord>> getBookmarkRecords({
    QuestionSubject? subject,
  }) {
    return dataSource.getBookmarks(subject: subject);
  }

  Future<void> migrateUserData({
    required String fromUserId,
    required String toUserId,
  }) async {
    await dataSource.migrateUserData(
      fromUserId: fromUserId,
      toUserId: toUserId,
    );
    notifyListeners();
  }

  Future<void> applyMergedBackup({
    required List<TestHistoryRecord> history,
    required List<BookmarkedQuestionRecord> bookmarks,
    required List<WrongAnswerRecord> wrongAnswers,
    required DailyLearningGoal dailyGoal,
  }) async {
    for (final TestHistoryRecord h in history) {
      await dataSource.insertTestHistory(h);
    }
    for (final BookmarkedQuestionRecord b in bookmarks) {
      await dataSource.upsertBookmark(b);
    }
    for (final WrongAnswerRecord w in wrongAnswers) {
      await dataSource.upsertWrongAnswer(w);
    }
    await dataSource.saveDailyGoal(dailyGoal);
    notifyListeners();
  }
}
