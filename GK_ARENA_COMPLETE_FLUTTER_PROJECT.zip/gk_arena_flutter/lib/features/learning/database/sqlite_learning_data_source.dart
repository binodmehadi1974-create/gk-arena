import 'package:gk_arena/features/learning/database/learning_data_source.dart';
import 'package:gk_arena/features/learning/models/learning_models.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// SQLite-backed persistence for Test History, Bookmarks, Wrong Answer Revision,
/// and optional Daily Learning Goals with strict per-user `user_id` isolation
/// (Schema v2 with automatic v1 -> v2 migration).
class SqliteLearningDataSource implements LearningDataSource {
  SqliteLearningDataSource({
    this.databaseName = 'gk_arena_learning.db',
    String initialUserId = LearningDataSource.defaultUserId,
  }) : _activeUserId = initialUserId;

  static const int schemaVersion = 2;
  static const String testHistoryTable = 'test_history';
  static const String bookmarksTable = 'bookmarks';
  static const String wrongAnswersTable = 'wrong_answers';
  static const String learningGoalsTable = 'learning_goals';

  final String databaseName;
  String _activeUserId;
  Database? _db;

  @override
  String get activeUserId => _activeUserId;

  @override
  void setActiveUserId(String userId) {
    _activeUserId =
        userId.trim().isEmpty ? LearningDataSource.defaultUserId : userId.trim();
  }

  Future<Database> _requireDb() async {
    if (_db == null || !_db!.isOpen) {
      await initialize();
    }
    return _db!;
  }

  @override
  Future<void> initialize() async {
    if (_db != null && _db!.isOpen) return;
    final String dbPath = p.join(await getDatabasesPath(), databaseName);
    _db = await openDatabase(
      dbPath,
      version: schemaVersion,
      onConfigure: (Database db) async {
        await db.rawQuery('PRAGMA journal_mode = WAL');
        await db.execute('PRAGMA synchronous = FULL');
      },
      onCreate: (Database db, int version) async {
        await db.execute('''
          CREATE TABLE $testHistoryTable (
            user_id TEXT NOT NULL,
            test_id TEXT NOT NULL,
            test_mode TEXT NOT NULL,
            subjects_json TEXT NOT NULL,
            subject_label TEXT NOT NULL,
            completed_at TEXT NOT NULL,
            total_questions INTEGER NOT NULL,
            correct_count INTEGER NOT NULL,
            incorrect_count INTEGER NOT NULL,
            unattempted_count INTEGER NOT NULL,
            score REAL NOT NULL,
            max_score REAL NOT NULL,
            accuracy_percent REAL NOT NULL,
            time_taken_seconds INTEGER NOT NULL,
            was_auto_submitted INTEGER NOT NULL,
            performance_summary TEXT NOT NULL,
            scoring_label TEXT NOT NULL,
            marks_per_correct REAL NOT NULL,
            negative_marking_per_wrong REAL NOT NULL,
            review_json TEXT NOT NULL,
            PRIMARY KEY (user_id, test_id)
          )
        ''');

        await db.execute('''
          CREATE TABLE $bookmarksTable (
            user_id TEXT NOT NULL,
            question_id TEXT NOT NULL,
            subject TEXT NOT NULL,
            saved_at TEXT NOT NULL,
            PRIMARY KEY (user_id, question_id)
          )
        ''');

        await db.execute('''
          CREATE TABLE $wrongAnswersTable (
            user_id TEXT NOT NULL,
            question_id TEXT NOT NULL,
            subject TEXT NOT NULL,
            wrong_count INTEGER NOT NULL,
            revision_attempts INTEGER NOT NULL,
            is_mastered INTEGER NOT NULL,
            last_wrong_at TEXT NOT NULL,
            last_revised_at TEXT,
            mastered_at TEXT,
            PRIMARY KEY (user_id, question_id)
          )
        ''');

        await db.execute('''
          CREATE TABLE $learningGoalsTable (
            user_id TEXT PRIMARY KEY,
            is_enabled INTEGER NOT NULL,
            daily_question_target INTEGER NOT NULL,
            updated_at TEXT NOT NULL
          )
        ''');

        await db.execute(
          'CREATE INDEX idx_history_user_completed ON $testHistoryTable(user_id, completed_at DESC)',
        );
        await db.execute(
          'CREATE INDEX idx_bookmarks_user_subject ON $bookmarksTable(user_id, subject, saved_at DESC)',
        );
        await db.execute(
          'CREATE INDEX idx_wrong_user_subject_mastered ON $wrongAnswersTable(user_id, subject, is_mastered)',
        );
      },
      onUpgrade: (Database db, int oldVersion, int newVersion) async {
        if (oldVersion < 2) {
          // Rebuild tables cleanly to migrate single-column PKs to composite (user_id, ...) PKs
          await db.transaction((Transaction txn) async {
            const String guest = LearningDataSource.defaultUserId;

            await txn.execute('''
              CREATE TABLE ${testHistoryTable}_v2 (
                user_id TEXT NOT NULL,
                test_id TEXT NOT NULL,
                test_mode TEXT NOT NULL,
                subjects_json TEXT NOT NULL,
                subject_label TEXT NOT NULL,
                completed_at TEXT NOT NULL,
                total_questions INTEGER NOT NULL,
                correct_count INTEGER NOT NULL,
                incorrect_count INTEGER NOT NULL,
                unattempted_count INTEGER NOT NULL,
                score REAL NOT NULL,
                max_score REAL NOT NULL,
                accuracy_percent REAL NOT NULL,
                time_taken_seconds INTEGER NOT NULL,
                was_auto_submitted INTEGER NOT NULL,
                performance_summary TEXT NOT NULL,
                scoring_label TEXT NOT NULL,
                marks_per_correct REAL NOT NULL,
                negative_marking_per_wrong REAL NOT NULL,
                review_json TEXT NOT NULL,
                PRIMARY KEY (user_id, test_id)
              )
            ''');
            await txn.execute('''
              INSERT INTO ${testHistoryTable}_v2
              SELECT '$guest', test_id, test_mode, subjects_json, subject_label,
                     completed_at, total_questions, correct_count, incorrect_count,
                     unattempted_count, score, max_score, accuracy_percent,
                     time_taken_seconds, was_auto_submitted, performance_summary,
                     scoring_label, marks_per_correct, negative_marking_per_wrong,
                     review_json
              FROM $testHistoryTable
            ''');
            await txn.execute('DROP TABLE $testHistoryTable');
            await txn.execute('ALTER TABLE ${testHistoryTable}_v2 RENAME TO $testHistoryTable');

            await txn.execute('''
              CREATE TABLE ${bookmarksTable}_v2 (
                user_id TEXT NOT NULL,
                question_id TEXT NOT NULL,
                subject TEXT NOT NULL,
                saved_at TEXT NOT NULL,
                PRIMARY KEY (user_id, question_id)
              )
            ''');
            await txn.execute('''
              INSERT INTO ${bookmarksTable}_v2
              SELECT '$guest', question_id, subject, saved_at FROM $bookmarksTable
            ''');
            await txn.execute('DROP TABLE $bookmarksTable');
            await txn.execute('ALTER TABLE ${bookmarksTable}_v2 RENAME TO $bookmarksTable');

            await txn.execute('''
              CREATE TABLE ${wrongAnswersTable}_v2 (
                user_id TEXT NOT NULL,
                question_id TEXT NOT NULL,
                subject TEXT NOT NULL,
                wrong_count INTEGER NOT NULL,
                revision_attempts INTEGER NOT NULL,
                is_mastered INTEGER NOT NULL,
                last_wrong_at TEXT NOT NULL,
                last_revised_at TEXT,
                mastered_at TEXT,
                PRIMARY KEY (user_id, question_id)
              )
            ''');
            await txn.execute('''
              INSERT INTO ${wrongAnswersTable}_v2
              SELECT '$guest', question_id, subject, wrong_count, revision_attempts,
                     is_mastered, last_wrong_at, last_revised_at, mastered_at
              FROM $wrongAnswersTable
            ''');
            await txn.execute('DROP TABLE $wrongAnswersTable');
            await txn.execute('ALTER TABLE ${wrongAnswersTable}_v2 RENAME TO $wrongAnswersTable');

            await txn.execute('''
              CREATE TABLE ${learningGoalsTable}_v2 (
                user_id TEXT PRIMARY KEY,
                is_enabled INTEGER NOT NULL,
                daily_question_target INTEGER NOT NULL,
                updated_at TEXT NOT NULL
              )
            ''');
            await txn.execute('''
              INSERT INTO ${learningGoalsTable}_v2
              SELECT '$guest', is_enabled, daily_question_target, updated_at
              FROM $learningGoalsTable
            ''');
            await txn.execute('DROP TABLE $learningGoalsTable');
            await txn.execute('ALTER TABLE ${learningGoalsTable}_v2 RENAME TO $learningGoalsTable');

            await txn.execute(
              'CREATE INDEX IF NOT EXISTS idx_history_user_completed ON $testHistoryTable(user_id, completed_at DESC)',
            );
            await txn.execute(
              'CREATE INDEX IF NOT EXISTS idx_bookmarks_user_subject ON $bookmarksTable(user_id, subject, saved_at DESC)',
            );
            await txn.execute(
              'CREATE INDEX IF NOT EXISTS idx_wrong_user_subject_mastered ON $wrongAnswersTable(user_id, subject, is_mastered)',
            );
          });
        }
      },
    );
  }

  @override
  Future<void> close() async {
    if (_db != null && _db!.isOpen) {
      await _db!.close();
    }
    _db = null;
  }

  @override
  Future<void> insertTestHistory(TestHistoryRecord record) async {
    final Database db = await _requireDb();
    final Map<String, Object?> row = <String, Object?>{
      ...record.toDbRow(),
      'user_id': _activeUserId,
    };
    await db.insert(
      testHistoryTable,
      row,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  @override
  Future<List<TestHistoryRecord>> getTestHistory({int? limit}) async {
    final Database db = await _requireDb();
    final List<Map<String, Object?>> rows = await db.query(
      testHistoryTable,
      where: 'user_id = ?',
      whereArgs: <Object?>[_activeUserId],
      orderBy: 'completed_at DESC',
      limit: limit,
    );
    return rows.map(TestHistoryRecord.fromDbRow).toList(growable: false);
  }

  @override
  Future<TestHistoryRecord?> getTestHistoryById(String testId) async {
    final Database db = await _requireDb();
    final List<Map<String, Object?>> rows = await db.query(
      testHistoryTable,
      where: 'user_id = ? AND test_id = ?',
      whereArgs: <Object?>[_activeUserId, testId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return TestHistoryRecord.fromDbRow(rows.first);
  }

  @override
  Future<bool> upsertBookmark(BookmarkedQuestionRecord record) async {
    final Database db = await _requireDb();
    final bool alreadyExists = await isBookmarked(record.questionId);
    if (alreadyExists) {
      return false;
    }
    await db.insert(
      bookmarksTable,
      <String, Object?>{
        ...record.toDbRow(),
        'user_id': _activeUserId,
      },
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
    return true;
  }

  @override
  Future<void> deleteBookmark(String questionId) async {
    final Database db = await _requireDb();
    await db.delete(
      bookmarksTable,
      where: 'user_id = ? AND question_id = ?',
      whereArgs: <Object?>[_activeUserId, questionId],
    );
  }

  @override
  Future<bool> isBookmarked(String questionId) async {
    final Database db = await _requireDb();
    final List<Map<String, Object?>> rows = await db.query(
      bookmarksTable,
      columns: <String>['question_id'],
      where: 'user_id = ? AND question_id = ?',
      whereArgs: <Object?>[_activeUserId, questionId],
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  @override
  Future<List<BookmarkedQuestionRecord>> getBookmarks({
    QuestionSubject? subject,
  }) async {
    final Database db = await _requireDb();
    final String where =
        subject == null ? 'user_id = ?' : 'user_id = ? AND subject = ?';
    final List<Object?> args = subject == null
        ? <Object?>[_activeUserId]
        : <Object?>[_activeUserId, subject.id];
    final List<Map<String, Object?>> rows = await db.query(
      bookmarksTable,
      where: where,
      whereArgs: args,
      orderBy: 'saved_at DESC',
    );
    return rows.map(BookmarkedQuestionRecord.fromDbRow).toList(growable: false);
  }

  @override
  Future<void> upsertWrongAnswer(WrongAnswerRecord record) async {
    final Database db = await _requireDb();
    await db.insert(
      wrongAnswersTable,
      <String, Object?>{
        ...record.toDbRow(),
        'user_id': _activeUserId,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  @override
  Future<WrongAnswerRecord?> getWrongAnswer(String questionId) async {
    final Database db = await _requireDb();
    final List<Map<String, Object?>> rows = await db.query(
      wrongAnswersTable,
      where: 'user_id = ? AND question_id = ?',
      whereArgs: <Object?>[_activeUserId, questionId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return WrongAnswerRecord.fromDbRow(rows.first);
  }

  @override
  Future<List<WrongAnswerRecord>> getWrongAnswers({
    QuestionSubject? subject,
    bool includeMastered = false,
  }) async {
    final Database db = await _requireDb();
    final List<String> clauses = <String>['user_id = ?'];
    final List<Object?> args = <Object?>[_activeUserId];

    if (subject != null) {
      clauses.add('subject = ?');
      args.add(subject.id);
    }
    if (!includeMastered) {
      clauses.add('is_mastered = 0');
    }

    final List<Map<String, Object?>> rows = await db.query(
      wrongAnswersTable,
      where: clauses.join(' AND '),
      whereArgs: args,
      orderBy: 'is_mastered ASC, last_wrong_at DESC',
    );
    return rows.map(WrongAnswerRecord.fromDbRow).toList(growable: false);
  }

  @override
  Future<DailyLearningGoal> getDailyGoal() async {
    final Database db = await _requireDb();
    final List<Map<String, Object?>> rows = await db.query(
      learningGoalsTable,
      where: 'user_id = ?',
      whereArgs: <Object?>[_activeUserId],
      limit: 1,
    );
    if (rows.isEmpty) {
      return DailyLearningGoal.defaultGoal();
    }
    return DailyLearningGoal.fromDbRow(rows.first);
  }

  @override
  Future<void> saveDailyGoal(DailyLearningGoal goal) async {
    final Database db = await _requireDb();
    final Map<String, Object?> row = <String, Object?>{
      'user_id': _activeUserId,
      'is_enabled': goal.isEnabled ? 1 : 0,
      'daily_question_target': goal.dailyQuestionTarget,
      'updated_at': goal.updatedAt.toUtc().toIso8601String(),
    };
    await db.insert(
      learningGoalsTable,
      row,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  @override
  Future<void> clearAllLearningData() async {
    final Database db = await _requireDb();
    await db.transaction((Transaction txn) async {
      await txn.delete(
        testHistoryTable,
        where: 'user_id = ?',
        whereArgs: <Object?>[_activeUserId],
      );
      await txn.delete(
        bookmarksTable,
        where: 'user_id = ?',
        whereArgs: <Object?>[_activeUserId],
      );
      await txn.delete(
        wrongAnswersTable,
        where: 'user_id = ?',
        whereArgs: <Object?>[_activeUserId],
      );
      await txn.delete(
        learningGoalsTable,
        where: 'user_id = ?',
        whereArgs: <Object?>[_activeUserId],
      );
    });
  }

  @override
  Future<void> migrateUserData({
    required String fromUserId,
    required String toUserId,
  }) async {
    if (fromUserId == toUserId) return;
    final Database db = await _requireDb();
    await db.transaction((Transaction txn) async {
      await txn.rawUpdate(
        'UPDATE OR IGNORE $testHistoryTable SET user_id = ? WHERE user_id = ?',
        <Object?>[toUserId, fromUserId],
      );
      await txn.rawUpdate(
        'UPDATE OR IGNORE $bookmarksTable SET user_id = ? WHERE user_id = ?',
        <Object?>[toUserId, fromUserId],
      );
      await txn.rawUpdate(
        'UPDATE OR IGNORE $wrongAnswersTable SET user_id = ? WHERE user_id = ?',
        <Object?>[toUserId, fromUserId],
      );
      await txn.rawUpdate(
        'UPDATE OR IGNORE $learningGoalsTable SET user_id = ? WHERE user_id = ?',
        <Object?>[toUserId, fromUserId],
      );
    });
  }
}
