import 'package:gk_arena/features/learning/database/learning_data_source.dart';
import 'package:gk_arena/features/learning/models/learning_models.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';

class _UserLearningBucket {
  final Map<String, Map<String, Object?>> historyRows =
      <String, Map<String, Object?>>{};
  final Map<String, Map<String, Object?>> bookmarkRows =
      <String, Map<String, Object?>>{};
  final Map<String, Map<String, Object?>> wrongAnswerRows =
      <String, Map<String, Object?>>{};
  Map<String, Object?>? goalRow;
}

/// In-memory persistence store mirroring exact SQLite per-user isolation rules.
class InMemoryLearningStore {
  final Map<String, _UserLearningBucket> _buckets =
      <String, _UserLearningBucket>{};

  _UserLearningBucket bucketFor(String userId) {
    return _buckets.putIfAbsent(userId, _UserLearningBucket.new);
  }
}

class InMemoryLearningDataSource implements LearningDataSource {
  InMemoryLearningDataSource({
    InMemoryLearningStore? store,
    String initialUserId = LearningDataSource.defaultUserId,
  })  : _store = store ?? InMemoryLearningStore(),
        _activeUserId = initialUserId;

  final InMemoryLearningStore _store;
  String _activeUserId;

  InMemoryLearningStore get store => _store;

  @override
  String get activeUserId => _activeUserId;

  @override
  void setActiveUserId(String userId) {
    _activeUserId =
        userId.trim().isEmpty ? LearningDataSource.defaultUserId : userId.trim();
  }

  _UserLearningBucket get _bucket => _store.bucketFor(_activeUserId);

  @override
  Future<void> initialize() async {}

  @override
  Future<void> close() async {}

  @override
  Future<void> insertTestHistory(TestHistoryRecord record) async {
    _bucket.historyRows[record.testId] = record.toDbRow();
  }

  @override
  Future<List<TestHistoryRecord>> getTestHistory({int? limit}) async {
    final List<TestHistoryRecord> records = _bucket.historyRows.values
        .map(TestHistoryRecord.fromDbRow)
        .toList()
      ..sort(
        (TestHistoryRecord a, TestHistoryRecord b) =>
            b.completedAt.compareTo(a.completedAt),
      );
    if (limit != null && records.length > limit) {
      return records.sublist(0, limit);
    }
    return List<TestHistoryRecord>.unmodifiable(records);
  }

  @override
  Future<TestHistoryRecord?> getTestHistoryById(String testId) async {
    final Map<String, Object?>? row = _bucket.historyRows[testId];
    if (row == null) return null;
    return TestHistoryRecord.fromDbRow(row);
  }

  @override
  Future<bool> upsertBookmark(BookmarkedQuestionRecord record) async {
    if (_bucket.bookmarkRows.containsKey(record.questionId)) {
      return false;
    }
    _bucket.bookmarkRows[record.questionId] = record.toDbRow();
    return true;
  }

  @override
  Future<void> deleteBookmark(String questionId) async {
    _bucket.bookmarkRows.remove(questionId);
  }

  @override
  Future<bool> isBookmarked(String questionId) async {
    return _bucket.bookmarkRows.containsKey(questionId);
  }

  @override
  Future<List<BookmarkedQuestionRecord>> getBookmarks({
    QuestionSubject? subject,
  }) async {
    final List<BookmarkedQuestionRecord> items = _bucket.bookmarkRows.values
        .map(BookmarkedQuestionRecord.fromDbRow)
        .where(
          (BookmarkedQuestionRecord item) =>
              subject == null || item.subject == subject,
        )
        .toList()
      ..sort(
        (BookmarkedQuestionRecord a, BookmarkedQuestionRecord b) =>
            b.savedAt.compareTo(a.savedAt),
      );
    return List<BookmarkedQuestionRecord>.unmodifiable(items);
  }

  @override
  Future<void> upsertWrongAnswer(WrongAnswerRecord record) async {
    _bucket.wrongAnswerRows[record.questionId] = record.toDbRow();
  }

  @override
  Future<WrongAnswerRecord?> getWrongAnswer(String questionId) async {
    final Map<String, Object?>? row = _bucket.wrongAnswerRows[questionId];
    if (row == null) return null;
    return WrongAnswerRecord.fromDbRow(row);
  }

  @override
  Future<List<WrongAnswerRecord>> getWrongAnswers({
    QuestionSubject? subject,
    bool includeMastered = false,
  }) async {
    final List<WrongAnswerRecord> items = _bucket.wrongAnswerRows.values
        .map(WrongAnswerRecord.fromDbRow)
        .where((WrongAnswerRecord item) {
          if (subject != null && item.subject != subject) return false;
          if (!includeMastered && item.isMastered) return false;
          return true;
        })
        .toList()
      ..sort((WrongAnswerRecord a, WrongAnswerRecord b) {
        if (a.isMastered != b.isMastered) {
          return a.isMastered ? 1 : -1;
        }
        return b.lastWrongAt.compareTo(a.lastWrongAt);
      });
    return List<WrongAnswerRecord>.unmodifiable(items);
  }

  @override
  Future<DailyLearningGoal> getDailyGoal() async {
    if (_bucket.goalRow == null) {
      return DailyLearningGoal.defaultGoal();
    }
    return DailyLearningGoal.fromDbRow(_bucket.goalRow!);
  }

  @override
  Future<void> saveDailyGoal(DailyLearningGoal goal) async {
    _bucket.goalRow = goal.toDbRow();
  }

  @override
  Future<void> clearAllLearningData() async {
    _bucket.historyRows.clear();
    _bucket.bookmarkRows.clear();
    _bucket.wrongAnswerRows.clear();
    _bucket.goalRow = null;
  }

  @override
  Future<void> migrateUserData({
    required String fromUserId,
    required String toUserId,
  }) async {
    if (fromUserId == toUserId) return;
    final _UserLearningBucket src = _store.bucketFor(fromUserId);
    final _UserLearningBucket dst = _store.bucketFor(toUserId);

    for (final MapEntry<String, Map<String, Object?>> entry
        in src.historyRows.entries) {
      dst.historyRows.putIfAbsent(entry.key, () => entry.value);
    }
    for (final MapEntry<String, Map<String, Object?>> entry
        in src.bookmarkRows.entries) {
      dst.bookmarkRows.putIfAbsent(entry.key, () => entry.value);
    }
    for (final MapEntry<String, Map<String, Object?>> entry
        in src.wrongAnswerRows.entries) {
      dst.wrongAnswerRows.putIfAbsent(entry.key, () => entry.value);
    }
    dst.goalRow ??= src.goalRow;

    src.historyRows.clear();
    src.bookmarkRows.clear();
    src.wrongAnswerRows.clear();
    src.goalRow = null;
  }
}
