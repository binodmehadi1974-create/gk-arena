import 'package:gk_arena/features/learning/models/learning_models.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';

/// Abstract persistence contract for Student Learning & Performance Tracking
/// with strict per-user isolation (`userId`).
abstract class LearningDataSource {
  static const String defaultUserId = 'guest_local';

  String get activeUserId;
  void setActiveUserId(String userId);

  Future<void> initialize();
  Future<void> close();

  // Test History (scoped to activeUserId)
  Future<void> insertTestHistory(TestHistoryRecord record);
  Future<List<TestHistoryRecord>> getTestHistory({int? limit});
  Future<TestHistoryRecord?> getTestHistoryById(String testId);

  // Bookmarks (scoped to activeUserId)
  Future<bool> upsertBookmark(BookmarkedQuestionRecord record);
  Future<void> deleteBookmark(String questionId);
  Future<bool> isBookmarked(String questionId);
  Future<List<BookmarkedQuestionRecord>> getBookmarks({
    QuestionSubject? subject,
  });

  // Wrong Answer Revision (scoped to activeUserId)
  Future<void> upsertWrongAnswer(WrongAnswerRecord record);
  Future<WrongAnswerRecord?> getWrongAnswer(String questionId);
  Future<List<WrongAnswerRecord>> getWrongAnswers({
    QuestionSubject? subject,
    bool includeMastered = false,
  });

  // Daily Learning Goal (scoped to activeUserId)
  Future<DailyLearningGoal> getDailyGoal();
  Future<void> saveDailyGoal(DailyLearningGoal goal);

  // Scoped Clear Data (clears ONLY activeUserId's personal records; never touches Question Bank)
  Future<void> clearAllLearningData();

  // Safe Guest-to-Account migration without duplicating existing records
  Future<void> migrateUserData({
    required String fromUserId,
    required String toUserId,
  });
}
