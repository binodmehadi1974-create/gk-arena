import 'package:flutter/foundation.dart';
import 'package:gk_arena/features/account/services/cloud_backup_service.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/question_bank/repositories/question_repository.dart';

enum ConnectivityStatus {
  offlineLocalOnly,
  online,
  disconnected,
}

class OfflineAvailabilitySummary {
  const OfflineAvailabilitySummary({
    required this.totalPublishedOfflineQuestions,
    required this.bySubject,
    required this.connectivityStatus,
    required this.cloudSyncConfigured,
  });

  final int totalPublishedOfflineQuestions;
  final Map<QuestionSubject, int> bySubject;
  final ConnectivityStatus connectivityStatus;
  final bool cloudSyncConfigured;

  bool get isOfflineReady => totalPublishedOfflineQuestions > 0;
}

/// Manages graceful offline behavior and reports real local offline-ready
/// question availability without pretending cloud sync is active.
class OfflineSupportService extends ChangeNotifier {
  OfflineSupportService({
    required this.questionRepository,
    required this.cloudSyncService,
  }) : _connectivity = cloudSyncService.remoteDataSource.isConfigured
            ? ConnectivityStatus.online
            : ConnectivityStatus.offlineLocalOnly;

  final QuestionRepository questionRepository;
  final CloudSyncService cloudSyncService;
  ConnectivityStatus _connectivity;

  ConnectivityStatus get connectivity => _connectivity;

  void updateConnectivity(ConnectivityStatus status) {
    if (_connectivity == status) return;
    _connectivity = status;
    notifyListeners();
  }

  Future<OfflineAvailabilitySummary> getAvailabilitySummary() async {
    final int total = await questionRepository.count(
      filter: const QuestionFilter(
        publicationStatus: PublicationStatus.published,
      ),
    );
    final Map<QuestionSubject, int> bySubject = <QuestionSubject, int>{};
    for (final QuestionSubject subject in QuestionSubject.values) {
      bySubject[subject] = await questionRepository.count(
        filter: QuestionFilter(
          subject: subject,
          publicationStatus: PublicationStatus.published,
        ),
      );
    }

    return OfflineAvailabilitySummary(
      totalPublishedOfflineQuestions: total,
      bySubject: bySubject,
      connectivityStatus: _connectivity,
      cloudSyncConfigured: cloudSyncService.remoteDataSource.isConfigured,
    );
  }
}
