import 'package:flutter/foundation.dart';
import 'package:gk_arena/features/learning/repositories/learning_repository.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/settings/database/settings_data_source.dart';
import 'package:gk_arena/features/settings/models/app_settings.dart';

/// App-wide controller managing language, theme, study preferences,
/// notification preferences, and persistent storage.
class SettingsController extends ChangeNotifier {
  SettingsController({
    required this.dataSource,
    this.learningRepository,
  });

  final SettingsDataSource dataSource;
  final LearningRepository? learningRepository;

  AppSettings _settings = const AppSettings();
  bool _initialized = false;

  AppSettings get settings => _settings;
  AppLanguage get appLanguage => _settings.appLanguage;
  AppThemePreference get themePreference => _settings.themePreference;
  StudyPreferences get studyPreferences => _settings.studyPreferences;
  NotificationPreferences get notificationPreferences =>
      _settings.notificationPreferences;

  Future<void> initialize() async {
    if (_initialized) return;
    await dataSource.initialize();
    _settings = await dataSource.loadSettings();
    _initialized = true;
    notifyListeners();
  }

  Future<void> close() => dataSource.close();

  Future<void> setAppLanguage(AppLanguage language) async {
    if (_settings.appLanguage == language) return;
    _settings = _settings.copyWith(appLanguage: language);
    notifyListeners();
    await dataSource.saveSettings(_settings);
  }

  Future<void> setThemePreference(AppThemePreference preference) async {
    if (_settings.themePreference == preference) return;
    _settings = _settings.copyWith(themePreference: preference);
    notifyListeners();
    await dataSource.saveSettings(_settings);
  }

  Future<void> updateStudyPreferences({
    QuestionLanguage? defaultQuestionLanguage,
    bool clearQuestionLanguage = false,
    QuestionDifficulty? preferredDifficulty,
    bool clearDifficulty = false,
    int? preferredTestDurationMinutes,
    bool? dailyGoalEnabled,
    int? dailyGoalTarget,
  }) async {
    final StudyPreferences updated = _settings.studyPreferences.copyWith(
      defaultQuestionLanguage: defaultQuestionLanguage,
      clearQuestionLanguage: clearQuestionLanguage,
      preferredDifficulty: preferredDifficulty,
      clearDifficulty: clearDifficulty,
      preferredTestDurationMinutes: preferredTestDurationMinutes,
      dailyGoalEnabled: dailyGoalEnabled,
      dailyGoalTarget: dailyGoalTarget,
    );
    _settings = _settings.copyWith(studyPreferences: updated);
    notifyListeners();
    await dataSource.saveSettings(_settings);

    if (learningRepository != null &&
        (dailyGoalEnabled != null || dailyGoalTarget != null)) {
      await learningRepository!.saveDailyGoal(
        isEnabled: updated.dailyGoalEnabled,
        dailyQuestionTarget: updated.dailyGoalTarget,
      );
    }
  }

  Future<void> updateNotificationPreferences({
    bool? dailyChallengeReminders,
    bool? studyReminders,
    bool? learningActivityNotifications,
  }) async {
    final NotificationPreferences updated =
        _settings.notificationPreferences.copyWith(
      dailyChallengeReminders: dailyChallengeReminders,
      studyReminders: studyReminders,
      learningActivityNotifications: learningActivityNotifications,
    );
    _settings = _settings.copyWith(notificationPreferences: updated);
    notifyListeners();
    await dataSource.saveSettings(_settings);
  }
}
