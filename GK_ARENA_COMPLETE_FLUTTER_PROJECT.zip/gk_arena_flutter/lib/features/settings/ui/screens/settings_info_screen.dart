import 'package:flutter/material.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';

/// Reusable Settings Information screen for About GK ARENA, Help & Support,
/// Privacy Policy, and Terms & Conditions using clearly labeled placeholders
/// where published legal documents or official contact details are unavailable.
class SettingsInfoScreen extends StatelessWidget {
  const SettingsInfoScreen({
    super.key,
    required this.title,
    required this.icon,
    required this.badgeText,
    required this.body,
  });

  final String title;
  final IconData icon;
  final String badgeText;
  final String body;

  @override
  Widget build(BuildContext context) {
    final Color surface = AppColors.surfaceOf(context);
    final Color border = AppColors.borderOf(context);
    final Color textPrimary = AppColors.textPrimaryOf(context);
    final Color textSecondary = AppColors.textSecondaryOf(context);

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(
            20,
            AppSpacing.md,
            20,
            AppSpacing.lg,
          ),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(AppSpacing.lg),
            decoration: BoxDecoration(
              color: surface,
              borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
              border: Border.all(color: border, width: 1),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: AppColors.softBlueOf(context),
                        borderRadius:
                            BorderRadius.circular(AppSpacing.radiusMd),
                      ),
                      child: Icon(icon, color: AppColors.primary, size: 22),
                    ),
                    const SizedBox(width: AppSpacing.sm),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            title,
                            style: AppTextStyles.sectionTitle
                                .copyWith(color: textPrimary),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            badgeText,
                            style: AppTextStyles.badgeLabel.copyWith(
                              color: AppColors.primary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppSpacing.md),
                Text(
                  body,
                  style: AppTextStyles.body.copyWith(
                    color: textSecondary,
                    height: 1.6,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
