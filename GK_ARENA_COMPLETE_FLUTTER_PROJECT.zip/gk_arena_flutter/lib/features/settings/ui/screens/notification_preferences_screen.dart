import 'package:flutter/material.dart';
import 'package:gk_arena/features/settings/controllers/settings_controller.dart';
import 'package:gk_arena/features/settings/localization/app_strings.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';

/// Notification Preferences screen clearly marking OS notification scheduling
/// as not yet available (no fabricated scheduling or fake reminders).
class NotificationPreferencesScreen extends StatelessWidget {
  const NotificationPreferencesScreen({
    super.key,
    required this.settingsController,
  });

  final SettingsController settingsController;

  @override
  Widget build(BuildContext context) {
    final AppStrings s = AppLanguageScope.of(context);
    final Color surface = AppColors.surfaceOf(context);
    final Color border = AppColors.borderOf(context);
    final Color textPrimary = AppColors.textPrimaryOf(context);
    final Color textSecondary = AppColors.textSecondaryOf(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(s.notificationsTitle),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(
            20,
            AppSpacing.sm,
            20,
            AppSpacing.lg,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(AppSpacing.md),
                decoration: BoxDecoration(
                  color: AppColors.softAmberOf(context),
                  borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
                  border: Border.all(color: AppColors.warning, width: 1),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Icon(
                      Icons.info_outline_rounded,
                      color: AppColors.warning,
                      size: 20,
                    ),
                    const SizedBox(width: AppSpacing.sm),
                    Expanded(
                      child: Text(
                        s.t(
                          hi: 'डिवाइस नोटिफ़िकेशन शेड्यूलिंग और Android अनुमति अभी इस बिल्ड में एकीकृत नहीं है। नीचे दिए गए विकल्प अभी सक्रिय नहीं हैं और अगले चरण में जोड़े जाएंगे।',
                          en: 'Local device notification scheduling and OS permission handling are not yet integrated in this build. The options below are previewed as Not Yet Available and do not schedule reminders yet.',
                        ),
                        style: AppTextStyles.body.copyWith(color: textPrimary),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.lg),
              Container(
                decoration: BoxDecoration(
                  color: surface,
                  borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
                  border: Border.all(color: border, width: 1),
                ),
                clipBehavior: Clip.antiAlias,
                child: Column(
                  children: <Widget>[
                    _UnavailableNotifTile(
                      icon: Icons.bolt_rounded,
                      title: s.t(
                        hi: 'दैनिक चैलेंज रिमाइंडर',
                        en: 'Daily Challenge Reminders',
                      ),
                      subtitle: s.t(
                        hi: 'दैनिक सामान्य ज्ञान चैलेंज के लिए अनुस्मारक',
                        en: 'Reminders for your Daily GK Challenge',
                      ),
                      badge: s.notYetAvailable,
                      textPrimary: textPrimary,
                      textSecondary: textSecondary,
                    ),
                    const Divider(indent: 64),
                    _UnavailableNotifTile(
                      icon: Icons.schedule_rounded,
                      title: s.t(
                        hi: 'अध्ययन रिमाइंडर',
                        en: 'Study Reminders',
                      ),
                      subtitle: s.t(
                        hi: 'नियमित अभ्यास समय के लिए अनुस्मारक',
                        en: 'Scheduled reminders for regular study sessions',
                      ),
                      badge: s.notYetAvailable,
                      textPrimary: textPrimary,
                      textSecondary: textSecondary,
                    ),
                    const Divider(indent: 64),
                    _UnavailableNotifTile(
                      icon: Icons.notifications_none_rounded,
                      title: s.t(
                        hi: 'लर्निंग गतिविधि सूचनाएँ',
                        en: 'Learning Activity Notifications',
                      ),
                      subtitle: s.t(
                        hi: 'रिवीजन और दैनिक लक्ष्य से जुड़ी सूचनाएँ',
                        en: 'Updates about revision items and daily goals',
                      ),
                      badge: s.notYetAvailable,
                      textPrimary: textPrimary,
                      textSecondary: textSecondary,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _UnavailableNotifTile extends StatelessWidget {
  const _UnavailableNotifTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.badge,
    required this.textPrimary,
    required this.textSecondary,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final String badge;
  final Color textPrimary;
  final Color textSecondary;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.md,
        vertical: 14,
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppColors.softBlueOf(context),
              borderRadius: BorderRadius.circular(AppSpacing.radiusSm),
            ),
            child: Icon(icon, color: AppColors.primary, size: 20),
          ),
          const SizedBox(width: AppSpacing.sm),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  title,
                  style: AppTextStyles.cardTitle.copyWith(color: textPrimary),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style:
                      AppTextStyles.cardSubtitle.copyWith(color: textSecondary),
                ),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: AppColors.softAmberOf(context),
                    borderRadius: BorderRadius.circular(AppSpacing.radiusPill),
                  ),
                  child: Text(
                    badge,
                    style: AppTextStyles.badgeLabel.copyWith(
                      color: AppColors.warning,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const Switch(
            value: false,
            onChanged: null,
          ),
        ],
      ),
    );
  }
}
