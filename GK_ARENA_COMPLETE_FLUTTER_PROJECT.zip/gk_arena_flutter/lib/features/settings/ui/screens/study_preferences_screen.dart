import 'package:flutter/material.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/settings/controllers/settings_controller.dart';
import 'package:gk_arena/features/settings/localization/app_strings.dart';
import 'package:gk_arena/features/settings/models/app_settings.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';

/// Study Preferences screen configuring default question language (separate
/// from app UI language), preferred difficulty, preferred test duration, and
/// optional daily learning goal.
class StudyPreferencesScreen extends StatelessWidget {
  const StudyPreferencesScreen({
    super.key,
    required this.settingsController,
  });

  final SettingsController settingsController;

  static const List<int> _durationOptions = <int>[5, 10, 15, 20, 30];
  static const List<int> _goalTargets = <int>[5, 10, 20, 30, 50];

  @override
  Widget build(BuildContext context) {
    final AppStrings s = AppLanguageScope.of(context);

    return AnimatedBuilder(
      animation: settingsController,
      builder: (BuildContext context, _) {
        final StudyPreferences prefs = settingsController.studyPreferences;
        final Color surface = AppColors.surfaceOf(context);
        final Color border = AppColors.borderOf(context);
        final Color textPrimary = AppColors.textPrimaryOf(context);
        final Color textSecondary = AppColors.textSecondaryOf(context);

        return Scaffold(
          appBar: AppBar(
            title: Text(s.studyPreferencesTitle),
          ),
          body: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(
                20,
                AppSpacing.sm,
                20,
                AppSpacing.lg,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  _PrefCard(
                    surface: surface,
                    border: border,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          s.t(
                            hi: 'डिफ़ॉल्ट प्रश्न भाषा',
                            en: 'Default Question Language',
                          ),
                          style: AppTextStyles.cardTitle
                              .copyWith(color: textPrimary),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          s.t(
                            hi: 'यह केवल प्रश्नों की भाषा तय करता है — ऐप इंटरफ़ेस भाषा से अलग है।',
                            en: 'Sets default quiz question language independently from app UI language.',
                          ),
                          style: AppTextStyles.cardSubtitle
                              .copyWith(color: textSecondary),
                        ),
                        const SizedBox(height: AppSpacing.sm),
                        Wrap(
                          spacing: AppSpacing.xs,
                          runSpacing: AppSpacing.xs,
                          children: <Widget>[
                            ChoiceChip(
                              label: Text(
                                s.t(hi: 'दोनों (हिन्दी + EN)', en: 'Both (HI + EN)'),
                              ),
                              selected: prefs.defaultQuestionLanguage == null,
                              onSelected: (_) {
                                settingsController.updateStudyPreferences(
                                  clearQuestionLanguage: true,
                                );
                              },
                            ),
                            ChoiceChip(
                              label: const Text('हिन्दी'),
                              selected: prefs.defaultQuestionLanguage ==
                                  QuestionLanguage.hindi,
                              onSelected: (_) {
                                settingsController.updateStudyPreferences(
                                  defaultQuestionLanguage:
                                      QuestionLanguage.hindi,
                                );
                              },
                            ),
                            ChoiceChip(
                              label: const Text('English'),
                              selected: prefs.defaultQuestionLanguage ==
                                  QuestionLanguage.english,
                              onSelected: (_) {
                                settingsController.updateStudyPreferences(
                                  defaultQuestionLanguage:
                                      QuestionLanguage.english,
                                );
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  _PrefCard(
                    surface: surface,
                    border: border,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          s.t(
                            hi: 'पसंदीदा कठिनाई स्तर',
                            en: 'Preferred Difficulty',
                          ),
                          style: AppTextStyles.cardTitle
                              .copyWith(color: textPrimary),
                        ),
                        const SizedBox(height: AppSpacing.sm),
                        Wrap(
                          spacing: AppSpacing.xs,
                          runSpacing: AppSpacing.xs,
                          children: <Widget>[
                            ChoiceChip(
                              label: Text(s.all),
                              selected: prefs.preferredDifficulty == null,
                              onSelected: (_) {
                                settingsController.updateStudyPreferences(
                                  clearDifficulty: true,
                                );
                              },
                            ),
                            for (final QuestionDifficulty diff
                                in QuestionDifficulty.values)
                              ChoiceChip(
                                label: Text(
                                  s.isHindi ? diff.labelHi : diff.labelEn,
                                ),
                                selected: prefs.preferredDifficulty == diff,
                                onSelected: (_) {
                                  settingsController.updateStudyPreferences(
                                    preferredDifficulty: diff,
                                  );
                                },
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  _PrefCard(
                    surface: surface,
                    border: border,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          s.t(
                            hi: 'पसंदीदा टेस्ट अवधि',
                            en: 'Preferred Test Duration',
                          ),
                          style: AppTextStyles.cardTitle
                              .copyWith(color: textPrimary),
                        ),
                        const SizedBox(height: AppSpacing.sm),
                        Wrap(
                          spacing: AppSpacing.xs,
                          runSpacing: AppSpacing.xs,
                          children: _durationOptions.map((int mins) {
                            return ChoiceChip(
                              label: Text('$mins min'),
                              selected:
                                  prefs.preferredTestDurationMinutes == mins,
                              onSelected: (_) {
                                settingsController.updateStudyPreferences(
                                  preferredTestDurationMinutes: mins,
                                );
                              },
                            );
                          }).toList(growable: false),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  _PrefCard(
                    surface: surface,
                    border: border,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          children: <Widget>[
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    s.t(
                                      hi: 'दैनिक अध्ययन लक्ष्य (वैकल्पिक)',
                                      en: 'Optional Daily Learning Goal',
                                    ),
                                    style: AppTextStyles.cardTitle
                                        .copyWith(color: textPrimary),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    s.t(
                                      hi: 'सीखने की प्रगति डैशबोर्ड से जुड़ा हुआ',
                                      en: 'Synced with your Learning Progress dashboard',
                                    ),
                                    style: AppTextStyles.cardSubtitle
                                        .copyWith(color: textSecondary),
                                  ),
                                ],
                              ),
                            ),
                            Switch(
                              value: prefs.dailyGoalEnabled,
                              onChanged: (bool enabled) {
                                settingsController.updateStudyPreferences(
                                  dailyGoalEnabled: enabled,
                                );
                              },
                            ),
                          ],
                        ),
                        if (prefs.dailyGoalEnabled) ...<Widget>[
                          const SizedBox(height: AppSpacing.sm),
                          Wrap(
                            spacing: AppSpacing.xs,
                            runSpacing: AppSpacing.xs,
                            children: _goalTargets.map((int target) {
                              return ChoiceChip(
                                label: Text('$target Qs'),
                                selected: prefs.dailyGoalTarget == target,
                                onSelected: (_) {
                                  settingsController.updateStudyPreferences(
                                    dailyGoalEnabled: true,
                                    dailyGoalTarget: target,
                                  );
                                },
                              );
                            }).toList(growable: false),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _PrefCard extends StatelessWidget {
  const _PrefCard({
    required this.surface,
    required this.border,
    required this.child,
  });

  final Color surface;
  final Color border;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        border: Border.all(color: border, width: 1),
      ),
      child: child,
    );
  }
}
