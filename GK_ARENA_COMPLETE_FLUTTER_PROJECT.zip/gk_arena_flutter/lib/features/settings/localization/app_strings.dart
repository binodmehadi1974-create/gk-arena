import 'package:flutter/widgets.dart';
import 'package:gk_arena/features/settings/models/app_settings.dart';

/// Inherited localization provider delivering instant UI updates across
/// the entire GK ARENA widget tree when app language changes.
class AppLanguageScope extends InheritedWidget {
  const AppLanguageScope({
    super.key,
    required this.language,
    required super.child,
  });

  final AppLanguage language;

  static AppStrings of(BuildContext context) {
    final AppLanguageScope? scope =
        context.dependOnInheritedWidgetOfExactType<AppLanguageScope>();
    return AppStrings(scope?.language ?? AppLanguage.hindi);
  }

  static AppLanguage languageOf(BuildContext context) {
    final AppLanguageScope? scope =
        context.dependOnInheritedWidgetOfExactType<AppLanguageScope>();
    return scope?.language ?? AppLanguage.hindi;
  }

  @override
  bool updateShouldNotify(AppLanguageScope oldWidget) =>
      language != oldWidget.language;
}

/// Centralized Hindi (Devanagari) & English UI strings.
/// Keeps app interface language cleanly separated from question language.
class AppStrings {
  const AppStrings(this.language);

  final AppLanguage language;

  bool get isHindi => language == AppLanguage.hindi;

  String t({required String hi, required String en}) => isHindi ? hi : en;

  // Navigation
  String get navHome => t(hi: 'होम', en: 'Home');
  String get navExplore => t(hi: 'विषय', en: 'Explore');
  String get navTests => t(hi: 'टेस्ट', en: 'Tests');
  String get navProfile => t(hi: 'प्रोफ़ाइल', en: 'Profile');

  // Common Buttons & Labels
  String get back => t(hi: 'वापस', en: 'Back');
  String get cancel => t(hi: 'रद्द करें', en: 'Cancel');
  String get confirm => t(hi: 'पुष्टि करें', en: 'Confirm');
  String get save => t(hi: 'सहेजें', en: 'Save');
  String get all => t(hi: 'सभी', en: 'All');
  String get viewAll => t(hi: 'सभी देखें', en: 'View All');
  String get next => t(hi: 'अगला', en: 'Next');
  String get previous => t(hi: 'पिछला', en: 'Previous');
  String get submit => t(hi: 'सबमिट', en: 'Submit');
  String get submitTest => t(hi: 'टेस्ट सबमिट करें', en: 'Submit Test');

  // Profile & Learning
  String get myProfile => t(hi: 'मेरी प्रोफ़ाइल', en: 'My Profile');
  String get learnerProfile => t(hi: 'अध्येता प्रोफ़ाइल', en: 'Learner Profile');
  String get learningSection => t(hi: 'मेरा अध्ययन', en: 'Learning');
  String get appSection => t(hi: 'ऐप', en: 'App');
  String get learningProgress =>
      t(hi: 'सीखने की प्रगति', en: 'Learning Progress');
  String get learningProgressSub => t(
        hi: 'विषय-वार अध्ययन और वास्तविक प्रदर्शन सारांश',
        en: 'Subject-wise progress and real performance summary',
      );
  String get testHistory => t(hi: 'टेस्ट इतिहास', en: 'Test History');
  String get testHistorySub => t(
        hi: 'पिछले टेस्ट के परिणाम और उत्तर समीक्षा',
        en: 'Previous test results and answer reviews',
      );
  String get bookmarks => t(hi: 'बुकमार्क', en: 'Bookmarks');
  String get bookmarksSub => t(
        hi: 'सहेजे गए प्रश्न और त्वरित अभ्यास',
        en: 'Saved questions and quick practice',
      );
  String get wrongAnswerRevision =>
      t(hi: 'गलत उत्तर रिवीजन', en: 'Wrong Answer Revision');
  String get wrongAnswerRevisionSub => t(
        hi: 'गलत हुए प्रश्नों का विषय-वार अभ्यास',
        en: 'Subject-wise revision of missed questions',
      );
  String get languagePreference =>
      t(hi: 'ऐप भाषा', en: 'Language Preference');
  String get languagePreferenceSub => t(
        hi: 'ऐप इंटरफ़ेस के लिए हिन्दी या English चुनें',
        en: 'Choose Hindi or English for the app interface',
      );

  // Settings
  String get settings => t(hi: 'सेटिंग्स', en: 'Settings');
  String get settingsSub => t(
        hi: 'भाषा, थीम, अध्ययन प्राथमिकताएँ और डेटा प्रबंधन',
        en: 'Language, theme, study preferences & data controls',
      );
  String get preferencesSection =>
      t(hi: 'प्राथमिकताएँ', en: 'Preferences');
  String get dataPrivacySection =>
      t(hi: 'डेटा और गोपनीयता', en: 'Data & Privacy');
  String get infoLegalSection =>
      t(hi: 'जानकारी और सहायता', en: 'Information & Support');

  String get appLanguageTitle => t(hi: 'ऐप की भाषा', en: 'App Language');
  String get themeTitle => t(hi: 'थीम (Theme)', en: 'Theme');
  String get themeLight => t(hi: 'लाइट थीम', en: 'Light Theme');
  String get themeDark => t(hi: 'डार्क थीम', en: 'Dark Theme');
  String get themeSystem => t(hi: 'सिस्टम डिफ़ॉल्ट', en: 'System Default');

  String themeLabel(AppThemePreference pref) {
    switch (pref) {
      case AppThemePreference.light:
        return themeLight;
      case AppThemePreference.dark:
        return themeDark;
      case AppThemePreference.system:
        return themeSystem;
    }
  }

  String get notificationsTitle =>
      t(hi: 'सूचना प्राथमिकताएँ', en: 'Notification Preferences');
  String get notificationsSub => t(
        hi: 'दैनिक चैलेंज और अध्ययन रिमाइंडर (अभी उपलब्ध नहीं)',
        en: 'Daily challenge & study reminders (Not yet available)',
      );
  String get notYetAvailable =>
      t(hi: 'अभी उपलब्ध नहीं', en: 'Not Yet Available');

  String get studyPreferencesTitle =>
      t(hi: 'अध्ययन प्राथमिकताएँ', en: 'Study Preferences');
  String get studyPreferencesSub => t(
        hi: 'डिफ़ॉल्ट प्रश्न भाषा, कठिनाई, अवधि और दैनिक लक्ष्य',
        en: 'Default question language, difficulty, duration & daily goal',
      );

  String get clearLearningData =>
      t(hi: 'मेरा लर्निंग डेटा साफ़ करें', en: 'Clear Learning Data');
  String get clearLearningDataSub => t(
        hi: 'टेस्ट इतिहास, बुकमार्क और रिवीजन डेटा हटाएँ (प्रश्न बैंक सुरक्षित रहेगा)',
        en: 'Delete test history, bookmarks & revision data (Question Bank stays safe)',
      );
  String get clearDataDialogTitle =>
      t(hi: 'लर्निंग डेटा साफ़ करें?', en: 'Clear Learning Data?');
  String get clearDataDialogBody => t(
        hi: 'इससे आपका पूरा टेस्ट इतिहास, सहेजे गए बुकमार्क, गलत उत्तर रिवीजन प्रगति और दैनिक लक्ष्य प्रगति स्थायी रूप से हट जाएगी।\n\nआपका प्रश्न बैंक (Question Bank) और ऐप सेटिंग्स सुरक्षित रहेंगी।',
        en: 'This will permanently delete your Test History, saved Bookmarks, Wrong Answer Revision progress, and Daily Goal progress.\n\nYour Question Bank and app settings will NOT be deleted.',
      );
  String get clearDataConfirmBtn =>
      t(hi: 'हाँ, डेटा साफ़ करें', en: 'Yes, Clear Data');
  String get clearDataDone => t(
        hi: 'आपका व्यक्तिगत लर्निंग डेटा साफ़ कर दिया गया है। प्रश्न बैंक सुरक्षित है।',
        en: 'Personal learning data cleared. Your Question Bank remains intact.',
      );

  String get aboutGkArena => t(hi: 'GK ARENA के बारे में', en: 'About GK ARENA');
  String get aboutGkArenaSub => t(
        hi: 'ऐप का परिचय और संस्करण जानकारी',
        en: 'App overview and version details',
      );
  String get helpSupport => t(hi: 'सहायता और समर्थन', en: 'Help & Support');
  String get helpSupportSub => t(
        hi: 'सहायता जानकारी (प्लेसहोल्डर)',
        en: 'Support information (Placeholder)',
      );
  String get privacyPolicy => t(hi: 'गोपनीयता नीति', en: 'Privacy Policy');
  String get privacyPolicySub => t(
        hi: 'डेटा उपयोग जानकारी (प्लेसहोल्डर)',
        en: 'Data usage policy (Placeholder)',
      );
  String get termsConditions =>
      t(hi: 'नियम और शर्तें', en: 'Terms & Conditions');
  String get termsConditionsSub => t(
        hi: 'उपयोग की शर्तें (प्लेसहोल्डर)',
        en: 'Usage terms (Placeholder)',
      );
  String get appVersion => t(hi: 'ऐप संस्करण', en: 'App Version');

  // Quiz & Test Screens
  String get testResult => t(hi: 'टेस्ट परिणाम', en: 'Test Result');
  String get savedTestResult =>
      t(hi: 'सहेजा गया परिणाम', en: 'Saved Test Result');
  String get answerReview => t(hi: 'उत्तर समीक्षा', en: 'Answer Review');
  String get reviewAnswers => t(hi: 'उत्तर समीक्षा देखें', en: 'Review Answers');
  String get retryTest => t(hi: 'पुनः प्रयास करें', en: 'Retry Test');
  String get backToTests => t(hi: 'टेस्ट पर वापस', en: 'Back to Tests');
  String get correct => t(hi: 'सही', en: 'Correct');
  String get incorrect => t(hi: 'गलत', en: 'Incorrect');
  String get skipped => t(hi: 'छोड़े गए', en: 'Skipped');
  String get markReview => t(hi: 'रिव्यू चिह्नित', en: 'Mark Review');
  String get marked => t(hi: 'चिह्नित', en: 'Marked');
  String get clearAnswer => t(hi: 'उत्तर हटाएँ', en: 'Clear Answer');
  String get explanation => t(hi: 'व्याख्या', en: 'Explanation');
}
