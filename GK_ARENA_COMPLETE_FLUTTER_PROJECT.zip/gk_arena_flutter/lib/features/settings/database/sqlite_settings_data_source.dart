import 'package:gk_arena/features/settings/database/settings_data_source.dart';
import 'package:gk_arena/features/settings/models/app_settings.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// SQLite-backed local persistence for app settings & personalization.
/// Stores strictly non-sensitive preferences (no passwords or PII).
class SqliteSettingsDataSource implements SettingsDataSource {
  SqliteSettingsDataSource({
    this.databaseName = 'gk_arena_settings.db',
  });

  static const int schemaVersion = 1;
  static const String settingsTable = 'app_settings';

  final String databaseName;
  Database? _db;

  Future<Database> _requireDb() async {
    if (_db == null || !_db!.isOpen) {
      await initialize();
    }
    return _db!;
  }

  @override
  Future<void> initialize() async {
    if (_db != null && _db!.isOpen) return;
    final String dbPath = p.join(await getDatabasesPath(), databaseName);
    _db = await openDatabase(
      dbPath,
      version: schemaVersion,
      onCreate: (Database db, int version) async {
        await db.execute('''
          CREATE TABLE $settingsTable (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            app_language TEXT NOT NULL,
            theme_preference TEXT NOT NULL,
            default_question_language TEXT,
            preferred_difficulty TEXT,
            preferred_test_duration_minutes INTEGER NOT NULL,
            daily_goal_enabled INTEGER NOT NULL,
            daily_goal_target INTEGER NOT NULL,
            notif_daily_challenge INTEGER NOT NULL,
            notif_study_reminders INTEGER NOT NULL,
            notif_learning_activity INTEGER NOT NULL
          )
        ''');
      },
      onUpgrade: (Database db, int oldVersion, int newVersion) async {
        // Reserved for future settings schema migrations.
      },
    );
  }

  @override
  Future<void> close() async {
    if (_db != null && _db!.isOpen) {
      await _db!.close();
    }
    _db = null;
  }

  @override
  Future<AppSettings> loadSettings() async {
    final Database db = await _requireDb();
    final List<Map<String, Object?>> rows = await db.query(
      settingsTable,
      where: 'id = 1',
      limit: 1,
    );
    if (rows.isEmpty) {
      return const AppSettings();
    }
    return AppSettings.fromDbRow(rows.first);
  }

  @override
  Future<void> saveSettings(AppSettings settings) async {
    final Database db = await _requireDb();
    await db.insert(
      settingsTable,
      settings.toDbRow(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }
}
