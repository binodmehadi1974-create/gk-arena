import 'package:gk_arena/features/settings/database/settings_data_source.dart';
import 'package:gk_arena/features/settings/models/app_settings.dart';

/// Injectable backing store for testing settings persistence across restarts.
class InMemorySettingsStore {
  Map<String, Object?>? settingsRow;
}

class InMemorySettingsDataSource implements SettingsDataSource {
  InMemorySettingsDataSource({InMemorySettingsStore? store})
      : _store = store ?? InMemorySettingsStore();

  final InMemorySettingsStore _store;

  InMemorySettingsStore get store => _store;

  @override
  Future<void> initialize() async {}

  @override
  Future<void> close() async {}

  @override
  Future<AppSettings> loadSettings() async {
    if (_store.settingsRow == null) {
      return const AppSettings();
    }
    return AppSettings.fromDbRow(_store.settingsRow!);
  }

  @override
  Future<void> saveSettings(AppSettings settings) async {
    _store.settingsRow = settings.toDbRow();
  }
}
