import 'package:gk_arena/features/settings/models/app_settings.dart';

/// Abstract local persistence contract for app settings and personalization.
abstract class SettingsDataSource {
  Future<void> initialize();
  Future<void> close();
  Future<AppSettings> loadSettings();
  Future<void> saveSettings(AppSettings settings);
}
