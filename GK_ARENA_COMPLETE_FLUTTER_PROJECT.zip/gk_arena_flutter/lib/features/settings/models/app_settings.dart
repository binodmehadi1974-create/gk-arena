import 'package:flutter/material.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';

/// App interface language (kept strictly separate from question content language).
enum AppLanguage {
  hindi('hi', 'हिन्दी', 'Hindi'),
  english('en', 'English', 'English');

  const AppLanguage(this.code, this.nativeName, this.englishName);

  final String code;
  final String nativeName;
  final String englishName;

  Locale get locale => Locale(code);

  static AppLanguage fromCode(String? raw) {
    final String normalized = (raw ?? '').trim().toLowerCase();
    if (normalized == 'en' || normalized == 'english') {
      return AppLanguage.english;
    }
    return AppLanguage.hindi;
  }
}

/// App-wide theme preference supporting Light, Dark, and System Default.
enum AppThemePreference {
  light('light'),
  dark('dark'),
  system('system');

  const AppThemePreference(this.code);

  final String code;

  ThemeMode get themeMode {
    switch (this) {
      case AppThemePreference.light:
        return ThemeMode.light;
      case AppThemePreference.dark:
        return ThemeMode.dark;
      case AppThemePreference.system:
        return ThemeMode.system;
    }
  }

  static AppThemePreference fromCode(String? raw) {
    final String normalized = (raw ?? '').trim().toLowerCase();
    for (final AppThemePreference pref in AppThemePreference.values) {
      if (pref.code == normalized) return pref;
    }
    return AppThemePreference.light;
  }
}

/// Study defaults connected to Test Configuration and optional Daily Goal.
class StudyPreferences {
  const StudyPreferences({
    this.defaultQuestionLanguage,
    this.preferredDifficulty,
    this.preferredTestDurationMinutes = 15,
    this.dailyGoalEnabled = false,
    this.dailyGoalTarget = 10,
  });

  /// Null means "Both (Hindi + English)".
  final QuestionLanguage? defaultQuestionLanguage;

  /// Null means "All Difficulties".
  final QuestionDifficulty? preferredDifficulty;

  final int preferredTestDurationMinutes;
  final bool dailyGoalEnabled;
  final int dailyGoalTarget;

  StudyPreferences copyWith({
    QuestionLanguage? defaultQuestionLanguage,
    bool clearQuestionLanguage = false,
    QuestionDifficulty? preferredDifficulty,
    bool clearDifficulty = false,
    int? preferredTestDurationMinutes,
    bool? dailyGoalEnabled,
    int? dailyGoalTarget,
  }) {
    return StudyPreferences(
      defaultQuestionLanguage: clearQuestionLanguage
          ? null
          : (defaultQuestionLanguage ?? this.defaultQuestionLanguage),
      preferredDifficulty: clearDifficulty
          ? null
          : (preferredDifficulty ?? this.preferredDifficulty),
      preferredTestDurationMinutes:
          preferredTestDurationMinutes ?? this.preferredTestDurationMinutes,
      dailyGoalEnabled: dailyGoalEnabled ?? this.dailyGoalEnabled,
      dailyGoalTarget: dailyGoalTarget ?? this.dailyGoalTarget,
    );
  }
}

/// Notification preference flags (UI preferences only; OS scheduling not yet wired).
class NotificationPreferences {
  const NotificationPreferences({
    this.dailyChallengeReminders = false,
    this.studyReminders = false,
    this.learningActivityNotifications = false,
  });

  final bool dailyChallengeReminders;
  final bool studyReminders;
  final bool learningActivityNotifications;

  NotificationPreferences copyWith({
    bool? dailyChallengeReminders,
    bool? studyReminders,
    bool? learningActivityNotifications,
  }) {
    return NotificationPreferences(
      dailyChallengeReminders:
          dailyChallengeReminders ?? this.dailyChallengeReminders,
      studyReminders: studyReminders ?? this.studyReminders,
      learningActivityNotifications:
          learningActivityNotifications ?? this.learningActivityNotifications,
    );
  }
}

/// Complete persisted app settings & personalization state (non-sensitive only).
class AppSettings {
  const AppSettings({
    this.appLanguage = AppLanguage.hindi,
    this.themePreference = AppThemePreference.light,
    this.studyPreferences = const StudyPreferences(),
    this.notificationPreferences = const NotificationPreferences(),
  });

  final AppLanguage appLanguage;
  final AppThemePreference themePreference;
  final StudyPreferences studyPreferences;
  final NotificationPreferences notificationPreferences;

  AppSettings copyWith({
    AppLanguage? appLanguage,
    AppThemePreference? themePreference,
    StudyPreferences? studyPreferences,
    NotificationPreferences? notificationPreferences,
  }) {
    return AppSettings(
      appLanguage: appLanguage ?? this.appLanguage,
      themePreference: themePreference ?? this.themePreference,
      studyPreferences: studyPreferences ?? this.studyPreferences,
      notificationPreferences:
          notificationPreferences ?? this.notificationPreferences,
    );
  }

  Map<String, Object?> toDbRow() {
    return <String, Object?>{
      'id': 1,
      'app_language': appLanguage.code,
      'theme_preference': themePreference.code,
      'default_question_language':
          studyPreferences.defaultQuestionLanguage?.code,
      'preferred_difficulty': studyPreferences.preferredDifficulty?.code,
      'preferred_test_duration_minutes':
          studyPreferences.preferredTestDurationMinutes,
      'daily_goal_enabled': studyPreferences.dailyGoalEnabled ? 1 : 0,
      'daily_goal_target': studyPreferences.dailyGoalTarget,
      'notif_daily_challenge':
          notificationPreferences.dailyChallengeReminders ? 1 : 0,
      'notif_study_reminders': notificationPreferences.studyReminders ? 1 : 0,
      'notif_learning_activity':
          notificationPreferences.learningActivityNotifications ? 1 : 0,
    };
  }

  factory AppSettings.fromDbRow(Map<String, Object?> row) {
    final String? qLangRaw = row['default_question_language']?.toString();
    QuestionLanguage? qLang;
    if (qLangRaw != null && qLangRaw.isNotEmpty) {
      try {
        qLang = QuestionLanguage.fromCode(qLangRaw);
      } catch (_) {
        qLang = null;
      }
    }

    final String? diffRaw = row['preferred_difficulty']?.toString();
    QuestionDifficulty? diff;
    if (diffRaw != null && diffRaw.isNotEmpty) {
      try {
        diff = QuestionDifficulty.fromCode(diffRaw);
      } catch (_) {
        diff = null;
      }
    }

    return AppSettings(
      appLanguage: AppLanguage.fromCode(row['app_language']?.toString()),
      themePreference:
          AppThemePreference.fromCode(row['theme_preference']?.toString()),
      studyPreferences: StudyPreferences(
        defaultQuestionLanguage: qLang,
        preferredDifficulty: diff,
        preferredTestDurationMinutes:
            (row['preferred_test_duration_minutes'] as num?)?.toInt() ?? 15,
        dailyGoalEnabled: (row['daily_goal_enabled'] as num?)?.toInt() == 1,
        dailyGoalTarget: (row['daily_goal_target'] as num?)?.toInt() ?? 10,
      ),
      notificationPreferences: NotificationPreferences(
        dailyChallengeReminders:
            (row['notif_daily_challenge'] as num?)?.toInt() == 1,
        studyReminders: (row['notif_study_reminders'] as num?)?.toInt() == 1,
        learningActivityNotifications:
            (row['notif_learning_activity'] as num?)?.toInt() == 1,
      ),
    );
  }
}
