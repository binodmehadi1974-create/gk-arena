import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gk_arena/features/quiz/services/quiz_environment.dart';
import 'package:gk_arena/features/settings/localization/app_strings.dart';
import 'package:gk_arena/ui/design_system/app_theme.dart';
import 'package:gk_arena/ui/navigation/app_shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ),
  );
  runApp(const GkArenaApp());
}

class GkArenaApp extends StatefulWidget {
  const GkArenaApp({
    super.key,
    this.quizEnvironment,
  });

  final QuizEnvironment? quizEnvironment;

  @override
  State<GkArenaApp> createState() => _GkArenaAppState();
}

class _GkArenaAppState extends State<GkArenaApp> {
  late final QuizEnvironment _environment;
  late final bool _ownsEnvironment;

  @override
  void initState() {
    super.initState();
    _ownsEnvironment = widget.quizEnvironment == null;
    _environment = widget.quizEnvironment ?? QuizEnvironment();
    _environment.ensureInitialized();
  }

  @override
  void dispose() {
    if (_ownsEnvironment) {
      _environment.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _environment.settingsController,
      builder: (BuildContext context, _) {
        final settings = _environment.settingsController.settings;
        return AppLanguageScope(
          language: settings.appLanguage,
          child: MaterialApp(
            title: 'GK ARENA',
            debugShowCheckedModeBanner: false,
            theme: AppTheme.lightTheme,
            darkTheme: AppTheme.darkTheme,
            themeMode: settings.themePreference.themeMode,
            locale: settings.appLanguage.locale,
            home: AppShell(quizEnvironment: _environment),
          ),
        );
      },
    );
  }
}
