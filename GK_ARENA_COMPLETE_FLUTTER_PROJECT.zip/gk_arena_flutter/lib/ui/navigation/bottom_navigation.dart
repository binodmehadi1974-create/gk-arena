import 'package:flutter/material.dart';
import 'package:gk_arena/features/settings/localization/app_strings.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';

class BottomNavItemData {
  const BottomNavItemData({
    required this.label,
    required this.icon,
    required this.activeIcon,
  });

  final String label;
  final IconData icon;
  final IconData activeIcon;
}

/// Polished 4-destination bottom navigation bar for GK ARENA
/// supporting Hindi/English localization and Light/Dark themes.
class GkBottomNavigation extends StatelessWidget {
  const GkBottomNavigation({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  final int currentIndex;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    final AppStrings s = AppLanguageScope.of(context);
    final bool isDark = AppColors.isDark(context);
    final Color activeColor =
        isDark ? AppColors.primaryOnDark : AppColors.primary;
    final Color inactiveColor = AppColors.textSecondaryOf(context);

    final List<BottomNavItemData> items = <BottomNavItemData>[
      BottomNavItemData(
        label: s.navHome,
        icon: Icons.home_outlined,
        activeIcon: Icons.home_rounded,
      ),
      BottomNavItemData(
        label: s.navExplore,
        icon: Icons.grid_view_outlined,
        activeIcon: Icons.grid_view_rounded,
      ),
      BottomNavItemData(
        label: s.navTests,
        icon: Icons.assignment_outlined,
        activeIcon: Icons.assignment_rounded,
      ),
      BottomNavItemData(
        label: s.navProfile,
        icon: Icons.person_outline_rounded,
        activeIcon: Icons.person_rounded,
      ),
    ];

    return Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceOf(context),
        border: Border(
          top: BorderSide(color: AppColors.borderOf(context), width: 1),
        ),
        boxShadow: isDark
            ? const <BoxShadow>[]
            : const <BoxShadow>[
                BoxShadow(
                  color: Color(0x0A111C3A),
                  blurRadius: 16,
                  offset: Offset(0, -4),
                ),
              ],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.xs,
            vertical: AppSpacing.xs,
          ),
          child: Row(
            children: List<Widget>.generate(items.length, (int index) {
              final BottomNavItemData item = items[index];
              final bool isSelected = index == currentIndex;

              return Expanded(
                child: Semantics(
                  selected: isSelected,
                  button: true,
                  label: item.label,
                  child: InkWell(
                    onTap: () => onTap(index),
                    borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
                    child: AnimatedContainer(
                      duration: AppSpacing.motionFast,
                      curve: Curves.easeOutCubic,
                      padding: const EdgeInsets.symmetric(
                        vertical: AppSpacing.xs,
                        horizontal: AppSpacing.xxs,
                      ),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? AppColors.softBlueOf(context)
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Icon(
                            isSelected ? item.activeIcon : item.icon,
                            size: 22,
                            color: isSelected ? activeColor : inactiveColor,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            item.label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: AppTextStyles.navLabel.copyWith(
                              color: isSelected ? activeColor : inactiveColor,
                              fontWeight: isSelected
                                  ? FontWeight.w700
                                  : FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}
