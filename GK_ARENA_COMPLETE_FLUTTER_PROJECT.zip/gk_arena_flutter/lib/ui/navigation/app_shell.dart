import 'package:flutter/material.dart';
import 'package:gk_arena/features/quiz/services/quiz_environment.dart';
import 'package:gk_arena/ui/navigation/bottom_navigation.dart';
import 'package:gk_arena/ui/screens/explore/explore_screen.dart';
import 'package:gk_arena/ui/screens/home/home_screen.dart';
import 'package:gk_arena/ui/screens/profile/profile_screen.dart';
import 'package:gk_arena/ui/screens/tests/tests_screen.dart';

/// Root navigation shell preserving tab state via IndexedStack and owning
/// the shared QuizEnvironment for Question Bank, Test Engine & Learning Tracking.
class AppShell extends StatefulWidget {
  const AppShell({
    super.key,
    this.quizEnvironment,
  });

  final QuizEnvironment? quizEnvironment;

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _selectedIndex = 0;
  late final QuizEnvironment _quizEnvironment;
  late final bool _ownsEnvironment;

  @override
  void initState() {
    super.initState();
    _ownsEnvironment = widget.quizEnvironment == null;
    _quizEnvironment = widget.quizEnvironment ?? QuizEnvironment();
    _quizEnvironment.ensureInitialized();
  }

  @override
  void dispose() {
    if (_ownsEnvironment) {
      _quizEnvironment.dispose();
    }
    super.dispose();
  }

  void _switchTab(int index) {
    if (_selectedIndex == index) return;
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: <Widget>[
          HomeScreen(
            onOpenExplore: () => _switchTab(1),
            onOpenTests: () => _switchTab(2),
            onOpenProfile: () => _switchTab(3),
            quizEnvironment: _quizEnvironment,
          ),
          ExploreScreen(quizEnvironment: _quizEnvironment),
          TestsScreen(quizEnvironment: _quizEnvironment),
          ProfileScreen(quizEnvironment: _quizEnvironment),
        ],
      ),
      bottomNavigationBar: GkBottomNavigation(
        currentIndex: _selectedIndex,
        onTap: _switchTab,
      ),
    );
  }
}
