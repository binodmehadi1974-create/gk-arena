import 'package:flutter/material.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/widgets/premium_button.dart';
import 'package:gk_arena/ui/widgets/state_views.dart';

/// Polished selection/placeholder screen opened from any test option in Stage 1.
class TestPlaceholderScreen extends StatelessWidget {
  const TestPlaceholderScreen({
    super.key,
    required this.title,
    required this.hindiTitle,
    required this.description,
    required this.icon,
  });

  final String title;
  final String hindiTitle;
  final String description;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, AppSpacing.md, 20, AppSpacing.lg),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(AppSpacing.lg),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
              border: Border.all(color: AppColors.border, width: 1),
              boxShadow: AppSpacing.softCardShadow,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    color: AppColors.softBlueSurface,
                    borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
                  ),
                  child: Icon(
                    icon,
                    color: AppColors.primary,
                    size: 28,
                  ),
                ),
                const SizedBox(height: AppSpacing.md),
                Text(title, style: AppTextStyles.sectionTitle),
                const SizedBox(height: 4),
                Text(
                  hindiTitle,
                  style: AppTextStyles.bodyPrimary.copyWith(
                    color: AppColors.primary,
                  ),
                ),
                const SizedBox(height: AppSpacing.sm),
                Text(description, style: AppTextStyles.body),
                const SizedBox(height: AppSpacing.lg),
                const GkStageNoticeBanner(
                  message:
                      'टेस्ट इंटरफ़ेस और प्रश्न सेट अगले विकास चरण में जोड़े जाएंगे। अभी यह चयन स्क्रीन UI पूर्वावलोकन के लिए है।',
                ),
                const SizedBox(height: AppSpacing.lg),
                PremiumButton(
                  label: 'Test Centre पर वापस जाएं',
                  variant: PremiumButtonVariant.primary,
                  fullWidth: true,
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
