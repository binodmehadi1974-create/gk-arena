import 'package:flutter/material.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/widgets/premium_button.dart';

/// Prominent Full Mock Test hero card on the Test Centre screen.
class FullMockHeroCard extends StatelessWidget {
  const FullMockHeroCard({
    super.key,
    required this.onSelectMockTest,
  });

  final VoidCallback onSelectMockTest;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: AppColors.heroGradient,
        borderRadius: BorderRadius.circular(AppSpacing.radiusXl),
        boxShadow: AppSpacing.heroCardShadow,
      ),
      child: Stack(
        children: <Widget>[
          Positioned(
            top: -20,
            right: -18,
            child: IgnorePointer(
              child: Container(
                width: 112,
                height: 112,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(0x1C19B8C8),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: const Color(0x24FFFFFF),
                        borderRadius: BorderRadius.circular(AppSpacing.radiusSm),
                      ),
                      child: const Icon(
                        Icons.workspace_premium_outlined,
                        color: AppColors.accentTeal,
                        size: 22,
                      ),
                    ),
                    const SizedBox(width: AppSpacing.sm),
                    const Expanded(
                      child: Text(
                        'Full Mock Test',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTextStyles.heroTitle,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppSpacing.sm),
                const Text(
                  'एक वास्तविक परीक्षा जैसा अभ्यास अनुभव।',
                  style: AppTextStyles.heroSubtitle,
                ),
                const SizedBox(height: AppSpacing.lg),
                PremiumButton(
                  label: 'मॉक टेस्ट चुनें',
                  variant: PremiumButtonVariant.lightOnDark,
                  trailingIcon: Icons.arrow_forward_rounded,
                  onPressed: onSelectMockTest,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
