import 'package:flutter/material.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/features/monetization/ui/widgets/gk_banner_ad_slot.dart';
import 'package:gk_arena/features/quiz/services/quiz_environment.dart';
import 'package:gk_arena/features/quiz/ui/screens/test_config_screen.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/navigation/smooth_page_route.dart';
import 'package:gk_arena/ui/screens/tests/widgets/full_mock_hero_card.dart';
import 'package:gk_arena/ui/screens/tests/widgets/test_type_card.dart';
import 'package:gk_arena/ui/widgets/section_header.dart';

class _TestOptionItem {
  const _TestOptionItem({
    required this.mode,
    required this.icon,
    required this.iconColor,
    required this.iconBackground,
  });

  final TestMode mode;
  final IconData icon;
  final Color iconColor;
  final Color iconBackground;
}

/// Screen 3 — Test Centre connected to the working Quiz Engine across all test modes.
class TestsScreen extends StatelessWidget {
  const TestsScreen({
    super.key,
    required this.quizEnvironment,
  });

  final QuizEnvironment quizEnvironment;

  static const List<_TestOptionItem> _testTypes = <_TestOptionItem>[
    _TestOptionItem(
      mode: TestMode.subjectWise,
      icon: Icons.layers_outlined,
      iconColor: AppColors.primary,
      iconBackground: AppColors.softBlueSurface,
    ),
    _TestOptionItem(
      mode: TestMode.topicWise,
      icon: Icons.topic_outlined,
      iconColor: AppColors.accentTeal,
      iconBackground: AppColors.softTealSurface,
    ),
    _TestOptionItem(
      mode: TestMode.mixedGk,
      icon: Icons.shuffle_rounded,
      iconColor: AppColors.accentTeal,
      iconBackground: AppColors.softTealSurface,
    ),
    _TestOptionItem(
      mode: TestMode.timed,
      icon: Icons.timer_outlined,
      iconColor: AppColors.warning,
      iconBackground: AppColors.softAmberSurface,
    ),
    _TestOptionItem(
      mode: TestMode.dailyChallenge,
      icon: Icons.lightbulb_outline_rounded,
      iconColor: AppColors.success,
      iconBackground: AppColors.softGreenSurface,
    ),
    _TestOptionItem(
      mode: TestMode.previousYear,
      icon: Icons.history_edu_outlined,
      iconColor: AppColors.deepNavy,
      iconBackground: AppColors.softIndigoSurface,
    ),
    _TestOptionItem(
      mode: TestMode.practice,
      icon: Icons.edit_note_rounded,
      iconColor: AppColors.primary,
      iconBackground: AppColors.softBlueSurface,
    ),
  ];

  void _openTestConfig(BuildContext context, TestMode mode) {
    Navigator.of(context).push(
      SmoothPageRoute<void>(
        builder: (_) => TestConfigScreen(
          mode: mode,
          environment: quizEnvironment,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, AppSpacing.md, 20, AppSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Text('Test Centre', style: AppTextStyles.pageTitle),
            const SizedBox(height: AppSpacing.xxs),
            const Text(
              'अभ्यास करें, खुद को परखें और बेहतर बनें।',
              style: AppTextStyles.body,
            ),
            const SizedBox(height: AppSpacing.lg),
            FullMockHeroCard(
              onSelectMockTest: () =>
                  _openTestConfig(context, TestMode.fullMock),
            ),
            const SizedBox(height: AppSpacing.lg),
            const SectionHeader(
              title: 'अभ्यास के प्रकार',
              subtitle: 'अपनी आवश्यकता के अनुसार टेस्ट चुनें।',
            ),
            const SizedBox(height: AppSpacing.md),
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _testTypes.length,
              separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.sm),
              itemBuilder: (BuildContext context, int index) {
                final _TestOptionItem item = _testTypes[index];
                return TestTypeCard(
                  title: item.mode.titleEn,
                  description: item.mode.description,
                  icon: item.icon,
                  iconColor: item.iconColor,
                  iconBackground: item.iconBackground,
                  onTap: () => _openTestConfig(context, item.mode),
                );
              },
            ),
            const SizedBox(height: AppSpacing.md),
            GkBannerAdSlot(policyService: quizEnvironment?.adManager.policyService),
          ],
        ),
      ),
    );
  }
}
