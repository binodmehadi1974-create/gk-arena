import 'package:flutter/material.dart';
import 'package:gk_arena/features/learning/models/learning_models.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/question_bank/models/question_model.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/features/quiz/services/quiz_environment.dart';
import 'package:gk_arena/features/quiz/ui/screens/quiz_screen.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/navigation/smooth_page_route.dart';
import 'package:gk_arena/ui/screens/explore/widgets/category_filter_bar.dart';
import 'package:gk_arena/ui/widgets/premium_button.dart';
import 'package:gk_arena/ui/widgets/state_views.dart';

/// Dedicated Bookmarks screen wired to persistent bookmarks with subject
/// filtering, full question preview, removal, and direct bookmark practice.
class BookmarksScreen extends StatefulWidget {
  const BookmarksScreen({
    super.key,
    this.quizEnvironment,
  });

  final QuizEnvironment? quizEnvironment;

  @override
  State<BookmarksScreen> createState() => _BookmarksScreenState();
}

class _BookmarksScreenState extends State<BookmarksScreen> {
  static const String _allFilter = 'All';

  late final List<String> _filters = <String>[
    _allFilter,
    ...QuestionSubject.values.map((QuestionSubject s) => s.titleEn),
  ];

  String _selectedFilter = _allFilter;
  bool _loading = true;
  List<ResolvedBookmark> _bookmarks = const <ResolvedBookmark>[];

  @override
  void initState() {
    super.initState();
    widget.quizEnvironment?.learningRepository.addListener(_onLearningChanged);
    _loadBookmarks();
  }

  @override
  void dispose() {
    widget.quizEnvironment?.learningRepository
        .removeListener(_onLearningChanged);
    super.dispose();
  }

  void _onLearningChanged() {
    _loadBookmarks();
  }

  QuestionSubject? get _selectedSubject {
    if (_selectedFilter == _allFilter) return null;
    for (final QuestionSubject subject in QuestionSubject.values) {
      if (subject.titleEn == _selectedFilter) return subject;
    }
    return null;
  }

  Future<void> _loadBookmarks() async {
    final QuizEnvironment? env = widget.quizEnvironment;
    if (env == null) {
      if (mounted) {
        setState(() {
          _bookmarks = const <ResolvedBookmark>[];
          _loading = false;
        });
      }
      return;
    }
    await env.ensureInitialized();
    final List<ResolvedBookmark> items =
        await env.learningRepository.getResolvedBookmarks(
      subject: _selectedSubject,
    );
    if (!mounted) return;
    setState(() {
      _bookmarks = items;
      _loading = false;
    });
  }

  Future<void> _removeBookmark(String questionId) async {
    final QuizEnvironment? env = widget.quizEnvironment;
    if (env == null) return;
    await env.learningRepository.removeBookmark(questionId);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        duration: Duration(seconds: 1),
        content: Text('बुकमार्क हटाया गया।'),
      ),
    );
  }

  void _practiceBookmarks() {
    final QuizEnvironment? env = widget.quizEnvironment;
    if (env == null || _bookmarks.isEmpty) return;

    final List<Question> questions =
        _bookmarks.map((ResolvedBookmark b) => b.question).toList(growable: false);
    final Set<QuestionSubject> subjects =
        questions.map((Question q) => q.subject).toSet();

    Navigator.of(context).push(
      SmoothPageRoute<void>(
        builder: (_) => QuizScreen(
          config: QuizConfig(
            mode: TestMode.practice,
            subjects: subjects.toList(growable: false),
            questionCount: questions.length,
            scoringRules: ScoringRules.noNegative,
            allowRepeatRecent: true,
          ),
          questions: questions,
          environment: env,
        ),
      ),
    );
  }

  void _openBookmarkDetail(ResolvedBookmark bookmark) {
    const List<String> labels = <String>['A', 'B', 'C', 'D'];
    final Question q = bookmark.question;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surfaceOf(context),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(AppSpacing.radiusXl),
        ),
      ),
      builder: (BuildContext sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Text(
                        '${q.subject.titleEn} • ${q.topic}',
                        style: AppTextStyles.badgeLabel.copyWith(
                          color: AppColors.primary,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: () => Navigator.of(sheetContext).pop(),
                        icon: const Icon(Icons.close_rounded),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.xs),
                  Text(
                    q.questionText,
                    style: AppTextStyles.bodyPrimary.copyWith(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  ...List<Widget>.generate(q.options.length, (int idx) {
                    final bool isCorrect = idx == q.correctOptionIndex;
                    return Container(
                      width: double.infinity,
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 10,
                      ),
                      decoration: BoxDecoration(
                        color: isCorrect
                            ? AppColors.softGreenSurface
                            : AppColors.background,
                        borderRadius:
                            BorderRadius.circular(AppSpacing.radiusSm),
                        border: Border.all(
                          color:
                              isCorrect ? AppColors.success : AppColors.border,
                        ),
                      ),
                      child: Text(
                        '${labels[idx]}. ${q.options[idx]}',
                        style: AppTextStyles.bodyPrimary.copyWith(
                          fontWeight:
                              isCorrect ? FontWeight.w600 : FontWeight.w500,
                        ),
                      ),
                    );
                  }),
                  const SizedBox(height: AppSpacing.xs),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(AppSpacing.sm),
                    decoration: BoxDecoration(
                      color: AppColors.softBlueSurface,
                      borderRadius: BorderRadius.circular(AppSpacing.radiusSm),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        const Text(
                          'व्याख्या / Explanation',
                          style: AppTextStyles.badgeLabel,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          q.explanation,
                          style: AppTextStyles.body.copyWith(
                            color: AppColors.textPrimary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bookmarks'),
      ),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(
                20,
                AppSpacing.sm,
                20,
                AppSpacing.sm,
              ),
              child: CategoryFilterBar(
                categories: _filters,
                selectedCategory: _selectedFilter,
                onSelected: (String value) {
                  setState(() {
                    _selectedFilter = value;
                    _loading = true;
                  });
                  _loadBookmarks();
                },
              ),
            ),
            if (!_loading && _bookmarks.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, AppSpacing.sm),
                child: PremiumButton(
                  label: 'Practice Bookmarks (${_bookmarks.length})',
                  variant: PremiumButtonVariant.primary,
                  trailingIcon: Icons.play_arrow_rounded,
                  fullWidth: true,
                  onPressed: _practiceBookmarks,
                ),
              ),
            Expanded(
              child: _loading
                  ? const Padding(
                    padding: EdgeInsets.all(20),
                    child: GkLoadingPlaceholderCard(lineCount: 4),
                  )
                  : _bookmarks.isEmpty
                      ? Padding(
                          padding: const EdgeInsets.all(20),
                          child: GkEmptyStateCard(
                            icon: Icons.bookmark_border_rounded,
                            badgeText: 'No Saved Items Yet',
                            title: _selectedFilter == _allFilter
                                ? 'अभी कोई बुकमार्क सहेजा नहीं गया है'
                                : '$_selectedFilter में कोई बुकमार्क नहीं है',
                            description:
                                'टेस्ट देते समय या उत्तर समीक्षा में किसी भी प्रश्न को बुकमार्क करें — वे त्वरित अभ्यास के लिए यहाँ सुरक्षित रहेंगे।',
                            actionLabel: 'वापस जाएं',
                            onActionTap: () => Navigator.of(context).pop(),
                          ),
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(
                            20,
                            AppSpacing.xs,
                            20,
                            AppSpacing.lg,
                          ),
                          itemCount: _bookmarks.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: AppSpacing.md),
                          itemBuilder: (BuildContext context, int index) {
                            final ResolvedBookmark item = _bookmarks[index];
                            return _BookmarkCard(
                              bookmark: item,
                              onTap: () => _openBookmarkDetail(item),
                              onRemove: () => _removeBookmark(item.question.id),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BookmarkCard extends StatelessWidget {
  const _BookmarkCard({
    required this.bookmark,
    required this.onTap,
    required this.onRemove,
  });

  final ResolvedBookmark bookmark;
  final VoidCallback onTap;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    final Question q = bookmark.question;
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceOf(context),
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        border: Border.all(color: AppColors.borderOf(context), width: 1),
        boxShadow: AppSpacing.softCardShadow,
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.md),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.softBlueSurface,
                        borderRadius:
                            BorderRadius.circular(AppSpacing.radiusPill),
                      ),
                      child: Text(
                        q.subject.titleEn,
                        style: AppTextStyles.badgeLabel.copyWith(
                          color: AppColors.primary,
                        ),
                      ),
                    ),
                    const SizedBox(width: AppSpacing.xs),
                    Expanded(
                      child: Text(
                        q.topic,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTextStyles.cardSubtitle,
                      ),
                    ),
                    IconButton(
                      tooltip: 'Remove Bookmark',
                      visualDensity: VisualDensity.compact,
                      onPressed: onRemove,
                      icon: const Icon(
                        Icons.bookmark_remove_outlined,
                        size: 20,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppSpacing.xs),
                Text(
                  q.questionText,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.bodyPrimary.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: AppSpacing.xs),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Text(
                      'View Answer & Explanation',
                      style: AppTextStyles.linkAction,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
