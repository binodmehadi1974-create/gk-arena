import 'package:flutter/material.dart';
import 'package:gk_arena/features/learning/models/learning_models.dart';
import 'package:gk_arena/features/learning/ui/screens/test_history_screen.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/quiz/services/quiz_environment.dart';
import 'package:gk_arena/features/quiz/ui/screens/quiz_result_screen.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/navigation/smooth_page_route.dart';
import 'package:gk_arena/ui/widgets/state_views.dart';

/// Real-data Student Dashboard & Subject-wise Analytics screen.
/// Displays zero fabricated stats, clean empty state for new users,
/// optional pressure-free daily learning goal, recent tests, and all 12 subjects.
class LearningProgressScreen extends StatefulWidget {
  const LearningProgressScreen({
    super.key,
    this.quizEnvironment,
  });

  final QuizEnvironment? quizEnvironment;

  @override
  State<LearningProgressScreen> createState() => _LearningProgressScreenState();
}

class _LearningProgressScreenState extends State<LearningProgressScreen> {
  static const List<int> _goalTargets = <int>[5, 10, 20, 30, 50];

  bool _loading = true;
  String? _loadError;
  StudentDashboardSummary? _summary;

  @override
  void initState() {
    super.initState();
    widget.quizEnvironment?.learningRepository.addListener(_onLearningChanged);
    _loadDashboard();
  }

  @override
  void dispose() {
    widget.quizEnvironment?.learningRepository
        .removeListener(_onLearningChanged);
    super.dispose();
  }

  void _onLearningChanged() {
    _loadDashboard();
  }

  Future<void> _loadDashboard() async {
    final QuizEnvironment? env = widget.quizEnvironment;
    if (env == null) {
      if (mounted) {
        setState(() {
          _summary = null;
          _loadError = null;
          _loading = false;
        });
      }
      return;
    }
    try {
      await env.ensureInitialized();
      final StudentDashboardSummary data =
          await env.learningRepository.getDashboardSummary();
      if (!mounted) return;
      setState(() {
        _summary = data;
        _loadError = null;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loadError = 'लर्निंग प्रगति लोड करने में समस्या आई। कृपया पुनः प्रयास करें।';
        _loading = false;
      });
    }
  }

  Future<void> _updateDailyGoal({
    required bool isEnabled,
    required int target,
  }) async {
    final QuizEnvironment? env = widget.quizEnvironment;
    if (env == null) return;
    await env.learningRepository.saveDailyGoal(
      isEnabled: isEnabled,
      dailyQuestionTarget: target,
    );
  }

  String _formatDuration(int totalSeconds) {
    final int mins = totalSeconds ~/ 60;
    final int secs = totalSeconds % 60;
    if (mins == 0) return '${secs}s';
    return '${mins}m ${secs}s';
  }

  @override
  Widget build(BuildContext context) {
    final StudentDashboardSummary? summary = _summary;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Learning Progress'),
      ),
      body: SafeArea(
        child: _loading
            ? const Padding(
                padding: EdgeInsets.all(20),
                child: GkLoadingPlaceholderCard(lineCount: 4),
              )
            : _loadError != null
                ? Padding(
                    padding: const EdgeInsets.all(20),
                    child: GkErrorRetryCard(
                      title: 'डेटा लोड नहीं हो सका',
                      message: _loadError!,
                      retryLabel: 'पुनः प्रयास करें',
                      onRetry: () {
                        setState(() {
                          _loading = true;
                          _loadError = null;
                        });
                        _loadDashboard();
                      },
                    ),
                  )
            : RefreshIndicator(
                onRefresh: _loadDashboard,
                child: SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(
                    20,
                    AppSpacing.sm,
                    20,
                    AppSpacing.lg,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      if (summary == null || !summary.hasActivity)
                        GkEmptyStateCard(
                          icon: Icons.insights_outlined,
                          badgeText: 'New Learner Dashboard',
                          title: 'आपकी वास्तविक प्रगति यहाँ दिखाई देगी',
                          description:
                              'अपना पहला टेस्ट या अभ्यास शुरू करें। पूरा होते ही आपका स्कोर, सटीकता और विषय-वार विश्लेषण यहाँ स्वतः अपडेट होगा।',
                          actionLabel: 'वापस जाएं',
                          onActionTap: () => Navigator.of(context).pop(),
                        )
                      else ...<Widget>[
                        // Real-data Hero Summary Card
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(AppSpacing.lg),
                          decoration: BoxDecoration(
                            gradient: AppColors.heroGradient,
                            borderRadius:
                                BorderRadius.circular(AppSpacing.radiusXl),
                            boxShadow: AppSpacing.heroCardShadow,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                'Overall Accuracy',
                                style: AppTextStyles.heroSubtitle.copyWith(
                                  color: AppColors.textOnDark,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${summary.overallAccuracyPercent}%',
                                style: const TextStyle(
                                  fontSize: 34,
                                  fontWeight: FontWeight.w800,
                                  color: AppColors.textOnDark,
                                  height: 1.1,
                                ),
                              ),
                              const SizedBox(height: AppSpacing.sm),
                              Text(
                                '${summary.totalTestsAttempted} Tests  •  '
                                '${summary.totalQuestionsAttempted} Questions Attempted  •  '
                                '${_formatDuration(summary.totalTimeSpentSeconds)}',
                                style: AppTextStyles.heroSubtitle,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: AppSpacing.md),
                        Row(
                          children: <Widget>[
                            Expanded(
                              child: _DashboardMetricTile(
                                label: 'Correct',
                                value: '${summary.totalCorrect}',
                                color: AppColors.success,
                                background: AppColors.softGreenSurface,
                              ),
                            ),
                            const SizedBox(width: AppSpacing.sm),
                            Expanded(
                              child: _DashboardMetricTile(
                                label: 'Incorrect',
                                value: '${summary.totalIncorrect}',
                                color: const Color(0xFFD64545),
                                background: const Color(0xFFFDECEC),
                              ),
                            ),
                            const SizedBox(width: AppSpacing.sm),
                            Expanded(
                              child: _DashboardMetricTile(
                                label: 'Skipped',
                                value: '${summary.totalUnattempted}',
                                color: AppColors.textSecondary,
                                background: AppColors.surface,
                              ),
                            ),
                          ],
                        ),
                      ],
                      const SizedBox(height: AppSpacing.lg),

                      // Optional Daily Learning Goal Card
                      if (summary != null)
                        _DailyGoalCard(
                          summary: summary,
                          targets: _goalTargets,
                          onToggle: (bool enabled) => _updateDailyGoal(
                            isEnabled: enabled,
                            target: summary.dailyGoal.dailyQuestionTarget,
                          ),
                          onSelectTarget: (int target) => _updateDailyGoal(
                            isEnabled: true,
                            target: target,
                          ),
                        ),

                      if (summary != null && summary.recentTests.isNotEmpty) ...<Widget>[
                        const SizedBox(height: AppSpacing.lg),
                        Row(
                          children: <Widget>[
                            const Expanded(
                              child: Text(
                                'Recent Tests',
                                style: AppTextStyles.sectionTitle.copyWith(color: AppColors.textPrimaryOf(context)),
                              ),
                            ),
                            if (widget.quizEnvironment != null)
                              TextButton(
                                onPressed: () {
                                  Navigator.of(context).push(
                                    SmoothPageRoute<void>(
                                      builder: (_) => TestHistoryScreen(
                                        environment: widget.quizEnvironment!,
                                      ),
                                    ),
                                  );
                                },
                                child: const Text(
                                  'View All',
                                  style: AppTextStyles.linkAction,
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: AppSpacing.xs),
                        Container(
                          decoration: BoxDecoration(
                            color: AppColors.surfaceOf(context),
                            borderRadius:
                                BorderRadius.circular(AppSpacing.radiusLg),
                            border: Border.all(color: AppColors.borderOf(context)),
                            boxShadow: AppSpacing.softCardShadow,
                          ),
                          clipBehavior: Clip.antiAlias,
                          child: Column(
                            children: List<Widget>.generate(
                              summary.recentTests.length,
                              (int idx) {
                                final TestHistoryRecord test =
                                    summary.recentTests[idx];
                                final bool isLast =
                                    idx == summary.recentTests.length - 1;
                                return Column(
                                  children: <Widget>[
                                    ListTile(
                                      title: Text(
                                        test.testMode.titleEn,
                                        style: AppTextStyles.cardTitle.copyWith(color: AppColors.textPrimaryOf(context)),
                                      ),
                                      subtitle: Text(
                                        '${test.subjectLabel} • Score ${test.score}/${test.maxScore}',
                                        style: AppTextStyles.cardSubtitle.copyWith(color: AppColors.textSecondaryOf(context)),
                                      ),
                                      trailing: Text(
                                        '${test.accuracyPercent}%',
                                        style: AppTextStyles.chipLabel.copyWith(
                                          color: AppColors.primary,
                                        ),
                                      ),
                                      onTap: widget.quizEnvironment == null
                                          ? null
                                          : () {
                                              Navigator.of(context).push(
                                                SmoothPageRoute<void>(
                                                  builder: (_) =>
                                                      QuizResultScreen(
                                                    result: test.toQuizResult(),
                                                    environment:
                                                        widget.quizEnvironment!,
                                                    isHistoricalView: true,
                                                  ),
                                                ),
                                              );
                                            },
                                    ),
                                    if (!isLast) const Divider(height: 1),
                                  ],
                                );
                              },
                            ),
                          ),
                        ),
                      ],

                      const SizedBox(height: AppSpacing.lg),
                      Text(
                        'Subject-wise Performance',
                        style: AppTextStyles.sectionTitle.copyWith(color: AppColors.textPrimaryOf(context)),
                      ),
                      const SizedBox(height: AppSpacing.sm),
                      Container(
                        decoration: BoxDecoration(
                          color: AppColors.surfaceOf(context),
                          borderRadius:
                              BorderRadius.circular(AppSpacing.radiusLg),
                          border: Border.all(color: AppColors.borderOf(context), width: 1),
                          boxShadow: AppSpacing.softCardShadow,
                        ),
                        clipBehavior: Clip.antiAlias,
                        child: Column(
                          children: List<Widget>.generate(
                            QuestionSubject.values.length,
                            (int index) {
                              final SubjectAnalytics stats = summary != null
                                  ? summary.subjectAnalytics[index]
                                  : SubjectAnalytics(
                                      subject: QuestionSubject.values[index],
                                      testsAttempted: 0,
                                      questionsPracticed: 0,
                                      correctCount: 0,
                                      incorrectCount: 0,
                                      unattemptedCount: 0,
                                      accuracyPercent: 0.0,
                                      pendingWrongCount: 0,
                                      masteredWrongCount: 0,
                                    );
                              final bool isLast =
                                  index == QuestionSubject.values.length - 1;
                              return Column(
                                children: <Widget>[
                                  _SubjectAnalyticsRow(stats: stats),
                                  if (!isLast) const Divider(indent: 16),
                                ],
                              );
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}

class _DailyGoalCard extends StatelessWidget {
  const _DailyGoalCard({
    required this.summary,
    required this.targets,
    required this.onToggle,
    required this.onSelectTarget,
  });

  final StudentDashboardSummary summary;
  final List<int> targets;
  final ValueChanged<bool> onToggle;
  final ValueChanged<int> onSelectTarget;

  @override
  Widget build(BuildContext context) {
    final DailyLearningGoal goal = summary.dailyGoal;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: AppColors.surfaceOf(context),
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        border: Border.all(color: AppColors.borderOf(context), width: 1),
        boxShadow: AppSpacing.softCardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Daily Learning Goal (Optional)',
                      style: AppTextStyles.cardTitle.copyWith(color: AppColors.textPrimaryOf(context)),
                    ),
                    SizedBox(height: 2),
                    Text(
                      'बिना दबाव के दैनिक अभ्यास लक्ष्य चुनें',
                      style: AppTextStyles.cardSubtitle.copyWith(color: AppColors.textSecondaryOf(context)),
                    ),
                  ],
                ),
              ),
              Switch(
                value: goal.isEnabled,
                onChanged: onToggle,
              ),
            ],
          ),
          if (goal.isEnabled) ...<Widget>[
            const SizedBox(height: AppSpacing.sm),
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    'Today: ${summary.todayQuestionsAttempted} / ${goal.dailyQuestionTarget} questions',
                    style: AppTextStyles.bodyPrimary.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                if (summary.isDailyGoalMet)
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.softGreenSurface,
                      borderRadius:
                          BorderRadius.circular(AppSpacing.radiusPill),
                    ),
                    child: Text(
                      'Goal Reached',
                      style: AppTextStyles.badgeLabel.copyWith(
                        color: AppColors.success,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: AppSpacing.xs),
            ClipRRect(
              borderRadius: BorderRadius.circular(AppSpacing.radiusPill),
              child: LinearProgressIndicator(
                value: summary.dailyGoalProgress,
                minHeight: 8,
                backgroundColor: AppColors.background,
                valueColor: AlwaysStoppedAnimation<Color>(
                  summary.isDailyGoalMet
                      ? AppColors.success
                      : AppColors.primary,
                ),
              ),
            ),
            const SizedBox(height: AppSpacing.sm),
            Wrap(
              spacing: AppSpacing.xs,
              runSpacing: AppSpacing.xs,
              children: targets.map((int t) {
                final bool selected = goal.dailyQuestionTarget == t;
                return ChoiceChip(
                  label: Text('$t Qs'),
                  selected: selected,
                  onSelected: (_) => onSelectTarget(t),
                );
              }).toList(growable: false),
            ),
          ],
        ],
      ),
    );
  }
}

class _SubjectAnalyticsRow extends StatelessWidget {
  const _SubjectAnalyticsRow({required this.stats});

  final SubjectAnalytics stats;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.md,
        vertical: 12,
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  stats.subject.titleEn,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.cardTitle.copyWith(color: AppColors.textPrimaryOf(context)),
                ),
                const SizedBox(height: 2),
                Text(
                  stats.hasActivity
                      ? '${stats.testsAttempted} tests • ${stats.questionsPracticed} practiced (${stats.correctCount}✓ / ${stats.incorrectCount}✗)'
                      : stats.subject.titleHi,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.cardSubtitle.copyWith(color: AppColors.textSecondaryOf(context)),
                ),
              ],
            ),
          ),
          const SizedBox(width: AppSpacing.sm),
          if (!stats.hasActivity)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.background,
                borderRadius: BorderRadius.circular(AppSpacing.radiusPill),
                border: Border.all(color: AppColors.borderOf(context), width: 1),
              ),
              child: Text(
                'Not Started',
                style: AppTextStyles.cardSubtitle.copyWith(color: AppColors.textSecondaryOf(context)),
              ),
            )
          else
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(
                  '${stats.accuracyPercent}%',
                  style: AppTextStyles.cardTitle.copyWith(
                    color: stats.needsRevision
                        ? AppColors.warning
                        : AppColors.success,
                  ),
                ),
                if (stats.needsRevision)
                  Text(
                    'Needs Revision',
                    style: AppTextStyles.badgeLabel.copyWith(
                      color: AppColors.warning,
                    ),
                  ),
              ],
            ),
        ],
      ),
    );
  }
}

class _DashboardMetricTile extends StatelessWidget {
  const _DashboardMetricTile({
    required this.label,
    required this.value,
    required this.color,
    required this.background,
  });

  final String label;
  final String value;
  final Color color;
  final Color background;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.sm,
        vertical: AppSpacing.md,
      ),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        border: Border.all(color: AppColors.borderOf(context), width: 1),
      ),
      child: Column(
        children: <Widget>[
          Text(
            value,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w800,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: AppTextStyles.cardSubtitle.copyWith(color: AppColors.textSecondaryOf(context)),
          ),
        ],
      ),
    );
  }
}
