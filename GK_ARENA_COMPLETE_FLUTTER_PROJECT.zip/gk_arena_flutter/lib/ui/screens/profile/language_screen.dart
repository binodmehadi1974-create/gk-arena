import 'package:flutter/material.dart';
import 'package:gk_arena/features/settings/controllers/settings_controller.dart';
import 'package:gk_arena/features/settings/localization/app_strings.dart';
import 'package:gk_arena/features/settings/models/app_settings.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';

class _LanguageOption {
  const _LanguageOption({
    required this.language,
    required this.title,
    required this.subtitleHi,
    required this.subtitleEn,
    required this.badge,
  });

  final AppLanguage language;
  final String title;
  final String subtitleHi;
  final String subtitleEn;
  final String badge;
}

/// Persistent App Interface Language selection screen (Hindi / English).
/// Updates the entire app UI immediately and keeps question language separate.
class LanguageScreen extends StatelessWidget {
  const LanguageScreen({
    super.key,
    this.settingsController,
  });

  final SettingsController? settingsController;

  static const List<_LanguageOption> _options = <_LanguageOption>[
    _LanguageOption(
      language: AppLanguage.hindi,
      title: 'हिन्दी (Hindi)',
      subtitleHi: 'ऐप के सभी मेन्यू, बटन और लेबल हिन्दी देवनागरी में।',
      subtitleEn: 'App menus, buttons, and labels in Hindi Devanagari.',
      badge: 'हिन्दी',
    ),
    _LanguageOption(
      language: AppLanguage.english,
      title: 'English',
      subtitleHi: 'साफ़ और स्पष्ट अंग्रेज़ी इंटरफ़ेस।',
      subtitleEn: 'Clean and concise English app interface.',
      badge: 'EN',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final AppStrings s = AppLanguageScope.of(context);
    final AppLanguage activeLanguage =
        settingsController?.appLanguage ?? AppLanguageScope.languageOf(context);
    final Color surface = AppColors.surfaceOf(context);
    final Color border = AppColors.borderOf(context);
    final Color textPrimary = AppColors.textPrimaryOf(context);
    final Color textSecondary = AppColors.textSecondaryOf(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(s.appLanguageTitle),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(
            20,
            AppSpacing.sm,
            20,
            AppSpacing.lg,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                s.t(
                  hi: 'ऐप इंटरफ़ेस की भाषा चुनें',
                  en: 'Choose App Interface Language',
                ),
                style: AppTextStyles.sectionTitle.copyWith(color: textPrimary),
              ),
              const SizedBox(height: AppSpacing.xxs),
              Text(
                s.t(
                  hi: 'चयन करते ही पूरा ऐप तुरंत अपडेट होगा और रीस्टार्ट के बाद भी सुरक्षित रहेगा। प्रश्नों की भाषा आप Study Preferences में अलग से चुन सकते हैं।',
                  en: 'The app updates immediately and remembers your choice after restart. You can configure question language separately in Study Preferences.',
                ),
                style: AppTextStyles.body.copyWith(color: textSecondary),
              ),
              const SizedBox(height: AppSpacing.md),
              ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _options.length,
                separatorBuilder: (_, __) =>
                    const SizedBox(height: AppSpacing.sm),
                itemBuilder: (BuildContext context, int index) {
                  final _LanguageOption option = _options[index];
                  final bool isSelected = option.language == activeLanguage;

                  return AnimatedContainer(
                    duration: AppSpacing.motionFast,
                    curve: Curves.easeOutCubic,
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppColors.softBlueOf(context)
                          : surface,
                      borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
                      border: Border.all(
                        color: isSelected ? AppColors.primary : border,
                        width: isSelected ? 1.5 : 1,
                      ),
                    ),
                    child: Material(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
                      child: InkWell(
                        onTap: () async {
                          await settingsController?.setAppLanguage(option.language);
                          if (!context.mounted) return;
                          ScaffoldMessenger.of(context)
                            ..hideCurrentSnackBar()
                            ..showSnackBar(
                              SnackBar(
                                duration: const Duration(seconds: 1),
                                content: Text(
                                  option.language == AppLanguage.hindi
                                      ? 'ऐप भाषा हिन्दी में सहेजी गई।'
                                      : 'App language saved to English.',
                                ),
                              ),
                            );
                        },
                        borderRadius:
                            BorderRadius.circular(AppSpacing.radiusMd),
                        child: Padding(
                          padding: const EdgeInsets.all(AppSpacing.md),
                          child: Row(
                            children: <Widget>[
                              Icon(
                                isSelected
                                    ? Icons.radio_button_checked_rounded
                                    : Icons.radio_button_off_rounded,
                                color: isSelected
                                    ? AppColors.primary
                                    : textSecondary,
                                size: 22,
                              ),
                              const SizedBox(width: AppSpacing.sm),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Text(
                                      option.title,
                                      style: AppTextStyles.cardTitle
                                          .copyWith(color: textPrimary),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      s.isHindi
                                          ? option.subtitleHi
                                          : option.subtitleEn,
                                      style: AppTextStyles.cardSubtitle
                                          .copyWith(color: textSecondary),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: AppSpacing.xs),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: isSelected
                                      ? AppColors.primary
                                      : AppColors.backgroundOf(context),
                                  borderRadius: BorderRadius.circular(
                                    AppSpacing.radiusPill,
                                  ),
                                ),
                                child: Text(
                                  option.badge,
                                  style: AppTextStyles.badgeLabel.copyWith(
                                    color: isSelected
                                        ? AppColors.textOnDark
                                        : textSecondary,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
