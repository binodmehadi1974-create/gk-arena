import 'package:flutter/material.dart';
import 'package:gk_arena/features/quiz/services/quiz_environment.dart';
import 'package:gk_arena/features/settings/controllers/settings_controller.dart';
import 'package:gk_arena/features/settings/localization/app_strings.dart';
import 'package:gk_arena/features/settings/models/app_settings.dart';
import 'package:gk_arena/features/settings/ui/screens/notification_preferences_screen.dart';
import 'package:gk_arena/features/settings/ui/screens/settings_info_screen.dart';
import 'package:gk_arena/features/settings/ui/screens/study_preferences_screen.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/navigation/smooth_page_route.dart';
import 'package:gk_arena/ui/screens/profile/language_screen.dart';
import 'package:gk_arena/ui/screens/profile/widgets/profile_menu_tile.dart';

/// Complete Settings & Personalization hub for GK ARENA.
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({
    super.key,
    this.quizEnvironment,
  });

  final QuizEnvironment? quizEnvironment;

  /// Matches pubspec.yaml `version: 1.0.0+1` verbatim.
  static const String appVersionDisplay = '1.0.0+1 (Dev)';

  Future<void> _showThemeDialog(
    BuildContext context,
    SettingsController controller,
  ) async {
    final AppStrings s = AppLanguageScope.of(context);
    final AppThemePreference current = controller.themePreference;

    final AppThemePreference? picked = await showDialog<AppThemePreference>(
      context: context,
      builder: (BuildContext dialogContext) {
        return SimpleDialog(
          title: Text(s.themeTitle),
          children: AppThemePreference.values.map((AppThemePreference pref) {
            final bool selected = pref == current;
            return SimpleDialogOption(
              onPressed: () => Navigator.of(dialogContext).pop(pref),
              child: Row(
                children: <Widget>[
                  Icon(
                    selected
                        ? Icons.radio_button_checked_rounded
                        : Icons.radio_button_off_rounded,
                    color: selected
                        ? AppColors.primary
                        : AppColors.textSecondaryOf(context),
                    size: 20,
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  Text(
                    s.themeLabel(pref),
                    style: AppTextStyles.bodyPrimary.copyWith(
                      color: AppColors.textPrimaryOf(context),
                      fontWeight:
                          selected ? FontWeight.w600 : FontWeight.w500,
                    ),
                  ),
                ],
              ),
            );
          }).toList(growable: false),
        );
      },
    );

    if (picked != null) {
      await controller.setThemePreference(picked);
    }
  }

  Future<void> _confirmClearLearningData(
    BuildContext context,
    QuizEnvironment environment,
  ) async {
    final AppStrings s = AppLanguageScope.of(context);
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text(s.clearDataDialogTitle),
          content: Text(s.clearDataDialogBody),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: Text(s.cancel),
            ),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.danger,
              ),
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: Text(s.clearDataConfirmBtn),
            ),
          ],
        );
      },
    );

    if (confirmed == true) {
      await environment.learningRepository.clearAllLearningData();
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(s.clearDataDone)),
      );
    }
  }

  void _push(BuildContext context, Widget screen) {
    Navigator.of(context).push(
      SmoothPageRoute<void>(builder: (_) => screen),
    );
  }

  @override
  Widget build(BuildContext context) {
    final AppStrings s = AppLanguageScope.of(context);
    final QuizEnvironment? env = quizEnvironment;
    final SettingsController? controller = env?.settingsController;
    final Color surface = AppColors.surfaceOf(context);
    final Color border = AppColors.borderOf(context);
    final Color textPrimary = AppColors.textPrimaryOf(context);

    Widget buildBody() {
      final AppLanguage lang =
          controller?.appLanguage ?? AppLanguageScope.languageOf(context);
      final AppThemePreference themePref =
          controller?.themePreference ?? AppThemePreference.light;

      return SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(
          20,
          AppSpacing.sm,
          20,
          AppSpacing.lg,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              s.preferencesSection,
              style: AppTextStyles.sectionTitle.copyWith(color: textPrimary),
            ),
            const SizedBox(height: AppSpacing.sm),
            _SettingsGroup(
              surface: surface,
              border: border,
              children: <Widget>[
                ProfileMenuTile(
                  icon: Icons.translate_rounded,
                  title: s.appLanguageTitle,
                  subtitle: s.languagePreferenceSub,
                  trailingText: lang.nativeName,
                  iconColor: AppColors.primary,
                  iconBackground: AppColors.softBlueOf(context),
                  onTap: () => _push(
                    context,
                    LanguageScreen(settingsController: controller),
                  ),
                ),
                const Divider(indent: 68),
                ProfileMenuTile(
                  icon: themePref == AppThemePreference.dark
                      ? Icons.dark_mode_outlined
                      : Icons.light_mode_outlined,
                  title: s.themeTitle,
                  subtitle: s.themeLabel(themePref),
                  trailingText: s.themeLabel(themePref),
                  iconColor: AppColors.warning,
                  iconBackground: AppColors.softAmberOf(context),
                  onTap: () {
                    if (controller != null) {
                      _showThemeDialog(context, controller);
                    }
                  },
                ),
                const Divider(indent: 68),
                ProfileMenuTile(
                  icon: Icons.tune_outlined,
                  title: s.studyPreferencesTitle,
                  subtitle: s.studyPreferencesSub,
                  iconColor: AppColors.accentTeal,
                  iconBackground: AppColors.softTealOf(context),
                  onTap: () {
                    if (controller != null) {
                      _push(
                        context,
                        StudyPreferencesScreen(settingsController: controller),
                      );
                    }
                  },
                ),
                const Divider(indent: 68),
                ProfileMenuTile(
                  icon: Icons.notifications_none_rounded,
                  title: s.notificationsTitle,
                  subtitle: s.notificationsSub,
                  iconColor: AppColors.primary,
                  iconBackground: AppColors.softIndigoOf(context),
                  onTap: () {
                    if (controller != null) {
                      _push(
                        context,
                        NotificationPreferencesScreen(
                          settingsController: controller,
                        ),
                      );
                    }
                  },
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.lg),
            Text(
              s.dataPrivacySection,
              style: AppTextStyles.sectionTitle.copyWith(color: textPrimary),
            ),
            const SizedBox(height: AppSpacing.sm),
            _SettingsGroup(
              surface: surface,
              border: border,
              children: <Widget>[
                ProfileMenuTile(
                  icon: Icons.delete_sweep_outlined,
                  title: s.clearLearningData,
                  subtitle: s.clearLearningDataSub,
                  iconColor: AppColors.danger,
                  iconBackground: const Color(0x26D64545),
                  onTap: () {
                    if (env != null) {
                      _confirmClearLearningData(context, env);
                    }
                  },
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.lg),
            Text(
              s.infoLegalSection,
              style: AppTextStyles.sectionTitle.copyWith(color: textPrimary),
            ),
            const SizedBox(height: AppSpacing.sm),
            _SettingsGroup(
              surface: surface,
              border: border,
              children: <Widget>[
                ProfileMenuTile(
                  icon: Icons.info_outline_rounded,
                  title: s.aboutGkArena,
                  subtitle: s.aboutGkArenaSub,
                  iconColor: AppColors.primary,
                  iconBackground: AppColors.softBlueOf(context),
                  onTap: () => _push(
                    context,
                    SettingsInfoScreen(
                      title: s.aboutGkArena,
                      icon: Icons.info_outline_rounded,
                      badgeText: appVersionDisplay,
                      body: s.t(
                        hi: 'GK ARENA हिन्दी और English में सामान्य ज्ञान, शैक्षणिक अध्ययन एवं प्रतियोगी परीक्षा अभ्यास के लिए बनाया गया एक आधुनिक लर्निंग ऐप है।',
                        en: 'GK ARENA is a bilingual Hindi and English general knowledge, academic learning, and competitive-exam practice application.',
                      ),
                    ),
                  ),
                ),
                const Divider(indent: 68),
                ProfileMenuTile(
                  icon: Icons.help_outline_rounded,
                  title: s.helpSupport,
                  subtitle: s.helpSupportSub,
                  iconColor: AppColors.success,
                  iconBackground: AppColors.softGreenOf(context),
                  onTap: () => _push(
                    context,
                    SettingsInfoScreen(
                      title: s.helpSupport,
                      icon: Icons.help_outline_rounded,
                      badgeText: s.t(
                        hi: 'प्लेसहोल्डर — आधिकारिक संपर्क अभी प्रकाशित नहीं',
                        en: 'Placeholder — Official support channels not yet published',
                      ),
                      body: s.t(
                        hi: 'आधिकारिक सहायता और संपर्क विवरण (ईमेल/सपोर्ट पोर्टल) ऐप के प्रकाशन से पहले यहाँ जोड़े जाएंगे।',
                        en: 'Official support contact details and help resources will be added here prior to public release.',
                      ),
                    ),
                  ),
                ),
                const Divider(indent: 68),
                ProfileMenuTile(
                  icon: Icons.privacy_tip_outlined,
                  title: s.privacyPolicy,
                  subtitle: s.privacyPolicySub,
                  iconColor: AppColors.accentTeal,
                  iconBackground: AppColors.softTealOf(context),
                  onTap: () => _push(
                    context,
                    SettingsInfoScreen(
                      title: s.privacyPolicy,
                      icon: Icons.privacy_tip_outlined,
                      badgeText: s.t(
                        hi: 'प्लेसहोल्डर — कानूनी दस्तावेज़ लंबित',
                        en: 'Placeholder — Official legal document pending',
                      ),
                      body: s.t(
                        hi: 'वर्तमान बिल्ड में आपकी सेटिंग्स और लर्निंग प्रगति केवल आपके डिवाइस पर स्थानीय रूप से सहेजी जाती हैं। कोई पासवर्ड या संवेदनशील व्यक्तिगत डेटा एकत्र नहीं किया जाता। पूर्ण गोपनीयता नीति सार्वजनिक रिलीज़ से पहले यहाँ प्रकाशित की जाएगी।',
                        en: 'In this build, your settings and learning progress are stored locally on your device only. No passwords or sensitive personal information are collected. The full Privacy Policy will be published here prior to release.',
                      ),
                    ),
                  ),
                ),
                const Divider(indent: 68),
                ProfileMenuTile(
                  icon: Icons.description_outlined,
                  title: s.termsConditions,
                  subtitle: s.termsConditionsSub,
                  iconColor: AppColors.warning,
                  iconBackground: AppColors.softAmberOf(context),
                  onTap: () => _push(
                    context,
                    SettingsInfoScreen(
                      title: s.termsConditions,
                      icon: Icons.description_outlined,
                      badgeText: s.t(
                        hi: 'प्लेसहोल्डर — कानूनी दस्तावेज़ लंबित',
                        en: 'Placeholder — Official legal document pending',
                      ),
                      body: s.t(
                        hi: 'आधिकारिक नियम और शर्तें सार्वजनिक रिलीज़ से पहले यहाँ प्रकाशित की जाएंगी।',
                        en: 'Official Terms and Conditions will be published here prior to public release.',
                      ),
                    ),
                  ),
                ),
                const Divider(indent: 68),
                ProfileMenuTile(
                  icon: Icons.verified_outlined,
                  title: s.appVersion,
                  subtitle: s.t(
                    hi: 'pubspec.yaml बिल्ड संस्करण',
                    en: 'Build version from pubspec.yaml',
                  ),
                  trailingText: appVersionDisplay,
                  iconColor: AppColors.primary,
                  iconBackground: AppColors.softIndigoOf(context),
                  onTap: () {},
                ),
              ],
            ),
          ],
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(s.settings),
      ),
      body: SafeArea(
        child: controller != null
            ? AnimatedBuilder(
                animation: controller,
                builder: (_, __) => buildBody(),
              )
            : buildBody(),
      ),
    );
  }
}

class _SettingsGroup extends StatelessWidget {
  const _SettingsGroup({
    required this.surface,
    required this.border,
    required this.children,
  });

  final Color surface;
  final Color border;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        border: Border.all(color: border, width: 1),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(children: children),
    );
  }
}
