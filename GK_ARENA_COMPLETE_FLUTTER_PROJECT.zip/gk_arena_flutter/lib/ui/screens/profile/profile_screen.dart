import 'package:flutter/material.dart';
import 'package:gk_arena/features/account/ui/screens/account_settings_screen.dart';
import 'package:gk_arena/features/learning/models/learning_models.dart';
import 'package:gk_arena/features/learning/ui/screens/test_history_screen.dart';
import 'package:gk_arena/features/learning/ui/screens/wrong_answer_revision_screen.dart';
import 'package:gk_arena/features/quiz/services/quiz_environment.dart';
import 'package:gk_arena/features/settings/localization/app_strings.dart';
import 'package:gk_arena/features/settings/models/app_settings.dart';
import 'package:gk_arena/features/settings/ui/screens/settings_info_screen.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/navigation/smooth_page_route.dart';
import 'package:gk_arena/ui/screens/profile/bookmarks_screen.dart';
import 'package:gk_arena/ui/screens/profile/language_screen.dart';
import 'package:gk_arena/ui/screens/profile/learning_progress_screen.dart';
import 'package:gk_arena/ui/screens/profile/settings_screen.dart';
import 'package:gk_arena/ui/screens/profile/widgets/profile_menu_tile.dart';

/// Screen 4 — Clean Profile screen connected to real My Learning data,
/// live Hindi/English localization, Light/Dark themes, and full Settings.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({
    super.key,
    this.quizEnvironment,
  });

  final QuizEnvironment? quizEnvironment;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  StudentDashboardSummary? _summary;

  @override
  void initState() {
    super.initState();
    widget.quizEnvironment?.learningRepository.addListener(_onLearningChanged);
    _loadSummary();
  }

  @override
  void dispose() {
    widget.quizEnvironment?.learningRepository
        .removeListener(_onLearningChanged);
    super.dispose();
  }

  void _onLearningChanged() {
    _loadSummary();
  }

  Future<void> _loadSummary() async {
    final QuizEnvironment? env = widget.quizEnvironment;
    if (env == null) return;
    await env.ensureInitialized();
    final StudentDashboardSummary summary =
        await env.learningRepository.getDashboardSummary();
    if (!mounted) return;
    setState(() {
      _summary = summary;
    });
  }

  void _push(BuildContext context, Widget screen) {
    Navigator.of(context).push(
      SmoothPageRoute<void>(builder: (_) => screen),
    );
  }

  @override
  Widget build(BuildContext context) {
    final AppStrings s = AppLanguageScope.of(context);
    final StudentDashboardSummary? summary = _summary;
    final AppLanguage activeLang =
        widget.quizEnvironment?.settingsController.appLanguage ??
            AppLanguageScope.languageOf(context);
    final Color surface = AppColors.surfaceOf(context);
    final Color border = AppColors.borderOf(context);
    final Color textPrimary = AppColors.textPrimaryOf(context);
    final Color textSecondary = AppColors.textSecondaryOf(context);

    final String profileSubtitle = (summary != null && summary.hasActivity)
        ? '${summary.totalTestsAttempted} Tests • ${summary.overallAccuracyPercent}% Accuracy • ${summary.totalQuestionsAttempted} Qs'
        : s.t(
            hi: 'GK ARENA • अपना पहला टेस्ट देकर सीखने की प्रगति ट्रैक करें।',
            en: 'GK ARENA • Complete your first test to track real learning progress.',
          );

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, AppSpacing.md, 20, AppSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              s.myProfile,
              style: AppTextStyles.pageTitle.copyWith(color: textPrimary),
            ),
            const SizedBox(height: AppSpacing.md),
            // Neutral Profile Header connected to real learning summary (never fabricated)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(AppSpacing.md),
              decoration: BoxDecoration(
                color: surface,
                borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
                border: Border.all(color: border, width: 1),
              ),
              child: Row(
                children: <Widget>[
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: AppColors.softBlueOf(context),
                      shape: BoxShape.circle,
                      border: Border.all(color: border, width: 1.5),
                    ),
                    child: const Icon(
                      Icons.person_outline_rounded,
                      color: AppColors.primary,
                      size: 30,
                    ),
                  ),
                  const SizedBox(width: AppSpacing.md),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          s.learnerProfile,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: AppTextStyles.sectionTitle
                              .copyWith(color: textPrimary),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          profileSubtitle,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: AppTextStyles.cardSubtitle
                              .copyWith(color: textSecondary),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.lg),
            Text(
              s.learningSection,
              style: AppTextStyles.sectionTitle.copyWith(color: textPrimary),
            ),
            const SizedBox(height: AppSpacing.sm),
            Container(
              decoration: BoxDecoration(
                color: surface,
                borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
                border: Border.all(color: border, width: 1),
              ),
              clipBehavior: Clip.antiAlias,
              child: Column(
                children: <Widget>[
                  ProfileMenuTile(
                    icon: Icons.insights_outlined,
                    title: s.learningProgress,
                    subtitle: s.learningProgressSub,
                    trailingText: (summary != null && summary.hasActivity)
                        ? '${summary.overallAccuracyPercent}%'
                        : null,
                    iconColor: AppColors.success,
                    iconBackground: AppColors.softGreenOf(context),
                    onTap: () => _push(
                      context,
                      LearningProgressScreen(
                        quizEnvironment: widget.quizEnvironment,
                      ),
                    ),
                  ),
                  const Divider(indent: 68),
                  ProfileMenuTile(
                    icon: Icons.history_rounded,
                    title: s.testHistory,
                    subtitle: s.testHistorySub,
                    trailingText: (summary != null &&
                            summary.totalTestsAttempted > 0)
                        ? '${summary.totalTestsAttempted}'
                        : null,
                    iconColor: AppColors.primary,
                    iconBackground: AppColors.softBlueOf(context),
                    onTap: () {
                      final QuizEnvironment? env = widget.quizEnvironment;
                      if (env == null) return;
                      _push(context, TestHistoryScreen(environment: env));
                    },
                  ),
                  const Divider(indent: 68),
                  ProfileMenuTile(
                    icon: Icons.bookmark_border_rounded,
                    title: s.bookmarks,
                    subtitle: s.bookmarksSub,
                    trailingText:
                        (summary != null && summary.bookmarksCount > 0)
                            ? '${summary.bookmarksCount}'
                            : null,
                    iconColor: AppColors.primary,
                    iconBackground: AppColors.softBlueOf(context),
                    onTap: () => _push(
                      context,
                      BookmarksScreen(
                        quizEnvironment: widget.quizEnvironment,
                      ),
                    ),
                  ),
                  const Divider(indent: 68),
                  ProfileMenuTile(
                    icon: Icons.replay_circle_filled_outlined,
                    title: s.wrongAnswerRevision,
                    subtitle: s.wrongAnswerRevisionSub,
                    trailingText: (summary != null &&
                            summary.pendingWrongAnswersCount > 0)
                        ? '${summary.pendingWrongAnswersCount}'
                        : null,
                    iconColor: AppColors.warning,
                    iconBackground: AppColors.softAmberOf(context),
                    onTap: () {
                      final QuizEnvironment? env = widget.quizEnvironment;
                      if (env == null) return;
                      _push(
                        context,
                        WrongAnswerRevisionScreen(environment: env),
                      );
                    },
                  ),
                  const Divider(indent: 68),
                  ProfileMenuTile(
                    icon: Icons.translate_rounded,
                    title: s.languagePreference,
                    subtitle: s.languagePreferenceSub,
                    trailingText: activeLang.nativeName,
                    iconColor: AppColors.accentTeal,
                    iconBackground: AppColors.softTealOf(context),
                    onTap: () => _push(
                      context,
                      LanguageScreen(
                        settingsController:
                            widget.quizEnvironment?.settingsController,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.lg),
            Text(
              s.appSection,
              style: AppTextStyles.sectionTitle.copyWith(color: textPrimary),
            ),
            const SizedBox(height: AppSpacing.sm),
            Container(
              decoration: BoxDecoration(
                color: surface,
                borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
                border: Border.all(color: border, width: 1),
              ),
              clipBehavior: Clip.antiAlias,
              child: Column(
                children: <Widget>[
                  ProfileMenuTile(
                    icon: Icons.manage_accounts_outlined,
                    title: s.t(hi: 'खाता और क्लाउड बैकअप', en: 'Account & Cloud Backup'),
                    subtitle: s.t(
                      hi: 'लॉगिन, Guest Mode और बैकअप स्थिति',
                      en: 'Login, Guest Mode & cloud backup status',
                    ),
                    trailingText: (widget.quizEnvironment?.accountController.isGuest ?? true)
                        ? 'Guest'
                        : null,
                    iconColor: AppColors.primary,
                    iconBackground: AppColors.softBlueOf(context),
                    onTap: () {
                      final QuizEnvironment? env = widget.quizEnvironment;
                      if (env == null) return;
                      _push(
                        context,
                        AccountSettingsScreen(
                          accountController: env.accountController,
                        ),
                      );
                    },
                  ),
                  const Divider(indent: 68),
                  ProfileMenuTile(
                    icon: Icons.settings_outlined,
                    title: s.settings,
                    subtitle: s.settingsSub,
                    iconColor: AppColors.primary,
                    iconBackground: AppColors.softIndigoOf(context),
                    onTap: () => _push(
                      context,
                      SettingsScreen(
                        quizEnvironment: widget.quizEnvironment,
                      ),
                    ),
                  ),
                  const Divider(indent: 68),
                  ProfileMenuTile(
                    icon: Icons.info_outline_rounded,
                    title: s.aboutGkArena,
                    subtitle: s.aboutGkArenaSub,
                    iconColor: AppColors.warning,
                    iconBackground: AppColors.softAmberOf(context),
                    onTap: () => _push(
                      context,
                      SettingsInfoScreen(
                        title: s.aboutGkArena,
                        icon: Icons.info_outline_rounded,
                        badgeText: SettingsScreen.appVersionDisplay,
                        body: s.t(
                          hi: 'GK ARENA हिन्दी और English में सामान्य ज्ञान, शैक्षणिक अध्ययन एवं प्रतियोगी परीक्षा अभ्यास के लिए बनाया गया एक आधुनिक लर्निंग ऐप है।',
                          en: 'GK ARENA is a bilingual Hindi and English general knowledge, academic learning, and competitive-exam practice application.',
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
