import 'package:flutter/material.dart';
import 'package:gk_arena/features/monetization/ui/widgets/gk_banner_ad_slot.dart';
import 'package:gk_arena/features/quiz/services/quiz_environment.dart';
import 'package:gk_arena/features/search/data/subject_ui_mapper.dart';
import 'package:gk_arena/features/search/models/search_models.dart';
import 'package:gk_arena/features/search/services/subject_search_service.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/navigation/smooth_page_route.dart';
import 'package:gk_arena/ui/screens/explore/subject_detail_screen.dart';
import 'package:gk_arena/ui/screens/explore/widgets/category_filter_bar.dart';
import 'package:gk_arena/ui/screens/explore/widgets/subject_catalog.dart';
import 'package:gk_arena/ui/widgets/state_views.dart';
import 'package:gk_arena/ui/widgets/subject_card.dart';

/// Screen 2 — Explore / All Subjects directory connected to SubjectSearchService.
class ExploreScreen extends StatefulWidget {
  const ExploreScreen({
    super.key,
    this.searchService = const SubjectSearchService(),
    this.quizEnvironment,
  });

  final SubjectSearchService searchService;
  final QuizEnvironment? quizEnvironment;

  @override
  State<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends State<ExploreScreen> {
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();

  String _selectedCategory = SubjectCatalog.categoryAll;
  String _query = '';

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  void _onQueryChanged(String value) {
    setState(() {
      _query = value;
    });
  }

  void _clearSearch() {
    _searchController.clear();
    setState(() {
      _query = '';
    });
  }

  void _resetSearchAndFilter() {
    _searchController.clear();
    setState(() {
      _query = '';
      _selectedCategory = SubjectCatalog.categoryAll;
    });
  }

  void _triggerSearchAction() {
    _searchFocusNode.unfocus();
    setState(() {
      _query = _searchController.text;
    });
  }

  void _openSubjectDetail(SubjectUiItem subject) {
    _searchFocusNode.unfocus();
    Navigator.of(context).push(
      SmoothPageRoute<void>(
        builder: (_) => SubjectDetailScreen(
          subject: subject,
          quizEnvironment: widget.quizEnvironment,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final SubjectSearchResult result = widget.searchService.search(
      query: _query,
      category: _selectedCategory,
    );
    final List<SubjectUiItem> subjects = result.entries
        .map(SubjectUiMapper.toUiItem)
        .toList(growable: false);

    return SafeArea(
      child: SingleChildScrollView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        padding: const EdgeInsets.fromLTRB(20, AppSpacing.md, 20, AppSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text('Explore', style: AppTextStyles.pageTitle.copyWith(color: AppColors.textPrimaryOf(context))),
            const SizedBox(height: AppSpacing.xxs),
            const Text(
              'अपने पसंदीदा विषय को चुनें।',
              style: AppTextStyles.body,
            ),
            const SizedBox(height: AppSpacing.md),
            TextField(
              key: const Key('explore_search_field'),
              controller: _searchController,
              focusNode: _searchFocusNode,
              textInputAction: TextInputAction.search,
              onChanged: _onQueryChanged,
              onSubmitted: (_) => _triggerSearchAction(),
              decoration: InputDecoration(
                hintText: 'विषय खोजें...',
                prefixIcon: IconButton(
                  key: const Key('explore_search_button'),
                  tooltip: 'खोजें',
                  onPressed: _triggerSearchAction,
                  icon: const Icon(
                    Icons.search_rounded,
                    color: AppColors.textSecondary,
                    size: 21,
                  ),
                ),
                suffixIcon: _query.isNotEmpty
                    ? IconButton(
                        key: const Key('explore_clear_search_button'),
                        tooltip: 'खोज साफ़ करें',
                        onPressed: _clearSearch,
                        icon: const Icon(
                          Icons.close_rounded,
                          color: AppColors.textSecondary,
                          size: 20,
                        ),
                      )
                    : null,
              ),
            ),
            const SizedBox(height: AppSpacing.md),
            CategoryFilterBar(
              categories: SubjectCatalog.categories,
              selectedCategory: _selectedCategory,
              onSelected: (String category) {
                setState(() {
                  _selectedCategory = category;
                });
              },
            ),
            if (result.hasActiveQuery && !result.isEmpty) ...<Widget>[
              const SizedBox(height: AppSpacing.sm),
              Text(
                '${result.count} विषय मिले',
                style: AppTextStyles.cardSubtitle.copyWith(
                  color: AppColors.primary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
            const SizedBox(height: AppSpacing.md),
            if (result.isEmpty)
              GkEmptyStateCard(
                key: const Key('explore_empty_state'),
                icon: Icons.search_off_rounded,
                badgeText: 'No Matching Subject',
                title: 'कोई विषय नहीं मिला',
                description:
                    '“${_query.trim()}” के लिए कोई विषय उपलब्ध नहीं है। कृपया हिन्दी या English में दूसरा नाम आज़माएँ।',
                actionLabel: 'खोज साफ़ करें',
                onActionTap: _resetSearchAndFilter,
              )
            else
              LayoutBuilder(
                builder: (BuildContext context, BoxConstraints constraints) {
                  final double cardWidth =
                      (constraints.maxWidth - AppSpacing.sm) / 2;
                  final double aspectRatio = (cardWidth / 158).clamp(0.92, 1.24);

                  return GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: subjects.length,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: AppSpacing.sm,
                      mainAxisSpacing: AppSpacing.sm,
                      childAspectRatio: aspectRatio,
                    ),
                    itemBuilder: (BuildContext context, int index) {
                      final SubjectUiItem subject = subjects[index];
                      return SubjectCard(
                        subject: subject,
                        onTap: () => _openSubjectDetail(subject),
                      );
                    },
                  );
                },
              ),
            const SizedBox(height: AppSpacing.md),
            GkBannerAdSlot(policyService: widget.quizEnvironment?.adManager.policyService),
          ],
        ),
      ),
    );
  }
}
