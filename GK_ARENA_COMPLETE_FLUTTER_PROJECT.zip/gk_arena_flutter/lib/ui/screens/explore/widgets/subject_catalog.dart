import 'package:flutter/material.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/widgets/subject_card.dart';

/// Static UI catalog of the 10 subjects for GK ARENA (Stage 1 — UI only).
abstract final class SubjectCatalog {
  static const String categoryAll = 'All';
  static const String categoryGk = 'General Knowledge';
  static const String categoryScience = 'Science';
  static const String categoryMaths = 'Maths & Aptitude';

  static const List<String> categories = <String>[
    categoryAll,
    categoryGk,
    categoryScience,
    categoryMaths,
  ];

  static const List<SubjectUiItem> allSubjects = <SubjectUiItem>[
    // GENERAL KNOWLEDGE
    SubjectUiItem(
      id: 'history',
      titleEn: 'History',
      titleHi: 'इतिहास',
      shortDescription: 'प्राचीन, मध्यकालीन और आधुनिक इतिहास।',
      category: categoryGk,
      icon: Icons.account_balance_outlined,
      accentColor: AppColors.primary,
      accentBackground: AppColors.softBlueSurface,
    ),
    SubjectUiItem(
      id: 'geography',
      titleEn: 'Geography',
      titleHi: 'भूगोल',
      shortDescription: 'भारत एवं विश्व का भौतिक व राजनीतिक भूगोल।',
      category: categoryGk,
      icon: Icons.public_outlined,
      accentColor: AppColors.accentTeal,
      accentBackground: AppColors.softTealSurface,
    ),
    SubjectUiItem(
      id: 'political_science',
      titleEn: 'Political Science',
      titleHi: 'राजनीति विज्ञान / भारतीय राजव्यवस्था',
      shortDescription: 'संविधान, शासन प्रणाली और संवैधानिक संस्थाएँ।',
      category: categoryGk,
      icon: Icons.gavel_outlined,
      accentColor: AppColors.deepNavy,
      accentBackground: AppColors.softIndigoSurface,
    ),
    SubjectUiItem(
      id: 'economics',
      titleEn: 'Economics',
      titleHi: 'अर्थशास्त्र',
      shortDescription: 'भारतीय अर्थव्यवस्था, बजट और बैंकिंग आधार।',
      category: categoryGk,
      icon: Icons.trending_up_rounded,
      accentColor: AppColors.success,
      accentBackground: AppColors.softGreenSurface,
    ),
    SubjectUiItem(
      id: 'static_gk',
      titleEn: 'Static GK',
      titleHi: 'स्थैतिक सामान्य ज्ञान',
      shortDescription: 'पुरस्कार, संस्कृति, संगठन और प्रमुख तथ्य।',
      category: categoryGk,
      icon: Icons.menu_book_outlined,
      accentColor: AppColors.warning,
      accentBackground: AppColors.softAmberSurface,
    ),
    SubjectUiItem(
      id: 'current_affairs',
      titleEn: 'Current Affairs',
      titleHi: 'समसामयिक घटनाएँ',
      shortDescription: 'राष्ट्रीय, अंतर्राष्ट्रीय और प्रमुख नवीन घटनाक्रम।',
      category: categoryGk,
      icon: Icons.newspaper_outlined,
      accentColor: AppColors.primary,
      accentBackground: AppColors.softBlueSurface,
    ),

    // SCIENCE
    SubjectUiItem(
      id: 'physics',
      titleEn: 'Physics',
      titleHi: 'भौतिक विज्ञान',
      shortDescription: 'गति, ऊर्जा, प्रकाश, विद्युत और आधुनिक भौतिकी।',
      category: categoryScience,
      icon: Icons.bolt_outlined,
      accentColor: AppColors.accentTeal,
      accentBackground: AppColors.softTealSurface,
    ),
    SubjectUiItem(
      id: 'general_science',
      titleEn: 'General Science',
      titleHi: 'सामान्य विज्ञान',
      shortDescription: 'रसायन विज्ञान और जीव विज्ञान सहित दैनिक विज्ञान।',
      category: categoryScience,
      icon: Icons.science_outlined,
      accentColor: AppColors.success,
      accentBackground: AppColors.softGreenSurface,
    ),

    // MATHS AND APTITUDE
    SubjectUiItem(
      id: 'mathematics',
      titleEn: 'Mathematics',
      titleHi: 'गणित',
      shortDescription: 'अंकगणित, बीजगणित, ज्यामिति और क्षेत्रमिति।',
      category: categoryMaths,
      icon: Icons.calculate_outlined,
      accentColor: AppColors.primary,
      accentBackground: AppColors.softBlueSurface,
    ),
    SubjectUiItem(
      id: 'reasoning',
      titleEn: 'Reasoning',
      titleHi: 'तार्किक क्षमता',
      shortDescription: 'श्रृंखला, कोडिंग, पहेलियाँ और तार्किक विश्लेषण।',
      category: categoryMaths,
      icon: Icons.psychology_outlined,
      accentColor: AppColors.deepNavy,
      accentBackground: AppColors.softIndigoSurface,
    ),
  ];

  /// Exactly 4 curated subjects shown on the Home Screen preview:
  /// History, Geography, Science, Mathematics.
  static List<SubjectUiItem> get homePreviewSubjects => <SubjectUiItem>[
        allSubjects[0], // History
        allSubjects[1], // Geography
        const SubjectUiItem(
          id: 'general_science',
          titleEn: 'Science',
          titleHi: 'विज्ञान',
          shortDescription: 'भौतिक, रसायन और जीव विज्ञान के मूल विषय।',
          category: categoryScience,
          icon: Icons.science_outlined,
          accentColor: AppColors.success,
          accentBackground: AppColors.softGreenSurface,
        ),
        allSubjects[8], // Mathematics
      ];

  static List<SubjectUiItem> byCategory(String category) {
    if (category == categoryAll) {
      return allSubjects;
    }
    return allSubjects
        .where((SubjectUiItem item) => item.category == category)
        .toList(growable: false);
  }
}
