import 'package:flutter/material.dart';
import 'package:gk_arena/features/question_bank/models/question_enums.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/features/quiz/services/quiz_environment.dart';
import 'package:gk_arena/features/quiz/ui/screens/test_config_screen.dart';
import 'package:gk_arena/features/settings/localization/app_strings.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/navigation/smooth_page_route.dart';
import 'package:gk_arena/ui/widgets/premium_button.dart';
import 'package:gk_arena/ui/widgets/subject_card.dart';

/// Subject Detail screen connected to the real Question Bank & Test Engine
/// with Light/Dark theme support and Hindi/English localization.
class SubjectDetailScreen extends StatefulWidget {
  const SubjectDetailScreen({
    super.key,
    required this.subject,
    this.quizEnvironment,
  });

  final SubjectUiItem subject;
  final QuizEnvironment? quizEnvironment;

  @override
  State<SubjectDetailScreen> createState() => _SubjectDetailScreenState();
}

class _SubjectDetailScreenState extends State<SubjectDetailScreen> {
  List<String> _topics = const <String>[];
  bool _loadingTopics = false;

  QuestionSubject? get _mappedSubject {
    try {
      return QuestionSubject.fromId(widget.subject.id);
    } catch (_) {
      try {
        return QuestionSubject.fromId(widget.subject.titleEn);
      } catch (_) {
        return null;
      }
    }
  }

  @override
  void initState() {
    super.initState();
    _loadTopics();
  }

  Future<void> _loadTopics() async {
    final QuizEnvironment? env = widget.quizEnvironment;
    final QuestionSubject? mapped = _mappedSubject;
    if (env == null || mapped == null) return;
    setState(() => _loadingTopics = true);
    await env.ensureInitialized();
    final List<String> topics =
        await env.questionLoader.getAvailableTopics(subject: mapped);
    if (!mounted) return;
    setState(() {
      _topics = topics;
      _loadingTopics = false;
    });
  }

  void _openTestConfig(TestMode mode) {
    final QuizEnvironment? env = widget.quizEnvironment;
    if (env == null) return;
    Navigator.of(context).push(
      SmoothPageRoute<void>(
        builder: (_) => TestConfigScreen(
          mode: mode,
          environment: env,
          initialSubject: _mappedSubject,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final AppStrings s = AppLanguageScope.of(context);
    final Color surface = AppColors.surfaceOf(context);
    final Color border = AppColors.borderOf(context);
    final Color textPrimary = AppColors.textPrimaryOf(context);
    final Color textSecondary = AppColors.textSecondaryOf(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          s.isHindi ? widget.subject.titleHi : widget.subject.titleEn,
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(
            20,
            AppSpacing.sm,
            20,
            AppSpacing.lg,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(AppSpacing.lg),
                decoration: BoxDecoration(
                  color: surface,
                  borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
                  border: Border.all(color: border, width: 1),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Container(
                          width: 52,
                          height: 52,
                          decoration: BoxDecoration(
                            color: widget.subject.accentBackground,
                            borderRadius:
                                BorderRadius.circular(AppSpacing.radiusMd),
                          ),
                          child: Icon(
                            widget.subject.icon,
                            color: widget.subject.accentColor,
                            size: 26,
                          ),
                        ),
                        const SizedBox(width: AppSpacing.md),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                widget.subject.titleEn,
                                style: AppTextStyles.sectionTitle
                                    .copyWith(color: textPrimary),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                widget.subject.titleHi,
                                style: AppTextStyles.bodyPrimary.copyWith(
                                  color: AppColors.primary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSpacing.md),
                    Text(
                      widget.subject.shortDescription,
                      style: AppTextStyles.body.copyWith(color: textSecondary),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.lg),
              if (widget.quizEnvironment != null) ...<Widget>[
                PremiumButton(
                  label: s.t(
                    hi: 'विषय-वार टेस्ट शुरू करें',
                    en: 'Start Subject-wise Test',
                  ),
                  variant: PremiumButtonVariant.primary,
                  trailingIcon: Icons.play_arrow_rounded,
                  fullWidth: true,
                  onPressed: () => _openTestConfig(TestMode.subjectWise),
                ),
                const SizedBox(height: AppSpacing.sm),
                PremiumButton(
                  label: s.t(
                    hi: 'अध्याय-वार अभ्यास करें',
                    en: 'Practice by Topic',
                  ),
                  variant: PremiumButtonVariant.soft,
                  fullWidth: true,
                  onPressed: () => _openTestConfig(TestMode.topicWise),
                ),
                const SizedBox(height: AppSpacing.lg),
              ],
              Text(
                s.t(hi: 'उपलब्ध अध्याय', en: 'Available Topics'),
                style: AppTextStyles.sectionTitle.copyWith(color: textPrimary),
              ),
              const SizedBox(height: AppSpacing.sm),
              if (_loadingTopics)
                const Center(child: CircularProgressIndicator())
              else if (_topics.isEmpty)
                Text(
                  s.t(
                    hi: 'इस विषय में उपलब्ध अध्याय प्रश्न बैंक लोड होते ही यहाँ दिखाई देंगे।',
                    en: 'Topics for this subject will appear here once questions are loaded.',
                  ),
                  style: AppTextStyles.body.copyWith(color: textSecondary),
                )
              else
                Wrap(
                  spacing: AppSpacing.xs,
                  runSpacing: AppSpacing.xs,
                  children: _topics
                      .map((String topic) => Chip(label: Text(topic)))
                      .toList(growable: false),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
