import 'package:flutter/material.dart';
import 'package:gk_arena/features/quiz/models/quiz_models.dart';
import 'package:gk_arena/features/quiz/services/quiz_environment.dart';
import 'package:gk_arena/features/quiz/ui/screens/test_config_screen.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/navigation/smooth_page_route.dart';
import 'package:gk_arena/ui/screens/explore/subject_detail_screen.dart';
import 'package:gk_arena/ui/screens/explore/widgets/subject_catalog.dart';
import 'package:gk_arena/ui/screens/home/widgets/daily_challenge_card.dart';
import 'package:gk_arena/ui/screens/home/widgets/hero_test_card.dart';
import 'package:gk_arena/ui/widgets/app_header.dart';
import 'package:gk_arena/ui/widgets/section_header.dart';
import 'package:gk_arena/ui/widgets/subject_card.dart';

/// Screen 1 — Focused, uncluttered Home screen for GK ARENA.
class HomeScreen extends StatelessWidget {
  const HomeScreen({
    super.key,
    required this.onOpenExplore,
    required this.onOpenTests,
    required this.onOpenProfile,
    required this.quizEnvironment,
  });

  final VoidCallback onOpenExplore;
  final VoidCallback onOpenTests;
  final VoidCallback onOpenProfile;
  final QuizEnvironment quizEnvironment;

  void _openDailyChallenge(BuildContext context) {
    Navigator.of(context).push(
      SmoothPageRoute<void>(
        builder: (_) => TestConfigScreen(
          mode: TestMode.dailyChallenge,
          environment: quizEnvironment,
        ),
      ),
    );
  }

  void _openSubjectDetail(BuildContext context, SubjectUiItem subject) {
    Navigator.of(context).push(
      SmoothPageRoute<void>(
        builder: (_) => SubjectDetailScreen(
          subject: subject,
          quizEnvironment: quizEnvironment,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<SubjectUiItem> previewSubjects = SubjectCatalog.homePreviewSubjects;

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, AppSpacing.md, 20, AppSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            AppHeader(onProfileTap: onOpenProfile),
            const SizedBox(height: AppSpacing.lg),
            const Text(
              'नमस्ते! आज क्या सीखेंगे?',
              style: AppTextStyles.greetingTitle,
            ),
            const SizedBox(height: AppSpacing.xxs),
            const Text(
              'सीखिए, अभ्यास कीजिए और आगे बढ़िए।',
              style: AppTextStyles.body,
            ),
            const SizedBox(height: AppSpacing.lg),
            HeroTestCard(onStartTest: onOpenTests),
            const SizedBox(height: AppSpacing.md),
            DailyChallengeCard(
              onOpenChallenge: () => _openDailyChallenge(context),
            ),
            const SizedBox(height: AppSpacing.lg),
            SectionHeader(
              title: 'विषय चुनें',
              subtitle: 'अपनी पसंद के विषय से शुरुआत करें।',
              actionLabel: 'सभी विषय देखें',
              onActionTap: onOpenExplore,
            ),
            const SizedBox(height: AppSpacing.md),
            LayoutBuilder(
              builder: (BuildContext context, BoxConstraints constraints) {
                final double cardWidth = (constraints.maxWidth - AppSpacing.sm) / 2;
                final double aspectRatio = (cardWidth / 154).clamp(0.95, 1.28);

                return GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: previewSubjects.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: AppSpacing.sm,
                    mainAxisSpacing: AppSpacing.sm,
                    childAspectRatio: aspectRatio,
                  ),
                  itemBuilder: (BuildContext context, int index) {
                    final SubjectUiItem subject = previewSubjects[index];
                    return SubjectCard(
                      subject: subject,
                      onTap: () => _openSubjectDetail(context, subject),
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
