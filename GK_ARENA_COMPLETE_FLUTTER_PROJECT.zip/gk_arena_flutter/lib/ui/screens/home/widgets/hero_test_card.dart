import 'package:flutter/material.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/widgets/premium_button.dart';

/// Primary royal-blue / deep-navy hero card on the Home screen.
class HeroTestCard extends StatelessWidget {
  const HeroTestCard({
    super.key,
    required this.onStartTest,
  });

  final VoidCallback onStartTest;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: AppColors.heroGradient,
        borderRadius: BorderRadius.circular(AppSpacing.radiusXl),
        boxShadow: AppSpacing.heroCardShadow,
      ),
      child: Stack(
        children: <Widget>[
          Positioned(
            top: -28,
            right: -24,
            child: IgnorePointer(
              child: Container(
                width: 120,
                height: 120,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(0x1A19B8C8),
                ),
              ),
            ),
          ),
          Positioned(
            bottom: -36,
            right: 40,
            child: IgnorePointer(
              child: Container(
                width: 96,
                height: 96,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(0x14FFFFFF),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0x24FFFFFF),
                    borderRadius: BorderRadius.circular(AppSpacing.radiusPill),
                    border: Border.all(
                      color: const Color(0x33FFFFFF),
                      width: 1,
                    ),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Icon(
                        Icons.verified_outlined,
                        size: 14,
                        color: AppColors.accentTeal,
                      ),
                      SizedBox(width: 6),
                      Text(
                        'TEST CENTRE',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.7,
                          color: AppColors.textOnDark,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: AppSpacing.md),
                const Text(
                  'अपना अगला टेस्ट शुरू करें',
                  style: AppTextStyles.heroTitle,
                ),
                const SizedBox(height: AppSpacing.xs),
                const Text(
                  'अपनी तैयारी को परखें और नया सीखें।',
                  style: AppTextStyles.heroSubtitle,
                ),
                const SizedBox(height: AppSpacing.lg),
                PremiumButton(
                  label: 'टेस्ट शुरू करें',
                  variant: PremiumButtonVariant.lightOnDark,
                  trailingIcon: Icons.arrow_forward_rounded,
                  onPressed: onStartTest,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
