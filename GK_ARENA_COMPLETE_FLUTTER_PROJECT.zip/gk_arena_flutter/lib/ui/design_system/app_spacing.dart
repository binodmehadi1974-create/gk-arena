import 'package:flutter/material.dart';

/// 8-point spacing, corner radius, and motion system for GK ARENA.
abstract final class AppSpacing {
  // Spacing Scale
  static const double xxs = 4.0;
  static const double xs = 8.0;
  static const double sm = 12.0;
  static const double md = 16.0;
  static const double lg = 24.0;
  static const double xl = 32.0;
  static const double xxl = 40.0;

  // Screen Horizontal Padding
  static const EdgeInsets screenHorizontal = EdgeInsets.symmetric(
    horizontal: 20.0,
  );

  // Corner Radii
  static const double radiusSm = 12.0;
  static const double radiusMd = 16.0;
  static const double radiusLg = 20.0;
  static const double radiusXl = 24.0;
  static const double radiusPill = 999.0;

  // Motion Durations (180–250 ms)
  static const Duration motionFast = Duration(milliseconds: 180);
  static const Duration motionNormal = Duration(milliseconds: 220);

  // Soft Elevation Shadows
  static const List<BoxShadow> softCardShadow = <BoxShadow>[
    BoxShadow(
      color: Color(0x0A111C3A),
      blurRadius: 16,
      offset: Offset(0, 6),
    ),
  ];

  static const List<BoxShadow> heroCardShadow = <BoxShadow>[
    BoxShadow(
      color: Color(0x2B245BE8),
      blurRadius: 24,
      offset: Offset(0, 10),
    ),
  ];
}
