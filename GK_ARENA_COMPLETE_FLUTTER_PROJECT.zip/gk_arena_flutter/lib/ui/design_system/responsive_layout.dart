import 'package:flutter/material.dart';

/// Responsive & accessibility layout helpers tailored for Android phones
/// (320dp compact to 430dp+ large phones and tablets) and large text scaling.
abstract final class GkResponsive {
  static const double minTouchTarget = 48.0;

  static double horizontalPadding(BuildContext context) {
    final double width = MediaQuery.sizeOf(context).width;
    if (width < 360) return 16.0;
    if (width >= 600) return 28.0;
    return 20.0;
  }

  static int gridColumns(BuildContext context) {
    final double width = MediaQuery.sizeOf(context).width;
    if (width >= 600) return 3;
    return 2;
  }

  /// Adjusts card aspect ratio smoothly when system font scale increases so
  /// Hindi/English multi-line labels never trigger RenderFlex overflow.
  static double adaptiveCardAspectRatio(
    BuildContext context, {
    double baseRatio = 1.15,
  }) {
    final double textScale =
        MediaQuery.textScalerOf(context).scale(1.0).clamp(1.0, 1.6);
    final double adjusted = baseRatio / (1.0 + (textScale - 1.0) * 0.55);
    return adjusted.clamp(0.78, baseRatio);
  }
}
