import 'package:flutter/material.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';

/// Central typography styles with clean Devanagari fallback support.
abstract final class AppTextStyles {
  static const List<String> _fontFallbacks = <String>[
    'Noto Sans Devanagari',
    'Kohinoor Devanagari',
    'Roboto',
    'sans-serif',
  ];

  static const TextStyle brandTitle = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w800,
    letterSpacing: 0.6,
    color: AppColors.deepNavy,
    height: 1.2,
    fontFamilyFallback: _fontFallbacks,
  );

  static const TextStyle pageTitle = TextStyle(
    fontSize: 24,
    fontWeight: FontWeight.w700,
    letterSpacing: -0.2,
    color: AppColors.textPrimary,
    height: 1.3,
    fontFamilyFallback: _fontFallbacks,
  );

  static const TextStyle greetingTitle = TextStyle(
    fontSize: 22,
    fontWeight: FontWeight.w700,
    color: AppColors.textPrimary,
    height: 1.35,
    fontFamilyFallback: _fontFallbacks,
  );

  static const TextStyle heroTitle = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.w700,
    color: AppColors.textOnDark,
    height: 1.35,
    fontFamilyFallback: _fontFallbacks,
  );

  static const TextStyle heroSubtitle = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.w400,
    color: AppColors.textOnDarkMuted,
    height: 1.45,
    fontFamilyFallback: _fontFallbacks,
  );

  static const TextStyle sectionTitle = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w700,
    color: AppColors.textPrimary,
    height: 1.3,
    fontFamilyFallback: _fontFallbacks,
  );

  static const TextStyle cardTitle = TextStyle(
    fontSize: 15,
    fontWeight: FontWeight.w700,
    color: AppColors.textPrimary,
    height: 1.3,
    fontFamilyFallback: _fontFallbacks,
  );

  static const TextStyle cardSubtitle = TextStyle(
    fontSize: 12.5,
    fontWeight: FontWeight.w400,
    color: AppColors.textSecondary,
    height: 1.4,
    fontFamilyFallback: _fontFallbacks,
  );

  static const TextStyle body = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.w400,
    color: AppColors.textSecondary,
    height: 1.5,
    fontFamilyFallback: _fontFallbacks,
  );

  static const TextStyle bodyPrimary = TextStyle(
    fontSize: 14.5,
    fontWeight: FontWeight.w500,
    color: AppColors.textPrimary,
    height: 1.45,
    fontFamilyFallback: _fontFallbacks,
  );

  static const TextStyle buttonLabel = TextStyle(
    fontSize: 14.5,
    fontWeight: FontWeight.w600,
    letterSpacing: 0.1,
    height: 1.25,
    fontFamilyFallback: _fontFallbacks,
  );

  static const TextStyle linkAction = TextStyle(
    fontSize: 13.5,
    fontWeight: FontWeight.w600,
    color: AppColors.primary,
    height: 1.25,
    fontFamilyFallback: _fontFallbacks,
  );

  static const TextStyle chipLabel = TextStyle(
    fontSize: 13,
    fontWeight: FontWeight.w600,
    height: 1.25,
    fontFamilyFallback: _fontFallbacks,
  );

  static const TextStyle badgeLabel = TextStyle(
    fontSize: 11.5,
    fontWeight: FontWeight.w600,
    letterSpacing: 0.2,
    height: 1.2,
    fontFamilyFallback: _fontFallbacks,
  );

  static const TextStyle navLabel = TextStyle(
    fontSize: 11.5,
    fontWeight: FontWeight.w600,
    height: 1.2,
    fontFamilyFallback: _fontFallbacks,
  );
}
