import 'package:flutter/material.dart';

/// Central color palette for GK ARENA (Light & Dark Themes).
abstract final class AppColors {
  // Brand Core
  static const Color primary = Color(0xFF245BE8);
  static const Color primaryDark = Color(0xFF1A43B5);
  static const Color primaryOnDark = Color(0xFF5B8CFF);
  static const Color deepNavy = Color(0xFF111C3A);
  static const Color accentTeal = Color(0xFF19B8C8);

  // Light Surfaces & Backgrounds
  static const Color background = Color(0xFFF5F7FC);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color softBlueSurface = Color(0xFFEAF0FF);
  static const Color softTealSurface = Color(0xFFE6F8FA);
  static const Color softAmberSurface = Color(0xFFFFF5E6);
  static const Color softGreenSurface = Color(0xFFE7F7F1);
  static const Color softIndigoSurface = Color(0xFFEEF0FF);

  // Dark Surfaces & Backgrounds (Brand-coherent Deep Navy palette)
  static const Color darkBackground = Color(0xFF0C1324);
  static const Color darkSurface = Color(0xFF151F36);
  static const Color darkSurfaceElevated = Color(0xFF1D2A48);
  static const Color darkSoftBlueSurface = Color(0xFF1A2B54);
  static const Color darkSoftTealSurface = Color(0xFF13333D);
  static const Color darkSoftAmberSurface = Color(0xFF3A2C16);
  static const Color darkSoftGreenSurface = Color(0xFF133428);
  static const Color darkSoftIndigoSurface = Color(0xFF21264D);

  // Typography
  static const Color textPrimary = Color(0xFF17233D);
  static const Color textSecondary = Color(0xFF74809A);
  static const Color textOnDark = Color(0xFFFFFFFF);
  static const Color textOnDarkMuted = Color(0xFFD6E2FF);
  static const Color darkTextPrimary = Color(0xFFF2F5FC);
  static const Color darkTextSecondary = Color(0xFF9AA8C7);

  // Borders & Dividers
  static const Color border = Color(0xFFE7EBF3);
  static const Color borderSubtle = Color(0xFFF0F3F9);
  static const Color darkBorder = Color(0xFF263556);

  // Semantic
  static const Color success = Color(0xFF159B72);
  static const Color warning = Color(0xFFE8A23A);
  static const Color danger = Color(0xFFD64545);

  // Shadows
  static const Color cardShadow = Color(0x0D111C3A);
  static const Color heroShadow = Color(0x2E245BE8);

  // Gradients (used selectively on Hero Cards and Primary CTA only)
  static const LinearGradient heroGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: <Color>[
      Color(0xFF245BE8),
      Color(0xFF1A3C9E),
      Color(0xFF111C3A),
    ],
  );

  static const LinearGradient primaryButtonGradient = LinearGradient(
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
    colors: <Color>[
      Color(0xFF245BE8),
      Color(0xFF1C47BF),
    ],
  );

  // Context-aware adaptive helpers for Light & Dark Themes
  static bool isDark(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark;

  static Color backgroundOf(BuildContext context) =>
      isDark(context) ? darkBackground : background;

  static Color surfaceOf(BuildContext context) =>
      isDark(context) ? darkSurface : surface;

  static Color borderOf(BuildContext context) =>
      isDark(context) ? darkBorder : border;

  static Color textPrimaryOf(BuildContext context) =>
      isDark(context) ? darkTextPrimary : textPrimary;

  static Color textSecondaryOf(BuildContext context) =>
      isDark(context) ? darkTextSecondary : textSecondary;

  static Color softBlueOf(BuildContext context) =>
      isDark(context) ? darkSoftBlueSurface : softBlueSurface;

  static Color softTealOf(BuildContext context) =>
      isDark(context) ? darkSoftTealSurface : softTealSurface;

  static Color softAmberOf(BuildContext context) =>
      isDark(context) ? darkSoftAmberSurface : softAmberSurface;

  static Color softGreenOf(BuildContext context) =>
      isDark(context) ? darkSoftGreenSurface : softGreenSurface;

  static Color softIndigoOf(BuildContext context) =>
      isDark(context) ? darkSoftIndigoSurface : softIndigoSurface;
}
