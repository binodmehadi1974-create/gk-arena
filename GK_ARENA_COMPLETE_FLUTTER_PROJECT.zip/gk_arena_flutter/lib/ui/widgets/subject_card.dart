import 'package:flutter/material.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';

/// Pure UI presentation metadata for a subject tile.
class SubjectUiItem {
  const SubjectUiItem({
    required this.id,
    required this.titleEn,
    required this.titleHi,
    required this.shortDescription,
    required this.category,
    required this.icon,
    required this.accentColor,
    required this.accentBackground,
  });

  final String id;
  final String titleEn;
  final String titleHi;
  final String shortDescription;
  final String category;
  final IconData icon;
  final Color accentColor;
  final Color accentBackground;
}

/// Clean, restrained subject card shared by Home and Explore grids.
class SubjectCard extends StatelessWidget {
  const SubjectCard({
    super.key,
    required this.subject,
    required this.onTap,
    this.showDescription = true,
  });

  final SubjectUiItem subject;
  final VoidCallback onTap;
  final bool showDescription;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceOf(context),
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        border: Border.all(color: AppColors.borderOf(context), width: 1),
        boxShadow: AppSpacing.softCardShadow,
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.md),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: subject.accentBackground,
                    borderRadius: BorderRadius.circular(AppSpacing.radiusSm),
                  ),
                  child: Icon(
                    subject.icon,
                    color: subject.accentColor,
                    size: 22,
                  ),
                ),
                const SizedBox(height: AppSpacing.sm),
                Text(
                  subject.titleEn,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.cardTitle,
                ),
                const SizedBox(height: 2),
                Text(
                  subject.titleHi,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.cardSubtitle.copyWith(
                    color: AppColors.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                if (showDescription) ...<Widget>[
                  const SizedBox(height: 6),
                  Expanded(
                    child: Text(
                      subject.shortDescription,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: AppTextStyles.cardSubtitle,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
