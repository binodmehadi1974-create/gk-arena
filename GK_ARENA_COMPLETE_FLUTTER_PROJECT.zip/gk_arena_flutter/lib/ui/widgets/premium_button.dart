import 'package:flutter/material.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';

enum PremiumButtonVariant {
  primary,
  lightOnDark,
  soft,
}

/// Reusable high-contrast button with proper height, padding, and pressed feedback.
class PremiumButton extends StatelessWidget {
  const PremiumButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.variant = PremiumButtonVariant.primary,
    this.trailingIcon,
    this.fullWidth = false,
  });

  final String label;
  final VoidCallback onPressed;
  final PremiumButtonVariant variant;
  final IconData? trailingIcon;
  final bool fullWidth;

  @override
  Widget build(BuildContext context) {
    final bool isPrimary = variant == PremiumButtonVariant.primary;
    final bool isLightOnDark = variant == PremiumButtonVariant.lightOnDark;

    final Color textColor = isPrimary
        ? AppColors.textOnDark
        : isLightOnDark
            ? AppColors.deepNavy
            : AppColors.primary;

    final BoxDecoration decoration = BoxDecoration(
      gradient: isPrimary ? AppColors.primaryButtonGradient : null,
      color: isPrimary
          ? null
          : isLightOnDark
              ? AppColors.surface
              : AppColors.softBlueSurface,
      borderRadius: BorderRadius.circular(AppSpacing.radiusSm),
    );

    return ConstrainedBox(
      constraints: BoxConstraints(
        minHeight: 46,
        minWidth: fullWidth ? double.infinity : 0,
      ),
      child: DecoratedBox(
        decoration: decoration,
        child: Material(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(AppSpacing.radiusSm),
          child: InkWell(
            onTap: onPressed,
            borderRadius: BorderRadius.circular(AppSpacing.radiusSm),
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 18,
                vertical: 12,
              ),
              child: Row(
                mainAxisSize: fullWidth ? MainAxisSize.max : MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Flexible(
                    child: Text(
                      label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: AppTextStyles.buttonLabel.copyWith(
                        color: textColor,
                      ),
                    ),
                  ),
                  if (trailingIcon != null) ...<Widget>[
                    const SizedBox(width: AppSpacing.xs),
                    Icon(
                      trailingIcon,
                      size: 18,
                      color: textColor,
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
