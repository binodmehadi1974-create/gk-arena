import 'package:flutter/material.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';

/// Compact branded header for the Home screen: Logo + GK ARENA + Profile avatar.
class AppHeader extends StatelessWidget {
  const AppHeader({
    super.key,
    required this.onProfileTap,
  });

  final VoidCallback onProfileTap;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            gradient: AppColors.heroGradient,
            borderRadius: BorderRadius.circular(AppSpacing.radiusSm),
            boxShadow: const <BoxShadow>[
              BoxShadow(
                color: Color(0x24245BE8),
                blurRadius: 10,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: const Icon(
            Icons.auto_stories_rounded,
            color: AppColors.textOnDark,
            size: 20,
          ),
        ),
        const SizedBox(width: AppSpacing.sm),
        const Expanded(
          child: Text(
            'GK ARENA',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: AppTextStyles.brandTitle,
          ),
        ),
        Material(
          color: AppColors.surfaceOf(context),
          shape: const CircleBorder(
            side: BorderSide(color: AppColors.border, width: 1),
          ),
          child: InkWell(
            onTap: onProfileTap,
            customBorder: const CircleBorder(),
            child: const SizedBox(
              width: 42,
              height: 42,
              child: Icon(
                Icons.person_outline_rounded,
                color: AppColors.deepNavy,
                size: 21,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
