import 'package:flutter/material.dart';
import 'package:gk_arena/ui/design_system/app_colors.dart';
import 'package:gk_arena/ui/design_system/app_spacing.dart';
import 'package:gk_arena/ui/design_system/app_text_styles.dart';
import 'package:gk_arena/ui/widgets/premium_button.dart';

/// Thoughtful empty-state card used across Bookmarks, Progress, and lists
/// (adaptive for both Light and Dark themes).
class GkEmptyStateCard extends StatelessWidget {
  const GkEmptyStateCard({
    super.key,
    required this.icon,
    required this.title,
    required this.description,
    this.badgeText,
    this.actionLabel,
    this.onActionTap,
  });

  final IconData icon;
  final String title;
  final String description;
  final String? badgeText;
  final String? actionLabel;
  final VoidCallback? onActionTap;

  @override
  Widget build(BuildContext context) {
    final Color surface = AppColors.surfaceOf(context);
    final Color border = AppColors.borderOf(context);
    final Color textPrimary = AppColors.textPrimaryOf(context);
    final Color textSecondary = AppColors.textSecondaryOf(context);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        border: Border.all(color: border, width: 1),
        boxShadow: AppColors.isDark(context) ? const <BoxShadow>[] : AppSpacing.softCardShadow,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: AppColors.softBlueOf(context),
              borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
            ),
            child: Icon(
              icon,
              color: AppColors.primary,
              size: 28,
            ),
          ),
          if (badgeText != null) ...<Widget>[
            const SizedBox(height: AppSpacing.sm),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.softTealOf(context),
                borderRadius: BorderRadius.circular(AppSpacing.radiusPill),
              ),
              child: Text(
                badgeText!,
                style: AppTextStyles.badgeLabel.copyWith(
                  color: textPrimary,
                ),
              ),
            ),
          ],
          const SizedBox(height: AppSpacing.md),
          Text(
            title,
            textAlign: TextAlign.center,
            style: AppTextStyles.sectionTitle.copyWith(color: textPrimary),
          ),
          const SizedBox(height: AppSpacing.xs),
          Text(
            description,
            textAlign: TextAlign.center,
            style: AppTextStyles.body.copyWith(color: textSecondary),
          ),
          if (actionLabel != null && onActionTap != null) ...<Widget>[
            const SizedBox(height: AppSpacing.lg),
            PremiumButton(
              label: actionLabel!,
              variant: PremiumButtonVariant.primary,
              trailingIcon: Icons.arrow_forward_rounded,
              onPressed: onActionTap!,
            ),
          ],
        ],
      ),
    );
  }
}

/// Reusable Error + Retry state card for graceful failure recovery.
class GkErrorRetryCard extends StatelessWidget {
  const GkErrorRetryCard({
    super.key,
    required this.title,
    required this.message,
    required this.onRetry,
    this.retryLabel = 'Retry',
  });

  final String title;
  final String message;
  final VoidCallback onRetry;
  final String retryLabel;

  @override
  Widget build(BuildContext context) {
    final Color surface = AppColors.surfaceOf(context);
    final Color border = AppColors.borderOf(context);
    final Color textPrimary = AppColors.textPrimaryOf(context);
    final Color textSecondary = AppColors.textSecondaryOf(context);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
        border: Border.all(color: border, width: 1),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          const Icon(
            Icons.error_outline_rounded,
            color: AppColors.danger,
            size: 36,
          ),
          const SizedBox(height: AppSpacing.sm),
          Text(
            title,
            textAlign: TextAlign.center,
            style: AppTextStyles.sectionTitle.copyWith(color: textPrimary),
          ),
          const SizedBox(height: AppSpacing.xs),
          Text(
            message,
            textAlign: TextAlign.center,
            style: AppTextStyles.body.copyWith(color: textSecondary),
          ),
          const SizedBox(height: AppSpacing.md),
          PremiumButton(
            label: retryLabel,
            variant: PremiumButtonVariant.primary,
            trailingIcon: Icons.refresh_rounded,
            onPressed: onRetry,
          ),
        ],
      ),
    );
  }
}

/// Subtle, reusable informational banner (Light & Dark adaptive).
class GkStageNoticeBanner extends StatelessWidget {
  const GkStageNoticeBanner({
    super.key,
    required this.message,
    this.icon = Icons.info_outline_rounded,
  });

  final String message;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: AppColors.softBlueOf(context),
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        border: Border.all(color: AppColors.borderOf(context), width: 1),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(icon, color: AppColors.primary, size: 20),
          const SizedBox(width: AppSpacing.sm),
          Expanded(
            child: Text(
              message,
              style: AppTextStyles.body.copyWith(
                color: AppColors.textPrimaryOf(context),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Clean animated loading placeholder card (SDK-only, Light & Dark adaptive).
class GkLoadingPlaceholderCard extends StatefulWidget {
  const GkLoadingPlaceholderCard({
    super.key,
    this.lineCount = 3,
  });

  final int lineCount;

  @override
  State<GkLoadingPlaceholderCard> createState() =>
      _GkLoadingPlaceholderCardState();
}

class _GkLoadingPlaceholderCardState extends State<GkLoadingPlaceholderCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _opacity;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    _opacity = Tween<double>(begin: 0.45, end: 0.95).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _opacity,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(AppSpacing.md),
        decoration: BoxDecoration(
          color: AppColors.surfaceOf(context),
          borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
          border: Border.all(color: AppColors.borderOf(context), width: 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: List<Widget>.generate(widget.lineCount, (int index) {
            final double widthFactor = index == 0
                ? 0.55
                : index == widget.lineCount - 1
                    ? 0.72
                    : 1.0;
            return Padding(
              padding: EdgeInsets.only(
                bottom: index == widget.lineCount - 1 ? 0 : AppSpacing.xs,
              ),
              child: FractionallySizedBox(
                widthFactor: widthFactor,
                child: Container(
                  height: index == 0 ? 16 : 12,
                  decoration: BoxDecoration(
                    color: AppColors.borderOf(context),
                    borderRadius: BorderRadius.circular(AppSpacing.xxs),
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}
