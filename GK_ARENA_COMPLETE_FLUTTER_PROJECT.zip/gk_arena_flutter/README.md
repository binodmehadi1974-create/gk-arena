# GK ARENA — Complete Flutter Android Project (Stages 1–16)

**GK ARENA** is a Flutter & Dart (Material 3) bilingual Hindi/English general knowledge, academic learning, and competitive-exam practice application.

## Project Structure
- `lib/` — Complete Flutter source code (Design System, 4-tab `AppShell`, Home, Explore, Bilingual Subject Search, Subject Details, Question Bank SQLite v3 + Content Intelligence, 8-mode Quiz Engine, Student Learning Analytics, Test History, Bookmarks, Wrong Answer Revision, Settings/Themes/Localization, Multi-User Account/Guest Mode/Cloud Sync Architecture, Admin Panel + Bulk Import/Verification, Offline Support, and AdMob Test Ads).
- `test/` — 14 executable automated test suites (63 test cases).
- `assets/sample_data/` — Clearly labeled development sample datasets (`demo_sample_questions.json`, `bilingual_sample_questions.json`, `sample_bulk_import.json`, `sample_bulk_import.csv`).
- `docs/` — Architecture, Firestore Security Rules (`firestore.rules`), Bulk Import guide, Security Audit checklist, AdMob Setup guide, and Release Readiness checklist.
- `.github/workflows/flutter_test.yml` — Ready-to-run GitHub Actions CI workflow for free cloud `flutter analyze` and `flutter test` from mobile Chrome.
- `pubspec.yaml` & `analysis_options.yaml` — Dart/Flutter dependencies and lint configuration.

## How to Open & Run (Mobile Chrome Cloud or PC)

### Option A — Using Only Android Phone + Chrome Browser (Free)
1. Upload this extracted `gk_arena_flutter` folder to a GitHub repository.
2. **Run Analyze & All 14 Test Suites**: Open the **Actions** tab on GitHub → select **GK ARENA Flutter Analyze & Test** → click **Run workflow**.
3. **Cloud IDE & Preview**: Import the GitHub repository into **Firebase Studio** (`https://firebase.studio`) or **GitHub Codespaces** in Chrome (Desktop site mode).

### Option B — Local Computer (VS Code / Android Studio)
```bash
# 1. Generate native Android platform scaffolding (if android/ is not yet created)
flutter create . --platforms=android

# 2. Install Flutter packages (creates pubspec.lock)
flutter pub get

# 3. Run static analyzer and all 14 automated test suites
flutter analyze
flutter test

# 4. Run on connected Android device or emulator
flutter run

# 5. Build Release APK / App Bundle (after configuring signing & manifest)
flutter build apk --release
flutter build appbundle --release
```

## Missing Configurations to Complete Before Public Release
1. **Native Android Folder (`android/`)**: Run `flutter create . --platforms=android` with your real reverse-domain package ID (`com.yourorg.gkarena`). Configure `minSdk >= 21`, app label `GK ARENA`, launcher icon, splash screen, and release signing keystore (`key.properties` kept outside Git).
2. **`pubspec.lock`**: Automatically generated when you run `flutter pub get`.
3. **Firebase Auth & Cloud Firestore (Optional Cloud Sync & Admin Claims)**: Run `flutterfire configure`, add `firebase_core`, `firebase_auth`, `cloud_firestore`, deploy `docs/firestore.rules`, and assign admin/reviewer custom claims server-side.
4. **AdMob Production Setup**:
   - Development uses **official Google AdMob TEST Ad Unit IDs only** (`AdConfig.useTestAds = true`).
   - Add `<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="ca-app-pub-3940256099942544~3347511713"/>` to `android/app/src/main/AndroidManifest.xml` for testing.
   - Only before Play Store release, replace `REPLACE_WITH_PRODUCTION_ANDROID_...` in `lib/features/monetization/config/ad_config.dart`, set `useTestAds = false`, and update the manifest `APPLICATION_ID` using an eligible adult (18+) AdMob account holder's real IDs.
5. **Privacy Policy & Legal Links**: Replace placeholders in `SettingsScreen` with your published Privacy Policy and Terms & Conditions URLs.
