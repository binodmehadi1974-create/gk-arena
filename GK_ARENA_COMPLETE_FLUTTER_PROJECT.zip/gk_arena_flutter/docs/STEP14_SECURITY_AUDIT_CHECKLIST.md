# GK ARENA — Step 14 Security Audit & Manual Cloud Setup Checklist

## 1. Local Security & Data Integrity Verified in Codebase
- Zero hardcoded API keys, credentials, or private keys.
- Zero `print()` / `debugPrint()` leaks in `lib/`.
- All SQLite queries use parameterized `?` arguments (no user-input string interpolation).
- SQLite `gk_arena_learning.db` uses `PRAGMA journal_mode = WAL` + `PRAGMA synchronous = FULL` for crash-safe user progress persistence.
- `BulkImportService` enforces a 10 MB file size cap, strict structural validation, null-byte rejection, max field lengths, and never auto-marks imported rows as factually `Verified`.
- `QuizSessionController` enforces duplicate-submission prevention.
- `AdminAccessService` defaults to `BackendEnforcedAdminAccessService`, blocking all admin mutations until real backend custom claims are wired.

## 2. Manual Backend Configuration Still Required Before Production Launch
1. Create a real Firebase project and run `flutterfire configure`.
2. Enable Firebase Auth (Email/Password) and deploy `docs/firestore.rules`.
3. Provision admin/reviewer roles strictly via server-side **Firebase Admin SDK Custom Claims** (`admin: true` / `reviewer: true`).
4. Run `flutter pub get`, `flutter analyze`, and `flutter test` via GitHub Actions (`.github/workflows/flutter_test.yml`) or Firebase Studio.
5. Perform real Android device testing (Light/Dark themes, Hindi Devanagari rendering, SQLite restart persistence).
