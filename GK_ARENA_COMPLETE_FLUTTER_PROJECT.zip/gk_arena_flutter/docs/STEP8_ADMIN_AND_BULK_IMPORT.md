# GK ARENA — Step 8: Admin Panel & Bulk Question Import Guide

## 1. Documented Bulk Import Formats

### A. JSON Format
Provide either a JSON array `[...]` or an object `{"questions": [...]}` where each object has:
- `id` (unique non-empty string)
- `question_text` (min 5 meaningful characters)
- `options` (array of exactly 4 unique non-empty strings)
- `correct_option_index` (integer `0`..`3`)
- `explanation` (non-empty string)
- `subject` (`history`, `geography`, `political_science`, `economics`, `physics`, `chemistry`, `biology`, `general_science`, `mathematics`, `reasoning`, `static_gk`, `current_affairs`)
- `topic`, `subtopic` (non-empty strings)
- `difficulty` (`easy`, `medium`, `hard`)
- `language` (`hi`, `en`)
- `exam_category` (`general`, `ssc`, `railway`, `bpsc`, `state_psc`, `banking`, `defence`, `upsc`)
- `question_type` (`single_choice`, `statement_based`, `match_the_following`, `assertion_reason`, `previous_year`)
- `source_reference` (non-empty string)
- `verification_status` (`unverified`, `pending_review` — bulk imports are never auto-marked factually `verified`)
- `publication_status` (optional; defaults to `draft` during bulk import)

### B. CSV Format (17 Columns with Header Row)
```text
id,question_text,option_a,option_b,option_c,option_d,correct_option_index,explanation,subject,topic,subtopic,difficulty,language,exam_category,question_type,source_reference,verification_status
```

## 2. Editorial Workflow vs Factual Verification
- Technical structural validation (`QuestionValidator`) is strictly separated from factual accuracy (`VerificationStatus`).
- Editorial states: `draft` -> `pending_review` -> `approved` -> `published` / `rejected`.

## 3. Backend Admin Security Requirements (Remaining Configuration)
- Never hardcode admin passwords or rely on hidden screens.
- Assign `admin: true` or `reviewer: true` using **Firebase Admin SDK Custom Claims** on a trusted backend server/Cloud Function.
- Deploy `docs/firestore.rules` so ordinary students can only read `published` questions and can never modify or delete Question Bank documents.
