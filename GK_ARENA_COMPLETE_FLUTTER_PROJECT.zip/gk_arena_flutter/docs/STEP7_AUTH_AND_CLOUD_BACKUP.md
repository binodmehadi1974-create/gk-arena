# GK ARENA — Step 7: Authentication & Cloud Backup Architecture

## 1. Recommended Provider
**Firebase Authentication + Cloud Firestore** (FlutterFire)
- Native Flutter/Android support (`firebase_core`, `firebase_auth`, `cloud_firestore`).
- Built-in Sign Up, Login, Logout, Email Verification, Password Reset, and Change Password without handling plaintext passwords.
- Offline-first caching and strict per-user Firestore Security Rules (`docs/firestore.rules`).

## 2. Required Configuration (Not Yet Connected in This Build)
To activate live cloud accounts and backup on your machine:
1. Create a Firebase project in the Firebase Console and enable **Email/Password Authentication** and **Cloud Firestore**.
2. Add FlutterFire packages to `pubspec.yaml`: `firebase_core`, `firebase_auth`, `cloud_firestore`.
3. Run `dart pub global activate flutterfire_cli` and `flutterfire configure` (generates `lib/firebase_options.dart` — never hardcode secret keys manually).
4. Deploy `docs/firestore.rules` via `firebase deploy --only firestore:rules`.
5. Implement `FirebaseAuthService implements AuthService` and `FirestoreCloudBackupDataSource implements CloudBackupRemoteDataSource`, then pass them into `QuizEnvironment`.

## 3. Data Isolation & Migration Plan
- **Local Isolation**: Every personal learning table (`test_history`, `bookmarks`, `wrong_answers`, `learning_goals`) is scoped by `user_id` (SQLite schema v2 migration automatically tags pre-existing v1 rows as `guest_local`).
- **Guest Mode**: New users start in `guest_local` without forced registration. When a guest creates an account, `AccountController.signUp(migrateGuestData: true)` safely migrates local guest records into the new `uid` with duplicate prevention.
- **Public vs Private Separation**: The Question Bank (`gk_arena_question_bank.db`) remains completely separate from per-user private learning data and is never uploaded or wiped by user account operations.
