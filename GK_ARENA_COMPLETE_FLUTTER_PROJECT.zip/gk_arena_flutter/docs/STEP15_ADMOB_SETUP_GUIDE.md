# GK ARENA — Step 15 AdMob Setup, Policy & Eligibility Guide

## 1. Development Mode Guarantee (Test Ads Only)
- `AdConfig.useTestAds` is set to `true` by default, and production IDs are placeholders (`REPLACE_WITH_PRODUCTION_ANDROID_...`).
- Official Google Android **TEST** Ad Unit IDs currently used:
  - Test App ID: `ca-app-pub-3940256099942544~3347511713`
  - Adaptive Banner Test ID: `ca-app-pub-3940256099942544/9214589741`
  - Interstitial Test ID: `ca-app-pub-3940256099942544/1033173712`
  - Rewarded Test ID: `ca-app-pub-3940256099942544/5224354917`
- **NEVER** click live production ads on your own device (violates Google AdMob policies).

## 2. Required AndroidManifest.xml Configuration (Before Android Build)
When Android platform files (`android/app/src/main/AndroidManifest.xml`) are generated via `flutter create . --platforms=android`, add inside `<application>`:
```xml
<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="ca-app-pub-3940256099942544~3347511713"/>
```
Replace the test App ID above with your real AdMob App ID **only** when preparing a verified Play Store production release.

## 3. Account Eligibility, Child/Teen Audience & Privacy Compliance
- **Account Holder Eligibility**: Google AdMob accounts require an eligible adult (18+) account holder with valid tax/payment verification. If the developer is under 18, a parent or legal guardian must create and manage the AdMob & Google Play Console accounts in compliance with Google's Terms of Service.
- **Student/Teen Safety**: `AdConsentAndPolicyService` sets `MaxAdContentRating.g` and `TagForUnderAgeOfConsent.yes` with `nonPersonalizedAds: true` by default.
- **Privacy Policy**: Publish a real Privacy Policy URL disclosing Google Mobile Ads SDK data usage before enabling production ads.
- **Production Cutover**: Replace the three `REPLACE_WITH_PRODUCTION_...` constants in `lib/features/monetization/config/ad_config.dart`, set `useTestAds = false`, and link your app in AdMob Console.
