# GK ARENA — Step 16 Final Release Readiness Checklist

## 1. Current Packaging & Release Verdict
**Status: NOT YET READY FOR PRODUCTION RELEASE** (Ready for cloud CI verification via GitHub Actions / Firebase Studio; native Android scaffolding & live verification remain).

## 2. Android Compatibility & Platform Setup Still Required
The `android/` native directory has not been generated in this container (Flutter SDK is unavailable here). On a Flutter-enabled environment (Firebase Studio / Codespaces / PC):
1. Run `flutter create . --platforms=android` (using your real chosen reverse-domain package ID — never invent a placeholder ID for Play Store).
2. Configure `android/app/build.gradle(.kts)`:
   - Confirm `minSdk >= 21` (required by `google_mobile_ads` & `sqflite`), `compileSdk` & `targetSdk` matching latest Google Play API level requirement.
   - Set final `applicationId`, `versionCode`, and `versionName` (`1.0.0+1` in `pubspec.yaml`).
3. Configure `android/app/src/main/AndroidManifest.xml`:
   - Label: `GK ARENA`
   - Permissions: `android.permission.INTERNET` and `android.permission.ACCESS_NETWORK_STATE` (no unnecessary dangerous permissions).
   - Add `<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" .../>` (use test App ID `ca-app-pub-3940256099942544~3347511713` until release).
4. Add real launcher icon and Android 12+ splash screen assets.

## 3. Code Signing & Credentials Security
- Generate a release upload keystore (`.jks`) locally/privately and configure `android/key.properties` **outside Git** (add `key.properties` and `*.jks` to `.gitignore`).
- Never commit signing keys, passwords, or Firebase/AdMob secrets into source code.

## 4. AdMob, Privacy Policy & Account Eligibility
- Replace `REPLACE_WITH_PRODUCTION_ANDROID_...` in `lib/features/monetization/config/ad_config.dart` and set `useTestAds = false` ONLY after Play Store release approval.
- Ensure Google Play Console and AdMob accounts are registered by an eligible adult (18+) account holder / legal guardian.
- Publish real **Privacy Policy** and **Terms & Conditions** URLs and replace placeholders in `SettingsScreen`.

## 5. Required Pre-Release Automated & Device Verification
1. Run `flutter pub get`, `flutter analyze`, and `flutter test` (all 14 test suites / 63 test cases) via `.github/workflows/flutter_test.yml` or Firebase Studio.
2. Run `flutter build apk --release` / `flutter build appbundle --release` in a real Flutter build environment.
3. Verify on a physical Android device: Light/Dark themes, Hindi Devanagari rendering, offline SQLite restart persistence, quiz timer, and AdMob **Test Ad** labels.
